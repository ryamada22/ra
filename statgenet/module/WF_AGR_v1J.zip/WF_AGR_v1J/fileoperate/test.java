package fileoperate;
import java.awt.*;
import java.awt.event.*;

class test extends WindowAdapter implements ActionListener {
	Frame frm = new Frame("Kitty on your lap");
	Label lb;
	public static void main(String args[]) {
		test win = new test();
	}
	public test() {
		frm.setSize(400 , 200);
		frm.setLayout(new GridLayout(2,1));

		Button load = (Button)frm.add(new Button("LOAD"));
		load.addActionListener(this);

		lb = (Label)frm.add(new Label());
		lb.setSize(50 , 400);

		frm.setVisible(true);
		frm.addWindowListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		FileDialog fd = new FileDialog(frm , "�ǂݍ��݂ɂ�" , FileDialog.LOAD);
		fd.setVisible(true);

		lb.setText(fd.getDirectory() + fd.getFile());
	}
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
}

