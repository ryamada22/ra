/*
 * �쐬��: 2005/09/16
 */
package fileoperate;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


/**
 * @author zumiko
 */
public class OpenF{
//abstract class OpenF{
	String openfile;
	FileReader infile;
	public BufferedReader in;
	//String line;
	
	public void openFstart(String file_) throws IOException{
		openfile = file_;
		infile = new FileReader(openfile);
		in = new BufferedReader(infile);
		//�^�u��؂�̃e�L�X�g�t�@�C��
		//while((line = in.readLine()) !=null){
		//}
	}

	
	public void openFend() throws IOException{
		in.close();
		infile.close();
	}
}