/*
 * File: DRect.java
 *
 * 5/26/96   Larry Barowski
 *
*/



package auburn.VGJ.util;



/**
 *	A class for holding a real rectangle.
 *	</p>Here is the <a href="../util/DRect.java">source</a>.
 *
 *@author	Larry Barowski
**/




public class DRect
{
public double	x, y, width, height;


public DRect(double x_in, double y_in, double width_in, double height_in)
	{
	x = x_in;
	y = y_in;
	width = width_in;
	height = height_in;
	}

}
