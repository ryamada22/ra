/*
 * �쐬��: 2005/10/30
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;

/**
 * @author Ryo Yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */

//	Sample17
	import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;
	import java.lang.Object.*;
;
	
	
	//public class InputFrame2 extends JFrame{
	public class InputFrame2{
		JTextField tf01=new JTextField("100000",8);
	    JTextField tf02=new JTextField("100",8);
	    JTextField tf03=new JTextField("100000",8);
	    JTextField tf04=new JTextField("50",8);
	    JTextField tf05=new JTextField("0.01",8);
	    JTextField tf06=new JTextField("0.1",8);
	    JTextField tf07=new JTextField(" �����̓s������͎͂Q�ƃ{�^�����g�p���Ă�������",26);
	    String dir = "";
	    String fileroot = "";
	    JTextField tf08=new JTextField("0.01",8);
	    
	    JLabel lb01=new JLabel("DNA��(���)");
	    JLabel lb02=new JLabel("�n�c����l��");
	    JLabel lb03=new JLabel("1cM�ɑ������鉖�");
	    JLabel lb04=new JLabel("�V�~�����[�V�������鐢�㐔");
	    JLabel lb05=new JLabel("�ψٗ�(0����1)");
	    JLabel lb06=new JLabel("�g������");
	    JLabel lb07=new JLabel("�o�͐�w��");
	    JLabel lb07_0=new JLabel("<�o�͎w��t�H���_�ɂāA�V�K�ɍ쐬�����ׂ���͖����w�肵�Ă�������>");
	    JLabel lb08=new JLabel("�n�v���^�C�v�p�x�̕\��臒l(0����1)");
	    //JLabel lb07a=new JLabel("!!Create directory \"C:\\\\WF_ARG\" or specify as you like!!");
	    
	    JLabel lb07_1=new JLabel("�ψٗ��Ƃ��Ă�1���゠����ɉ�͑Ώ۔͈͂�");
	    JLabel lb07_2=new JLabel("�ψق�����m�����w��B");
	    JLabel lb07_3=new JLabel("�g�������Ƃ��Ă�");
		JLabel lb08_1=new JLabel("1���゠�����1 cM�����̒���������ɋN����");
		JLabel lb08_2=new JLabel("�g�����񐔂��w��B");
		JLabel lb08_3=new JLabel("0.01���f�t�H���g�l                          ");
		
		
		
		
//�{�^����ǉ�
        JButton b01=new JButton("Apply & Run");
        JButton b02=new JButton("�K�p���Ď��s");
        JButton b03=new JButton("�Q��");
	    //�又��
	    public static void main(String ar[]){
	    	InputFrame2 sample = new InputFrame2();
	    }
	    //�R���X�g���N�^
	    public InputFrame2(){
	    	
	    	
	        // �t���[�����쐬
	        JFrame f=new JFrame("Input parameters");
	        

	        
	        
	        f.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	        //f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	        
	        b01.setActionCommand("Apply & Run");
	        b01.addActionListener(new PushButtonActionListener(f));
	        b02.setActionCommand("Apply");
	        b02.addActionListener(new PushButtonActionListener(f));
	        b02.setBackground(Color.ORANGE);
	        b03.setActionCommand("Directory");
	        b03.addActionListener(new PushButtonActionListener(f));
	        // �{�^���ƃe�L�X�g�t�B�[���h�����C�A�E�g
	        JPanel p1=new JPanel();
	        p1.add(lb01);
	        p1.add(tf01);
	        f.getContentPane().add(p1);
	        JPanel p2=new JPanel();
	        p2.add(lb02);
	        p2.add(tf02);
	        f.getContentPane().add(p2);
	        JPanel p3=new JPanel();
	        p3.add(lb03);
	        p3.add(tf03);
	        f.getContentPane().add(p3);
	        JPanel p4=new JPanel();
	        p4.add(lb04);
	        p4.add(tf04);
	        f.getContentPane().add(p4);
	        JPanel p5=new JPanel();
	        p5.add(lb05);
	        p5.add(tf05);
	        f.getContentPane().add(p5);
	        JPanel p6=new JPanel();
	        p6.add(lb06);
	        p6.add(tf06);
	        f.getContentPane().add(p6);
	        
	        JPanel p8=new JPanel();
	        p8.add(lb08);
	        p8.add(tf08);
	        f.getContentPane().add(p8);
	        //JPanel p7a=new JPanel();
	        //p7a.add(lb07a);
	        //f.getContentPane().add(p7a);
	        JPanel p7=new JPanel();
	        p7.add(lb07);
	        JPanel p7_0=new JPanel();
	        JPanel p7_5=new JPanel();
	        p7_5.add(lb07_0);
	        tf07.setBackground(Color.orange);
	        p7_0.add(tf07);
	        p7_0.add(b03);
	        f.getContentPane().add(p7);
	        
	        f.getContentPane().add(p7_0);
	        f.getContentPane().add(p7_5);
	        
	        
	        JPanel p7_1=new JPanel();
	        p7_1.add(lb07_1);
	        f.getContentPane().add(p7_1);
	        JPanel p7_2=new JPanel();
	        p7_2.add(lb07_2);
	        f.getContentPane().add(p7_2);
	        JPanel p7_3=new JPanel();
	        p7_3.add(lb07_3);
	        f.getContentPane().add(p7_3);
	        JPanel p8_1=new JPanel();
	        p8_1.add(lb08_1);
	        f.getContentPane().add(p8_1);
	        JPanel p8_2=new JPanel();
	        p8_2.add(lb08_2);
	        f.getContentPane().add(p8_2);
	        JPanel p8_3=new JPanel();
	        p8_3.add(lb08_3);
	        f.getContentPane().add(p8_3);
	        JPanel pb=new JPanel();
	        //pb.add(b01);
	        
	        
	        
	        pb.add(b02);
	        f.getContentPane().add(pb);
	        // �t���[����\��
	        f.setLocation(600, 50);
	        f.setSize(500,500);
	        f.setVisible(true);
	        
	        String mss1 = "  �o�͗p�̃f�B���N�g�����쐬���A����� ";
	        String mss2 = "   \"Input parameters\" window�Ɏw�肵�܂��B ";
	        String mss3 = "  �l���E���㐔���傫���ꍇ�A���Ԃ�������܂��B ";
	        String mss4 = "  �r���ŕۗ����邱�Ƃ��ł��܂����A�I�����ɂ̓��b�Z�[�W���o�܂��B ";
	        JFrame fa = new JFrame("Messages");
	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	    	//ErrDialog dia=new ErrDialog(fa,"Error Message",err);
	        //JLabel dir1 = new JLabel(mss1);
	        //JLabel dir2 = new JLabel(mss2);
	        JLabel dir3 = new JLabel(mss3);
	        JLabel dir4 = new JLabel(mss4);
	    	JPanel pdir1;
	    	JPanel pdir2;
	    	JPanel pdir3;
	    	JPanel pdir4;
	    	//pdir1 = new JPanel();
	    	//pdir1.add(dir1);
	    	//pdir2 = new JPanel();
	    	//pdir2.add(dir2);
	    	pdir3 = new JPanel();
	    	pdir3.add(dir3);
	    	pdir4 = new JPanel();
	    	pdir4.add(dir4);
	    	//fa.getContentPane().add(pdir1);
	    	//fa.getContentPane().add(pdir2);
	    	fa.getContentPane().add(pdir3);
	    	fa.getContentPane().add(pdir4);
	    	fa.setLocation(400,600);
	        fa.setSize(600,100);
	        fa.setVisible(true);
	    }
	    //�{�^���N���b�N���̃A�N�V�������X�i
	    private class PushButtonActionListener implements ActionListener{
	        JFrame f = null;
	        public PushButtonActionListener(JFrame af) {
	               this.f = af;
	        }
	        public void actionPerformed(ActionEvent ae){
	            
	            if(ae.getActionCommand()=="Apply & Run"){
	            	
	            	int int1 = Integer.parseInt(tf01.getText());
	            	int int2 = Integer.parseInt(tf02.getText());
	            	int int3 = Integer.parseInt(tf03.getText());
	            	int int4 = Integer.parseInt(tf04.getText());
	            	double double5 = Double.parseDouble(tf05.getText());
	            	double double6 = Double.parseDouble(tf06.getText());
	            	double ans = int1 + int2 + int3 + int4 + double5 + double6;
	            	
	            	
	            	String rootdir = tf07.getText();
	            	tf07.setBackground(Color.white);
	            	//JPanel p7_5=new JPanel();
	    	        //p7_5.add(lb07_0);
	    	        //p7_0.add(tf07);
	    	        //p7_0.add(b03);
	    	        //f.getContentPane().add(p7_0);
	            	
	            	double double8 = Double.parseDouble(tf08.getText());
	            	//System.out.println("rootdir " + rootdir);
	            	
	                
	            	WrightFisherParameter_Ref wfp;
	            	wfp = new WrightFisherParameter_Ref();
	            	wfp.region_length = int1;//nucleotide��100base�̂Ƃ�100
	            	wfp.population_size = int2*2;//1���l�A���F�̂�2���{
	            	wfp.nt_morgan_ratio = int3;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
	            	wfp.num_generation = int4;
	            	wfp.mutation_rate = double5;
	            	wfp.recombination_rate = double6;
	            	
	            	//wfp.hapfreq4disp = 0;
	            	wfp.hapfreq4disp = double8;
	                    //ErrDialog dia=new ErrDialog(this.f,"Error Message",err);
	            	//WFSim2_2 sim;
	            	//sim = new WFSim2_2();
	            	Cancel_WFSim2_2 sim;
	            	//sim = new Cancel_WFSim2_2(a,wfp);
	            	String a[] = {rootdir};
	            	//WFSim2_2.main2(a,wfp); 
	            	WFSim2_2.main3(a,wfp); 
	            	
	            	
	            	String mss0 = "  Simulation ended.";
	            	String mss1 = "  Open \".bml\" file(s) via Menu of VGJ window \"File->Open\".";
	            	String mss2 = "  Open \".svg\" file(s) via SVG viewer.";
	            	String mss3 = "  Other multiple files are logs or for further usages of simulational population.";
	    	        JFrame fa = new JFrame("Directions");
	    	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	    	        JLabel dir0 = new JLabel(mss0);
	    	        JLabel dir1 = new JLabel(mss1);
	    	    	JLabel dir2 = new JLabel(mss2);
	    	    	JLabel dir3 = new JLabel(mss3);
	    	    	JPanel pdir0;
	    	    	JPanel pdir1;
	    	    	JPanel pdir2;
	    	    	JPanel pdir3;
	    	    	pdir0 = new JPanel();
	    	    	pdir1 = new JPanel();
	    	    	pdir2 = new JPanel();
	    	    	pdir3 = new JPanel();
	    	    	pdir0.add(dir0);
	    	    	pdir1.add(dir1);
	    	    	pdir2.add(dir2);
	    	    	pdir3.add(dir3);
	    	    	fa.getContentPane().add(pdir0);
	    	    	fa.getContentPane().add(pdir1);
	    	    	fa.getContentPane().add(pdir2);
	    	    	fa.getContentPane().add(pdir3);
	    	    	fa.setLocation(300,500);
	    	        fa.setSize(600,100);
	    	        fa.setVisible(true);
	    	        
	                    return;
	                
	                
	            }
	            else if(ae.getActionCommand()=="Apply"){
	            	
	            	int int1 = Integer.parseInt(tf01.getText());
	            	int int2 = Integer.parseInt(tf02.getText());
	            	int int3 = Integer.parseInt(tf03.getText());
	            	int int4 = Integer.parseInt(tf04.getText());
	            	double double5 = Double.parseDouble(tf05.getText());
	            	double double6 = Double.parseDouble(tf06.getText());
	            	double ans = int1 + int2 + int3 + int4 + double5 + double6;
	            	//String rootdir = tf07.getText();
	            	
	            	String rootdir = dir;
	            	double double8 = Double.parseDouble(tf08.getText());
	            	//System.out.println("rootdir " + rootdir);
	            	MiscUtil2 ms = new MiscUtil2();
	            	//rootdir = ms.regReplaceAll2(rootdir,"\\","\\\\");
	                
	            	WrightFisherParameter_Ref wfp;
	            	wfp = new WrightFisherParameter_Ref();
	            	wfp.region_length = int1;//nucleotide��100base�̂Ƃ�100
	            	wfp.population_size = int2*2;//1���l�A���F�̂�2���{
	            	wfp.nt_morgan_ratio = int3;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
	            	wfp.num_generation = int4;
	            	wfp.mutation_rate = double5;
	            	wfp.recombination_rate = double6;
	            	
	            	//wfp.hapfreq4disp = 0;
	            	wfp.hapfreq4disp = double8;
	                    //ErrDialog dia=new ErrDialog(this.f,"Error Message",err);
	            	WFSim2_2 sim;
	            	sim = new WFSim2_2();
	            	String a[] = {rootdir,fileroot};
	            	//WFSim2_2.main2(a,wfp); 
	            	//sim.main3(a,wfp); 
	            	//CancelTestExtends ct = new CancelTestExtends();
	            	//CancelTestExtends.main(a);
	            	//Cancel_WFSim2_2.main3(a,wfp);
	            	Cancel_WFSim2_2_mkdir.main4(a,wfp);
	            	
	            	
	            	/*
	            	String mss0 = "  Simulation ended.";
	            	String mss1 = "  Open \".bml\" file(s) via Menu of VGJ window \"File->Open\".";
	            	String mss2 = "  Open \".svg\" file(s) via SVG viewer.";
	            	String mss3 = "  Other multiple files are logs or for further usages of simulational population.";
	    	        JFrame fa = new JFrame("Directions");
	    	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	    	        JLabel dir0 = new JLabel(mss0);
	    	        JLabel dir1 = new JLabel(mss1);
	    	    	JLabel dir2 = new JLabel(mss2);
	    	    	JLabel dir3 = new JLabel(mss3);
	    	    	JPanel pdir0;
	    	    	JPanel pdir1;
	    	    	JPanel pdir2;
	    	    	JPanel pdir3;
	    	    	pdir0 = new JPanel();
	    	    	pdir1 = new JPanel();
	    	    	pdir2 = new JPanel();
	    	    	pdir3 = new JPanel();
	    	    	pdir0.add(dir0);
	    	    	pdir1.add(dir1);
	    	    	pdir2.add(dir2);
	    	    	pdir3.add(dir3);
	    	    	fa.getContentPane().add(pdir0);
	    	    	fa.getContentPane().add(pdir1);
	    	    	fa.getContentPane().add(pdir2);
	    	    	fa.getContentPane().add(pdir3);
	    	    	fa.setLocation(300,500);
	    	        fa.setSize(600,100);
	    	        fa.setVisible(true);
	    	        */
	                    return;
	                
	                
	            }
	            else if(ae.getActionCommand()=="Directory"){
	            	FileDialog fd = new FileDialog(f , "Input File" , FileDialog.LOAD);
	        		fd.setVisible(true);
	        		dir = fd.getDirectory(); 
	        		fileroot = fd.getFile();
	        		tf07.setText(fd.getDirectory() + fd.getFile());
	        		tf07.setBackground(Color.white);

	            }
	        }    
	    }
	    //�_�C�A���O
	    class ErrDialog extends JDialog{
	        ErrDialog(Frame f,String title,String msg) {
	            // ���[�_���_�C�A���O���쐬
	            JDialog dia = new JDialog(f, title, true);
	            // ���x����ǉ�
	            JLabel lab = new JLabel(msg);
	            dia.getContentPane().add(BorderLayout.NORTH, lab);
	            // ���[�_���_�C�A���O��\��
	            dia.setLocation(250, 250);
	            dia.setSize(600, 100);
	            dia.setVisible(true);
	        }
	    }
	
	   
	
	}


