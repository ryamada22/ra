/*
 * �쐬��: 2005/08/26
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import treeANDvine.*;
import tAvEnter.*;

/**
 * @author yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
public class InOutCtrl {

	public static void main(String[] args) {
		
		
		//infile of haplotype set
		String indir ="C:\\retrohaplotype\\Mult2\\In\\";
		String infile="test5.txt";
		String input = indir + infile;
		
		//snp����haplotype���̊m�F
		int numsnp=0;
		int numhap=0;
		
		int lineCol[];
		lineCol = new int[2];
		try{
			lineCol=MiscUtilRY.lineCol(input);
		}catch(IOException e){
			System.out.println(e);
		}
		numhap=lineCol[0];
		int hp[][];
		hp = new int[lineCol[0]][0];
		try{
			hp=PoolhapRead.poolhap(input);
		}catch(IOException e){
			System.out.println(e);
		}
		
		int hap[][];
		hap = new int[lineCol[0]][lineCol[1]];
		for(int i=0;i<lineCol[0];i++){
			for(int j=0;j<lineCol[1];j++){
				hap[i][j]=0;
			}
		}
		for(int i=0;i<lineCol[0];i++){
			for(int j=0;j<hp[i].length;j++){
				hap[i][hp[i][j]]=1;
			}
		}
		for(int i=0;i<lineCol[1];i++){
			int zero=0;
			int one=0;
			for(int j=0;j<lineCol[0];j++){
				
				if(hap[j][i]==0){
					zero++;
				}else if(hap[j][j]==1){
					one++;
				}
			}
			if(zero*one>1){
				numsnp++;
			}
		}
		
		//output common among iterations
		String outdir="C:\\retrohaplotype\\Mult2\\Out\\";
		String outfile=infile;
		String output=outdir + "\\Multitrials\\"+outfile;
		
		//output for whole trials
		String outdirall="C:\\retrohaplotype\\Mult2\\Out\\";
		String outfileall=infile + "_all.xml";
		String outputall=outdirall + "\\Multitrials\\"+outfileall;
		
		String outtxt=infile + "_all.txt";
		String outputtxt=outdirall + "\\Multitrials\\"+ outtxt;
		
		String xsl="..\\xsl"+"\\Stat1.xsl";
		String extractxmlfile=outdirall + "\\Multitrials\\"+infile+"_Stat1.xml";
		String ext_text="";
		
		ext_text+=OutXML.HeaderXML();
		ext_text+="<?xml:stylesheet type=\"text/xsl\" href=\"" + xsl +"\"?>\n";
		ext_text+="<Stat1>\n";
		ext_text+="<title>Stat1</title>\n";
		ext_text+="<tbl href=\"" + outputall+"\"/>\n";
		ext_text+="</Stat1>\n";
		
		OutXML.out2File(extractxmlfile,ext_text);
		
		String outxml ="";
		//Iteration conditions
		int numiter = 2;
		//outfile options
		/*
		 * �����ɂ��AGML�\���𐧌�
		 * NdLb : 0�̓f�t�H���g�A1��haplotype �^�A2�̓n�v���^�C�vID�A3�̓n�v���^�C�v�^(0001010)
		 * EdLb : 0�̓f�t�H���g�A1��mutation/recombination�ʒu
		 * rootCol,mutCol,recCol : 0 blue,1 brown,2 pink,3 green,4 yellow
		 * mutEdcol, recEdcol : 0 black,1 blue, 2 green, 3 orange
		 * int origin ����:0��outVGJtoSt2�Ɠ����A1�͂͂��߂ɗ^����ꂽ�n�v���^�C�v�Ƃ��̑��̃n�v���^�C�v��ʂ̐F�ŕ\��
		 * rootCol���͂��߂ɂ������n�v���^�C�v�AmutCol��ǉ����ꂽ�n�v���^�C�v�̐F�Ƃ���
		 */
		int NdLb=3;
		int EdLb=1;
		int rootCol=3;
		int mutCol=1;
		int recCol=2;
		int mutEdcol=0;
		int recEdcol=3;
		int origin=1;
		
		//Log�o�^
		LogMult log;
		log=new LogMult(numhap,numsnp,numiter);
		for(int i=0;i<lineCol[0];i++){
			String tmp="";
			for(int j=0;j<lineCol[1];j++){
				tmp+=hap[i][j];
			}
			log.startHp[i]=tmp;
		}
		
		//outputall��iteration���ʕ����̃w�b�_
		outxml+=OutXML.HeaderXML();
		outxml+="<!DOCTYPE Graphs [\n";
		for(int i=0;i<numiter;i++){
			String output_tmp = outdirall + "Graphs\\" + outfile +"_" + i;
			outxml+="<!ENTITY id"+i+" SYSTEM \"" + output_tmp + ".xml\">\n";
			//outxml+="<!ENTITY node_"+i+" SYSTEM \"" + output_tmp + "_nd.xml\">\n";
			//outxml+="<!ENTITY edge_"+i+" SYSTEM \"" + output_tmp + "_ed.xml\">\n";
		}
		outxml+="]>\n\n";
		outxml+="<Graphs>";
		for(int i=0;i<numiter;i++){
			outxml+="&id"+i+";";
		}
		outxml+="</Graphs>";
		
		OutXML.out2File(outputall,outxml);
		
//		�R���\�[���\���̃^�C�g���s
		String title="Iteration\tNo.Root\tNo.Mut\tNo.Rec\tNo.Event\tGraph\t";
		
		System.out.println(title);
		title += "\n";
		
		
		for(int i=0;i<numiter;i++){
			
			String output_tmp = output + "_" + i;
			/*
			RetroFromTxtMult.run(input,output_tmp,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
					*/
			/*
			String noidxml = RetroFromTxtMult.run2(input,output_tmp,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			*/
			
			String noidxml = RetroFromTxtMult.run4(i,log,indir,infile,outdir,outfile,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			
			
			//���s���̕\��
			
			//���ʍs
			String result="";
			String result2="";
			result += i +"\t";
			result += log.root[i]+"\t";
			result +=  log.mutant[i]+"\t";
			result += log.rec[i]+"\t";
			result +=  log.numevent[i] + "\t";
			result += "G(" + log.totalnd[i] + "," + log.totaled[i] +")\t";
			
			result2 += i +"\t";
			result2 += log.root[i]+"\t";
			result2 +=  log.mutant[i]+"\t";
			result2 += log.rec[i]+"\t";
			result2 +=  log.numevent[i] + "\t";
			result2 += "G(\t" + log.totalnd[i] + "\t," + log.totaled[i] +"\t)\t";
			//nodetype
			result += "| ";
			for(int j=0;j<log.numhap;j++){
				result += log.numedges[j][i] + "; " + log.roots[j]+", " + log.muts[j]+", " + log.recs[j] +" | ";
				
				result2 += log.numedges[j][i] + "\t" + log.roots[j]+"\t" + log.muts[j]+"\t" + log.recs[j] +"\t|\t";
			
			}
			
			
			//result += "\n";
			System.out.println(result);
			
			//text file �o�͗p
			title+=result2 +"\n";
			
			/*
			//�ʂ��ďo�͂��邽�߂̏���
			outxml+=OutXML.GraphHeaderXML();
			outxml+= "\t<id>" + i + "</id>";
			outxml+=noidxml;
			outxml+=OutXML.GraphFooterXML();
			//System.out.println(outxml);
			 * 
			 */
			//System.out.println("iteration " + i);

			
		}
		/*
//		outputall��iteration���ʕ����̃t�b�^
		outxml+="</Graphs>\n";
		OutXML.out2File(outputall,outxml);
		*/
		OutXML.out2File(outputtxt,title);
//		�I���̕\��
		System.out.println("End of Program" );
	}

	public static void main2(String[] args,WrightFisherParameter_Ref_Rev wfp) {
		
		
		//infile of haplotype set
		/*
		String indir ="C:\\retrohaplotype\\Mult2\\In\\";
		String infile="poolhaplotype.txt";
		*/
		String indir = args[0];
		indir += "\\\\";
		String infile= args[1];
		String input = indir + infile;
		System.out.println(indir + " " + infile + " " + input);
		String outdir = args[2];
		
//		Iteration conditions
		int numiter =wfp.num_iteration;
		
		//snp����haplotype���̊m�F
		int numsnp=0;
		int numhap=0;
		
		int lineCol[];
		lineCol = new int[2];
		try{
			lineCol=MiscUtilRY.lineCol(input);
		}catch(IOException e){
			System.out.println(e);
		}
		numhap=lineCol[0];
		int hp[][];
		hp = new int[lineCol[0]][0];
		try{
			hp=PoolhapRead.poolhap(input);
		}catch(IOException e){
			System.out.println(e);
		}
		
		int hap[][];
		hap = new int[lineCol[0]][lineCol[1]];
		for(int i=0;i<lineCol[0];i++){
			for(int j=0;j<lineCol[1];j++){
				hap[i][j]=0;
			}
		}
		for(int i=0;i<lineCol[0];i++){
			for(int j=0;j<hp[i].length;j++){
				hap[i][hp[i][j]]=1;
			}
		}
		for(int i=0;i<lineCol[1];i++){
			int zero=0;
			int one=0;
			for(int j=0;j<lineCol[0];j++){
				
				if(hap[j][i]==0){
					zero++;
				}else if(hap[j][j]==1){
					one++;
				}
			}
			if(zero*one>1){
				numsnp++;
			}
		}
		
		//output common among iterations
		//String outdir="C:\\retrohaplotype\\Mult2\\Out\\";
		
		String outfile=infile;
		String output=outdir + "\\Multitrials\\"+outfile;
		
		//output for whole trials
		//String outdirall="C:\\retrohaplotype\\Mult2\\Out\\";
		String outdirall= outdir;
		String outfileall=infile + "_all.xml";
		String outputall=outdirall + "\\Multitrials\\"+outfileall;
		
		String outtxt=infile + "_all.txt";
		String outputtxt=outdirall + "\\Multitrials\\"+ outtxt;
		
		String xsl="..\\xsl"+"\\Stat1.xsl";
		String extractxmlfile=outdirall + "\\Multitrials\\"+infile+"_Stat1.xml";
		String ext_text="";
		
		ext_text+=OutXML.HeaderXML();
		ext_text+="<?xml:stylesheet type=\"text/xsl\" href=\"" + xsl +"\"?>\n";
		ext_text+="<Stat1>\n";
		ext_text+="<title>Stat1</title>\n";
		ext_text+="<tbl href=\"" + outputall+"\"/>\n";
		ext_text+="</Stat1>\n";
		
		OutXML.out2File(extractxmlfile,ext_text);
		
		String outxml ="";
		
		//outfile options
		/*
		 * �����ɂ��AGML�\���𐧌�
		 * NdLb : 0�̓f�t�H���g�A1��haplotype �^�A2�̓n�v���^�C�vID�A3�̓n�v���^�C�v�^(0001010)
		 * EdLb : 0�̓f�t�H���g�A1��mutation/recombination�ʒu
		 * rootCol,mutCol,recCol : 0 blue,1 brown,2 pink,3 green,4 yellow
		 * mutEdcol, recEdcol : 0 black,1 blue, 2 green, 3 orange
		 * int origin ����:0��outVGJtoSt2�Ɠ����A1�͂͂��߂ɗ^����ꂽ�n�v���^�C�v�Ƃ��̑��̃n�v���^�C�v��ʂ̐F�ŕ\��
		 * rootCol���͂��߂ɂ������n�v���^�C�v�AmutCol��ǉ����ꂽ�n�v���^�C�v�̐F�Ƃ���
		 */
//		�o�̓p�����^
		GMLoutParameters gmloutp;
		gmloutp = new GMLoutParameters();
		
		int NdLb=gmloutp.NdLb;
		int EdLb=gmloutp.EdLb;
		int rootCol=gmloutp.rootCol;
		int mutCol=gmloutp.mutCol;
		int recCol=gmloutp.recCol;
		int mutEdcol=gmloutp.mutEdcol;
		int recEdcol=gmloutp.recEdcol;
		int origin=gmloutp.origin;
		/*
		int NdLb=3;
		int EdLb=1;
		int rootCol=3;
		int mutCol=1;
		int recCol=2;
		int mutEdcol=0;
		int recEdcol=3;
		int origin=1;
		*/
		
		//Log�o�^
		LogMult log;
		log=new LogMult(numhap,numsnp,numiter);
		for(int i=0;i<lineCol[0];i++){
			String tmp="";
			for(int j=0;j<lineCol[1];j++){
				tmp+=hap[i][j];
			}
			log.startHp[i]=tmp;
		}
		
		//outputall��iteration���ʕ����̃w�b�_
		outxml+=OutXML.HeaderXML();
		outxml+="<!DOCTYPE Graphs [\n";
		for(int i=0;i<numiter;i++){
			String output_tmp = outdirall + "Graphs\\" + outfile +"_" + i;
			outxml+="<!ENTITY id"+i+" SYSTEM \"" + output_tmp + ".xml\">\n";
			//outxml+="<!ENTITY node_"+i+" SYSTEM \"" + output_tmp + "_nd.xml\">\n";
			//outxml+="<!ENTITY edge_"+i+" SYSTEM \"" + output_tmp + "_ed.xml\">\n";
		}
		outxml+="]>\n\n";
		outxml+="<Graphs>";
		for(int i=0;i<numiter;i++){
			outxml+="&id"+i+";";
		}
		outxml+="</Graphs>";
		
		OutXML.out2File(outputall,outxml);
		
//		�R���\�[���\���̃^�C�g���s
		String title="Iteration\tNo.Root\tNo.Mut\tNo.Rec\tNo.Event\tGraph\t";
		
		System.out.println(title);
		title += "\n";
		
		
		for(int i=0;i<numiter;i++){
			
			String output_tmp = output + "_" + i;
			/*
			RetroFromTxtMult.run(input,output_tmp,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
					*/
			/*
			String noidxml = RetroFromTxtMult.run2(input,output_tmp,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			*/
			
			String noidxml = RetroFromTxtMult.run4(i,log,indir,infile,outdir,outfile,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			
			
			//���s���̕\��
			
			//���ʍs
			String result="";
			String result2="";
			result += i +"\t";
			result += log.root[i]+"\t";
			result +=  log.mutant[i]+"\t";
			result += log.rec[i]+"\t";
			result +=  log.numevent[i] + "\t";
			result += "G(" + log.totalnd[i] + "," + log.totaled[i] +")\t";
			
			result2 += i +"\t";
			result2 += log.root[i]+"\t";
			result2 +=  log.mutant[i]+"\t";
			result2 += log.rec[i]+"\t";
			result2 +=  log.numevent[i] + "\t";
			result2 += "G(\t" + log.totalnd[i] + "\t," + log.totaled[i] +"\t)\t";
			//nodetype
			result += "| ";
			for(int j=0;j<log.numhap;j++){
				result += log.numedges[j][i] + "; " + log.roots[j]+", " + log.muts[j]+", " + log.recs[j] +" | ";
				
				result2 += log.numedges[j][i] + "\t" + log.roots[j]+"\t" + log.muts[j]+"\t" + log.recs[j] +"\t|\t";
			
			}
			
			
			//result += "\n";
			System.out.println(result);
			
			//text file �o�͗p
			title+=result2 +"\n";
			
			/*
			//�ʂ��ďo�͂��邽�߂̏���
			outxml+=OutXML.GraphHeaderXML();
			outxml+= "\t<id>" + i + "</id>";
			outxml+=noidxml;
			outxml+=OutXML.GraphFooterXML();
			//System.out.println(outxml);
			 * 
			 */
			//System.out.println("iteration " + i);

			
		}
		/*
//		outputall��iteration���ʕ����̃t�b�^
		outxml+="</Graphs>\n";
		OutXML.out2File(outputall,outxml);
		*/
		OutXML.out2File(outputtxt,title);
//		�I���̕\��
		System.out.println("End of Program" );
	}

	public static void main3(String[] args,int inputFileType,WrightFisherParameter_Ref_Rev wfp) {
		
		
		//infile of haplotype set
		/*
		String indir ="C:\\retrohaplotype\\Mult2\\In\\";
		String infile="poolhaplotype.txt";
		*/
		String indir = args[0];
		indir += "\\\\";
		String infile= args[1];
		String input = indir + infile;
		System.out.println("main3 " + indir + " " + infile + " " + input);
		String outdir = args[2];
		
//		Iteration conditions
		int numiter =wfp.num_iteration;
		
		//inputFileType
		int infiletype = inputFileType;
		
		//snp����haplotype���̊m�F
		int numsnp=0;//���^�ӏ���
		int region_len=0;
		int numhap=0;
//		haplotype��ސ��𐔂���
		 int haptypenum=0;
//		Log�o�^
		LogMult log;
		log=null;
		int lineCol[];
		lineCol = new int[2];
		int hap[][];
		
		//fileType 1 �p
		IntArray4Hp[] specifiedHp =null;
		int hpid[] = null;
		int hpfreq[] = null;
		if(infiletype ==0){
			
			try{
				lineCol=MiscUtilRY.lineCol(input);
			}catch(IOException e){
				System.out.println(e);
			}
			numhap=lineCol[0];
			region_len = lineCol[1];
			int hp[][];
			hp = new int[lineCol[0]][0];
			try{
				hp=PoolhapRead.poolhap(input);
			}catch(IOException e){
				System.out.println(e);
			}
			

			hap = new int[lineCol[0]][lineCol[1]];
			for(int i=0;i<lineCol[0];i++){
				for(int j=0;j<lineCol[1];j++){
					hap[i][j]=0;
				}
			}
			for(int i=0;i<lineCol[0];i++){
				for(int j=0;j<hp[i].length;j++){
					hap[i][hp[i][j]]=1;
				}
			}
			for(int i=0;i<lineCol[1];i++){
				int zero=0;
				int one=0;
				for(int j=0;j<lineCol[0];j++){
					
					if(hap[j][i]==0){
						zero++;
					}else if(hap[j][i]==1){
						one++;
					}
				}
				if(zero*one>1){
					numsnp++;
				}
			}

			log=new LogMult(numhap,numsnp,numiter);
			for(int i=0;i<lineCol[0];i++){
				String tmp="";
				for(int j=0;j<lineCol[1];j++){
					tmp+=hap[i][j];
				}
				log.startHp[i]=tmp;
			}
		}
		else if(infiletype==1){
			
			FileReader fr = null;
			System.out.println("koko");
			try{
				 fr = new FileReader(input);
				 BufferedReader objBr=new BufferedReader(fr);
				 int fileline=0;
				 
				 while(objBr.ready()){
				 	fileline++;
				 	String[] aryTkn=objBr.readLine().split("\t");
				 	if(fileline>9){
				 		haptypenum++;
				 		System.out.println("hp" + fileline);
				 	}
				 }
				 objBr.close();
				 objBr = null;
			}catch(IOException e){
				System.out.println(e);
			}
			
			fr = null;
			System.out.println("koko");
			try{
				 
				fr = new FileReader(input);
				 BufferedReader objBr=new BufferedReader(fr);
				 int fileline=0;
				 //haplotype��ސ��𐔂���
				 hpid = new int[haptypenum];
					hpfreq = new int[haptypenum];
					specifiedHp = new IntArray4Hp[haptypenum];
				System.out.println("haptypenum " + haptypenum);
				while(objBr.ready()){
					//System.out.println("numhap " + numhap);
					fileline++;
					int tokennum=0;
					String[] aryTkn=objBr.readLine().split("\t");
					//System.out.println("length " + aryTkn.length);
					if(fileline==1){
						//numsnp = Integer.parseInt(aryTkn[1]);
						region_len = Integer.parseInt(aryTkn[1]);
						//System.out.println("kok " + numsnp);
					}
					else if (fileline ==2){
						numhap = Integer.parseInt(aryTkn[1]);
						
					}
					
					else if(fileline>9){
						for(int i=0;i<haptypenum;i++){
							if(Integer.parseInt(aryTkn[0])==i){
								specifiedHp[i] = new IntArray4Hp();
								System.out.println("hapid�m�F");
								for(int j=1;j<aryTkn.length;j++){
									hpid[i]=Integer.parseInt(aryTkn[1]);
									hpfreq[i]=Integer.parseInt(aryTkn[2]);
									if(j>2){
										specifiedHp[i].addelem(Integer.parseInt(aryTkn[j]));
									}
								}
								
								for(int j=0;j<specifiedHp[i].arr.length;j++){
									System.out.println("ss " + specifiedHp[i].arr[j]);
								}
							}
						}
					}
				}
				objBr.close();
				
			}catch(IOException e){
				System.out.println(e);
			}
			
			//numhap=1;numsnp=3;
			System.out.println("haptypenum region_len " + haptypenum + " " + region_len);
			
			hap = new int[haptypenum][region_len];
			for(int i=0;i<haptypenum;i++){
				for(int j=0;j<region_len;j++){
					hap[i][j]=0;
				}
				for(int j=0;j<specifiedHp[i].arr.length;j++){
					hap[i][specifiedHp[i].arr[j]]=1;
				}
			}
			for(int i=0;i<region_len;i++){
				int zero=0;
				int one=0;
				for(int j=0;j<haptypenum;j++){
					
					if(hap[j][i]==0){
						zero++;
					}else if(hap[j][j]==1){
						one++;
					}
				}
				if(zero*one>1){
					numsnp++;
				}
			}
			log=new LogMult(haptypenum,numsnp,numiter);
			//log=new LogMult(numhap,numsnp,numiter);
			for(int i=0;i<haptypenum;i++){
				String tmp="";
				for(int j=0;j<region_len;j++){
					tmp+=hap[i][j];
				}
				log.startHp[i]=tmp;
			}
			/*
			for(int i=0;i<lineCol[0];i++){
				String tmp="";
				for(int j=0;j<lineCol[1];j++){
					tmp+=hap[i][j];
				}
				log.startHp[i]=tmp;
			}
			*/
			
			
			
		}
		
		
		//output common among iterations
		//String outdir="C:\\retrohaplotype\\Mult2\\Out\\";
		
		String outfile=infile;
		String output=outdir + "\\Multitrials\\"+outfile;
		
		//output for whole trials
		//String outdirall="C:\\retrohaplotype\\Mult2\\Out\\";
		String outdirall= outdir;
		String outfileall=infile + "_all.xml";
		String outputall=outdirall + "\\Multitrials\\"+outfileall;
		
		String outtxt=infile + "_all.txt";
		String outputtxt=outdirall + "\\Multitrials\\"+ outtxt;
		
		String xsl="..\\xsl"+"\\Stat1.xsl";
		String extractxmlfile=outdirall + "\\Multitrials\\"+infile+"_Stat1.xml";
		String ext_text="";
		
		ext_text+=OutXML.HeaderXML();
		ext_text+="<?xml:stylesheet type=\"text/xsl\" href=\"" + xsl +"\"?>\n";
		ext_text+="<Stat1>\n";
		ext_text+="<title>Stat1</title>\n";
		ext_text+="<tbl href=\"" + outputall+"\"/>\n";
		ext_text+="</Stat1>\n";
		
		OutXML.out2File(extractxmlfile,ext_text);
		
		String outxml ="";
		
		//outfile options
		/*
		 * �����ɂ��AGML�\���𐧌�
		 * NdLb : 0�̓f�t�H���g�A1��haplotype �^�A2�̓n�v���^�C�vID�A3�̓n�v���^�C�v�^(0001010)
		 * EdLb : 0�̓f�t�H���g�A1��mutation/recombination�ʒu
		 * rootCol,mutCol,recCol : 0 blue,1 brown,2 pink,3 green,4 yellow
		 * mutEdcol, recEdcol : 0 black,1 blue, 2 green, 3 orange
		 * int origin ����:0��outVGJtoSt2�Ɠ����A1�͂͂��߂ɗ^����ꂽ�n�v���^�C�v�Ƃ��̑��̃n�v���^�C�v��ʂ̐F�ŕ\��
		 * rootCol���͂��߂ɂ������n�v���^�C�v�AmutCol��ǉ����ꂽ�n�v���^�C�v�̐F�Ƃ���
		 */
//		�o�̓p�����^
		GMLoutParameters gmloutp;
		gmloutp = new GMLoutParameters();
		
		int NdLb=gmloutp.NdLb;
		int EdLb=gmloutp.EdLb;
		int rootCol=gmloutp.rootCol;
		int mutCol=gmloutp.mutCol;
		int recCol=gmloutp.recCol;
		int mutEdcol=gmloutp.mutEdcol;
		int recEdcol=gmloutp.recEdcol;
		int origin=gmloutp.origin;
		/*
		int NdLb=3;
		int EdLb=1;
		int rootCol=3;
		int mutCol=1;
		int recCol=2;
		int mutEdcol=0;
		int recEdcol=3;
		int origin=1;
		*/
		
		
		
		//outputall��iteration���ʕ����̃w�b�_
		outxml+=OutXML.HeaderXML();
		outxml+="<!DOCTYPE Graphs [\n";
		for(int i=0;i<numiter;i++){
			String output_tmp = outdirall + "Graphs\\" + outfile +"_" + i;
			outxml+="<!ENTITY id"+i+" SYSTEM \"" + output_tmp + ".xml\">\n";
			//outxml+="<!ENTITY node_"+i+" SYSTEM \"" + output_tmp + "_nd.xml\">\n";
			//outxml+="<!ENTITY edge_"+i+" SYSTEM \"" + output_tmp + "_ed.xml\">\n";
		}
		outxml+="]>\n\n";
		outxml+="<Graphs>";
		for(int i=0;i<numiter;i++){
			outxml+="&id"+i+";";
		}
		outxml+="</Graphs>";
		
		OutXML.out2File(outputall,outxml);
		
//		�R���\�[���\���̃^�C�g���s
		String title="Iteration\tNo.Root\tNo.Mut\tNo.Rec\tNo.Event\tGraph\t";
		
		System.out.println(title);
		title += "\n";
		
		
		for(int i=0;i<numiter;i++){
			
			String output_tmp = output + "_" + i;
			/*
			RetroFromTxtMult.run(input,output_tmp,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
					*/
			/*
			String noidxml = RetroFromTxtMult.run2(input,output_tmp,NdLb,EdLb,
					rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			*/
			if(infiletype == 0){
				System.out.println("������");
				String noidxml = RetroFromTxtMult.run4_2(numsnp,i,log,indir,infile,outdir,outfile,NdLb,EdLb,
						rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			}
			else if(infiletype == 1){
				System.out.println("����");
				String noidxml = RetroFromTxtMult.run5_2(numsnp,hpid,hpfreq,specifiedHp,i,log,indir,infile,outdir,outfile,NdLb,EdLb,
						rootCol,mutCol,recCol,mutEdcol,recEdcol,origin);
			}
			
			
			
			//���s���̕\��
			
			//���ʍs
			String result="";
			String result2="";
			result += i +"\t";
			result += log.root[i]+"\t";
			result +=  log.mutant[i]+"\t";
			result += log.rec[i]+"\t";
			result +=  log.numevent[i] + "\t";
			result += "G(" + log.totalnd[i] + "," + log.totaled[i] +")\t";
			
			result2 += i +"\t";
			result2 += log.root[i]+"\t";
			result2 +=  log.mutant[i]+"\t";
			result2 += log.rec[i]+"\t";
			result2 +=  log.numevent[i] + "\t";
			result2 += "G(\t" + log.totalnd[i] + "\t," + log.totaled[i] +"\t)\t";
			//nodetype
			result += "| ";
			for(int j=0;j<log.numhap;j++){
				result += log.numedges[j][i] + "; " + log.roots[j]+", " + log.muts[j]+", " + log.recs[j] +" | ";
				
				result2 += log.numedges[j][i] + "\t" + log.roots[j]+"\t" + log.muts[j]+"\t" + log.recs[j] +"\t|\t";
			
			}
			
			
			//result += "\n";
			System.out.println(result);
			
			//text file �o�͗p
			title+=result2 +"\n";
			
			/*
			//�ʂ��ďo�͂��邽�߂̏���
			outxml+=OutXML.GraphHeaderXML();
			outxml+= "\t<id>" + i + "</id>";
			outxml+=noidxml;
			outxml+=OutXML.GraphFooterXML();
			//System.out.println(outxml);
			 * 
			 */
			//System.out.println("iteration " + i);

			
		}
		/*
//		outputall��iteration���ʕ����̃t�b�^
		outxml+="</Graphs>\n";
		OutXML.out2File(outputall,outxml);
		*/
		OutXML.out2File(outputtxt,title);
//		�I���̕\��
		System.out.println("End of Program" );
	}

}
