/*
 * �쐬��: 2005/08/02
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;
import java.io.*;
import java.util.*;
import java.io.IOException;
import java.io.StringBufferInputStream;

import auburn.VGJ.*;
import auburn.VGJ.algorithm.GraphUpdate;
import auburn.VGJ.algorithm.cartegw.BiconnectGraph;
import auburn.VGJ.algorithm.cgd.CGDAlgorithm;
import auburn.VGJ.algorithm.shawn.Spring;
import auburn.VGJ.algorithm.tree.TreeAlgorithm;
import auburn.VGJ.examplealg.ExampleAlg2;
import auburn.VGJ.graph.GMLobject;
import auburn.VGJ.graph.Graph;
import auburn.VGJ.graph.ParseError;
import auburn.VGJ.gui.MessageDialog;
import auburn.VGJ.gui.GraphWindow;
import auburn.VGJ.graph.*;

import tAvEnter.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import java.lang.Object;



/**
 * @author yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
public class RetroFromTxtMult {

	public static void main(String[] args) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];	
		//String file = "/home/zumiaki/java/RetroGradetHP3toROOTnoFileAug22/tAvEnter/poolhaplotype";
		
		
		//Yamada's modify Aug24
		//String file = args[0];
		String file;
		String dir="C:\\retrohaplotype\\";
		String infile="poolhaplotype";
		file = dir + infile;
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		lg.printAll();
		//lg.printRetroMR();
		lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startHaplotype);
//		�E�B���h�E
        TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		String outxml ="";
		outxml+=OutXML.HeaderXML();
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		
		outxml+=OutXML.GraphFooterXML();
		//outxml+=OutXML.NodeHeaderXML();
		//for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//outxml+= OutXML.Node2XML(tmpgr2[1].nodes[i]);
		//}
		
		//�S���s�ʂ��Ă�xml�t�@�C���ɂ́Agr�h�c�����s�񐔂Ƃ���
		
		//outxml+=OutXML.NodeFooterXML();
		OutXML.out2File(xmlfile,outxml);
		int kyori[][]=GraphStat.dijkstra(tmpgr2[1],0);
		int kyoriNoDir[][]=GraphStat.dijkstra(tmpgr2[1],1);
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}


	public static void run(String infile,String outfile,int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];	
		//String file = "/home/zumiaki/java/RetroGradetHP3toROOTnoFileAug22/tAvEnter/poolhaplotype";
		
		
		//Yamada's modify Aug24
		//String file = args[0];
		/*
		String file;
		String dir="C:\\retrohaplotype\\";
		String infile="poolhaplotype";
		
		file = dir + infile;
		*/
		String file = infile;
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		lg.printAll();
		//lg.printRetroMR();
		lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outfile + ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		String outxml ="";
		outxml+=OutXML.HeaderXML();
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		outxml+=OutXML.GraphFooterXML();
		//outxml+=OutXML.NodeHeaderXML();
		//for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//outxml+= OutXML.Node2XML(tmpgr2[1].nodes[i]);
		//}
		
		
		//outxml+=OutXML.NodeFooterXML();
		
		xmlfile = outfile + ".xml";
		
		OutXML.out2File(xmlfile,outxml);
		int kyori[][]=GraphStat.dijkstra(tmpgr2[1],0);
		int kyoriNoDir[][]=GraphStat.dijkstra(tmpgr2[1],1);
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}


	/*
	 * String��Ԃ�
	 */
	public static String run2(String infile,String outfile,int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];	
		//String file = "/home/zumiaki/java/RetroGradetHP3toROOTnoFileAug22/tAvEnter/poolhaplotype";
		
		
		//Yamada's modify Aug24
		//String file = args[0];
		/*
		String file;
		String dir="C:\\retrohaplotype\\";
		String infile="poolhaplotype";
		
		file = dir + infile;
		*/
		String file = infile;
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		//System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		//System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		//System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			//System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		//lg.printAll();
		//lg.printRetroMR();
		//lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		//System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outfile + ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        //TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		String outxml ="";
		outxml+=OutXML.HeaderXML();
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		outxml+=OutXML.GraphFooterXML();
		//outxml+=OutXML.NodeHeaderXML();
		//for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//outxml+= OutXML.Node2XML(tmpgr2[1].nodes[i]);
		//}
		
		
		//outxml+=OutXML.NodeFooterXML();
		
		xmlfile = outfile + ".xml";
		
		OutXML.out2File(xmlfile,outxml);
		int kyori[][]=GraphStat.dijkstra(tmpgr2[1],0);
		int kyoriNoDir[][]=GraphStat.dijkstra(tmpgr2[1],1);
		
		//return�p��String���쐬����
		String retst="";
		retst +=OutXML.Graph2XMLnoID(tmpgr2[1],0,lg.numsnp,lg);
		
		return retst;
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}


	/*
	 * Log�������Ƃ��Ď���āALog���X�V����@String��Ԃ�
	 */
	public static String run3(int iter,LogMult log,String infile,String outfile,int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];	
		//String file = "/home/zumiaki/java/RetroGradetHP3toROOTnoFileAug22/tAvEnter/poolhaplotype";
		
		
		//Yamada's modify Aug24
		//String file = args[0];
		/*
		String file;
		String dir="C:\\retrohaplotype\\";
		String infile="poolhaplotype";
		
		file = dir + infile;
		*/
		String file = infile;
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		//System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		//System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		//System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			//System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		//MultiTrial Log�o�^
		
		log.totalnd[iter]=tmpgr2[1].nodes.length;
		log.totaled[iter]=tmpgr2[1].edges.length;
		
		//Node type
		int nodetype[]=GraphStat.NodeType(tmpgr2[1]);
		log.root[iter]=nodetype[0];
		log.mutant[iter]=nodetype[1];
		log.rec[iter]=nodetype[2];
		
		//Event�W�v
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		log.numevent[iter]=num0+num1+num2+num3+num4;
		log.mut_new[iter]=num0;
		log.mut_new[iter]=num1;
		log.rec_new[iter]=num3;
		log.rec_no_new[iter]=num4;
		
		//haplotype���Ƃ̏W�v
		for(int i=0;i<lg.startHaplotype.length;i++){
			tmpnd=lg.startHaplotype[i].argnd;
			int ndtype=TaVtoGML.nodeType(tmpnd);
			if(ndtype==0){
				log.roots[i]++;
			}else if(ndtype==1){
				log.muts[i]++;
			}else if(ndtype==2){
				log.recs[i]++;
			}
			log.numedges[i][iter]=tmpnd.edge.length;
		}
		
		//haplotype�ԋ����̎Z�o
		log.distanceHpDir[iter]=GraphStat.dijkstra(tmpgr2[1],0);
		log.distanceHpNoDir[iter]=GraphStat.dijkstra(tmpgr2[1],1);
		
		
		
		//lg.printAll();
		//lg.printRetroMR();
		//lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		//System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outfile + ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        //TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		xmlfile = outfile + ".xml";//�m�[�h�E�G�b�W�̏��͍ڂ����A�����̃O���t�̏�����ׂ�̂Ɏg��
		String xmlfile_n_e = outfile + "_n_e.xml";//Graph�̃m�[�h�E�G�b�W�̏��𓋍�
		String xmlfile_nd = outfile + "_nd.xml";
		String xmlfile_ed = outfile + "_ed.xml";
		
		String outxml ="";//xmlfile�p
		String outxml_n_e="";
		outxml+=OutXML.HeaderXML();
		outxml_n_e+=OutXML.HeaderXML();
		
		
		outxml_n_e+="<!DOCTYPE Graph [\n";
		outxml_n_e+="<!ENTITY node SYSTEM \""+xmlfile_nd+"\">";	
		outxml_n_e+="<!ENTITY edge SYSTEM \""+xmlfile_ed+"\">";
		outxml_n_e+="]>";
		
		
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml_n_e+=OutXML.GraphHeaderXML();
		
		//outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		//outxml+=OutXML.Graph2XMLiter(iter,tmpgr2[1],0,lg.numsnp,lg);
		//Graph�̏����ڂ���
		outxml+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		outxml_n_e+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		//GML�e�L�X�g���ڂ���
		outxml+="<GML>\n" + text + "\n</GML>\n";
		outxml_n_e+="<GML>\n" + text + "\n</GML>\n";
		//Node��XML������A������ڂ���
		outxml_n_e+="&node"+";\n";
		//Edge��XML������A������ڂ���
		outxml_n_e+="&edge" + ";\n";
		outxml+=OutXML.GraphFooterXML();
		outxml_n_e+=OutXML.GraphFooterXML();
		//Node��xml�p��String
		String xml_nd="";
		//xml_nd+=OutXML.HeaderXML();
		xml_nd+=OutXML.NodeHeaderXML();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			xml_nd += "<Node>\n";
			xml_nd+= OutXML.Node2XMLTab(tmpgr2[1].nodes[i],1,lg.numsnp);
			xml_nd += "\n</Node>\n";
		}
		xml_nd+=OutXML.NodeFooterXML();
		//Edge��xml�p��String
		String xml_ed="";
		//xml_ed+=OutXML.HeaderXML();
		xml_ed+=OutXML.EdgeHeaderXML();
		for(int i=0;i<tmpgr2[1].edges.length;i++){
			xml_ed+="<Edge>\n";
			xml_ed+= OutXML.Edge2XMLTab(tmpgr2[1].edges[i],1);
			xml_ed+="\n</Edge>\n";
		}
		xml_ed+=OutXML.EdgeFooterXML();
		
		
		OutXML.out2File(xmlfile,outxml);
		OutXML.out2File(xmlfile_n_e,outxml_n_e);
		OutXML.out2File(xmlfile_nd,xml_nd);
		OutXML.out2File(xmlfile_ed,xml_ed);
		
		//return�p��String���쐬����
		String retst="";
		retst +=OutXML.Graph2XMLnoID(tmpgr2[1],0,lg.numsnp,lg);
		
		
		//�P���s�I������Ƃ���ŁAlog�ȊO��S��null�ɂ���
		for(int i=0;i<lg.nd.length;i++){
			
			lg.nd[i].edge=null;
			lg.nd[i].hp=null;
			lg.nd[i].ev=null;
			lg.nd[i].gr=null;
			lg.nd[i]=null;
		}
		for(int i=0;i<lg.ed.length;i++){
			
			lg.ed[i].end=null;
			lg.ed[i].start=null;
			lg.ed[i].ev=null;
			lg.ed[i].gr=null;
			lg.ed[i]=null;
		}
		for(int i=0;i<lg.gr.length;i++){
			
			lg.gr[i].edges=null;
			lg.gr[i].nodes=null;
			lg.gr[i].ev=null;
			lg.gr[i]=null;
		}
		for(int i=0;i<lg.hp.length;i++){
			
			lg.hp[i].argnd=null;
			lg.hp[i].forestnd=null;
			lg.hp[i].treend=null;
			lg.hp[i].st=null;
			lg.hp[i].end=null;
			lg.hp[i].hp=null;
			lg.hp[i]=null;
		}
		for(int i=0;i<lg.ev.length;i++){
			
			lg.ev[i].adedarg=null;
			lg.ev[i].adedfr=null;
			lg.ev[i].adedtr=null;
			lg.ev[i].adndarg=null;
			lg.ev[i].adndfr=null;
			lg.ev[i].adndtr=null;
			lg.ev[i].adTree=null;
			lg.ev[i].arg=null;
			lg.ev[i].child_hp=null;
			lg.ev[i].ed=null;
			lg.ev[i].event_site=null;
			lg.ev[i].fr=null;
			lg.ev[i].fr=null;
			lg.ev[i].hp=null;
			lg.ev[i].ko=null;
			lg.ev[i].oya1=null;
			lg.ev[i].oya2=null;
			lg.ev[i].parent_hp=null;
			lg.ev[i].rmedarg=null;
			lg.ev[i].rmedfr=null;
			lg.ev[i].rmedtr=null;
			lg.ev[i].rmndarg=null;
			lg.ev[i].rmndfr=null;
			lg.ev[i].rmndtr=null;
			lg.ev[i].rmTree=null;
			lg.ev[i]=null;
		}
		lg=null;
		tmpev = null;
		tmphaplotype = null;
		tmpnd = null;
		tmped = null;
		tmpgr = null;
		tmpgr2 = null;
		grall = null;
		tmpgr_2 = null;
		
		return retst;
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}


	/*
	 * Log�������Ƃ��Ď���āALog���X�V����@String��Ԃ�
	 */
	/*
	 * run4��010101�\���̓��̓t�@�C�����Ƃ�
	 */
	public static String run4(int iter,LogMult log,String indir,String infile,String outdir,String outfile, int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		
		Retrograde_Parameters rpara = new Retrograde_Parameters();
		
		
		int iteration = rpara.iteration;
		int num_iteration = rpara.num_iteration;
		double recratio = rpara.recratio;
		int max_iter = rpara.max_iter;
		int backrecdepth = rpara.backrecdepth;
		
		int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		
		/*
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		*/
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];	
		//String file = "/home/zumiaki/java/RetroGradetHP3toROOTnoFileAug22/tAvEnter/poolhaplotype";
		
		
		//Yamada's modify Aug24
		//String file = args[0];
		/*
		String file;
		String dir="C:\\retrohaplotype\\";
		String infile="poolhaplotype";
		
		file = dir + infile;
		*/
		String file = indir + infile;
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		//System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		//System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		//System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			//System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		//MultiTrial Log�o�^
		
		log.totalnd[iter]=tmpgr2[1].nodes.length;
		log.totaled[iter]=tmpgr2[1].edges.length;
		
		//Node type
		int nodetype[]=GraphStat.NodeType(tmpgr2[1]);
		log.root[iter]=nodetype[0];
		log.mutant[iter]=nodetype[1];
		log.rec[iter]=nodetype[2];
		
		//Event�W�v
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		log.numevent[iter]=num0+num1+num2+num3+num4;
		log.mut_new[iter]=num0;
		log.mut_new[iter]=num1;
		log.rec_new[iter]=num3;
		log.rec_no_new[iter]=num4;
		
		//haplotype���Ƃ̏W�v
		for(int i=0;i<lg.startHaplotype.length;i++){
			tmpnd=lg.startHaplotype[i].argnd;
			int ndtype=TaVtoGML.nodeType(tmpnd);
			if(ndtype==0){
				log.roots[i]++;
			}else if(ndtype==1){
				log.muts[i]++;
			}else if(ndtype==2){
				log.recs[i]++;
			}
			log.numedges[i][iter]=tmpnd.edge.length;
		}
		
		//haplotype�ԋ����̎Z�o
		log.distanceHpDir[iter]=GraphStat.dijkstra(tmpgr2[1],0);
		log.distanceHpNoDir[iter]=GraphStat.dijkstra(tmpgr2[1],1);
		
		
		
		//lg.printAll();
		//lg.printRetroMR();
		//lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		//System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outdir + "\\Graph_gmls\\"  + outfile + "_"+iter+ ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        //TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		xmlfile = outdir + "\\Graphs\\" + outfile + "_"+iter+".xml";//�m�[�h�E�G�b�W�̏��͍ڂ����A�����̃O���t�̏�����ׂ�̂Ɏg��
		String xmlfile_n_e = outdir + "\\Graph_n_es\\" + outfile + "_"+iter+"_n_e.xml";//Graph�̃m�[�h�E�G�b�W�̏��𓋍�
		String xmlfile_nd = outdir + "\\Nodes\\" + outfile + "_"+iter+"_nd.xml";
		String xmlfile_ed = outdir + "\\Edges\\" + outfile + "_"+iter+"_ed.xml";
		
		String outxml ="";//xmlfile�p
		String outxml_n_e="";
		outxml+=OutXML.HeaderXML();
		outxml_n_e+=OutXML.HeaderXML();
		
		
		outxml_n_e+="<!DOCTYPE Graph [\n";
		outxml_n_e+="<!ENTITY node SYSTEM \""+xmlfile_nd+"\">";	
		outxml_n_e+="<!ENTITY edge SYSTEM \""+xmlfile_ed+"\">";
		outxml_n_e+="]>";
		
		
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml_n_e+=OutXML.GraphHeaderXML();
		
		//outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		//outxml+=OutXML.Graph2XMLiter(iter,tmpgr2[1],0,lg.numsnp,lg);
		//Graph�̏����ڂ���
		outxml+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		outxml_n_e+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		//GML�e�L�X�g���ڂ���
		outxml+="<GML>\n" + text + "\n</GML>\n";
		outxml_n_e+="<GML>\n" + text + "\n</GML>\n";
		//Node��XML������A������ڂ���
		outxml_n_e+="&node"+";\n";
		//Edge��XML������A������ڂ���
		outxml_n_e+="&edge" + ";\n";
		outxml+=OutXML.GraphFooterXML();
		outxml_n_e+=OutXML.GraphFooterXML();
		//Node��xml�p��String
		String xml_nd="";
		//xml_nd+=OutXML.HeaderXML();
		xml_nd+=OutXML.NodeHeaderXML();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			xml_nd += "<Node>\n";
			xml_nd+= OutXML.Node2XMLTab(tmpgr2[1].nodes[i],1,lg.numsnp);
			xml_nd += "\n</Node>\n";
		}
		xml_nd+=OutXML.NodeFooterXML();
		//Edge��xml�p��String
		String xml_ed="";
		//xml_ed+=OutXML.HeaderXML();
		xml_ed+=OutXML.EdgeHeaderXML();
		for(int i=0;i<tmpgr2[1].edges.length;i++){
			xml_ed+="<Edge>\n";
			xml_ed+= OutXML.Edge2XMLTab(tmpgr2[1].edges[i],1);
			xml_ed+="\n</Edge>\n";
		}
		xml_ed+=OutXML.EdgeFooterXML();
		
		
		OutXML.out2File(xmlfile,outxml);
		OutXML.out2File(xmlfile_n_e,outxml_n_e);
		OutXML.out2File(xmlfile_nd,xml_nd);
		OutXML.out2File(xmlfile_ed,xml_ed);
		
		//return�p��String���쐬����
		String retst="";
		retst +=OutXML.Graph2XMLnoID(tmpgr2[1],0,lg.numsnp,lg);
		
		
		//�P���s�I������Ƃ���ŁAlog�ȊO��S��null�ɂ���
		for(int i=0;i<lg.nd.length;i++){
			
			lg.nd[i].edge=null;
			lg.nd[i].hp=null;
			lg.nd[i].ev=null;
			lg.nd[i].gr=null;
			lg.nd[i]=null;
		}
		for(int i=0;i<lg.ed.length;i++){
			
			lg.ed[i].end=null;
			lg.ed[i].start=null;
			lg.ed[i].ev=null;
			lg.ed[i].gr=null;
			lg.ed[i]=null;
		}
		for(int i=0;i<lg.gr.length;i++){
			
			lg.gr[i].edges=null;
			lg.gr[i].nodes=null;
			lg.gr[i].ev=null;
			lg.gr[i]=null;
		}
		for(int i=0;i<lg.hp.length;i++){
			
			lg.hp[i].argnd=null;
			lg.hp[i].forestnd=null;
			lg.hp[i].treend=null;
			lg.hp[i].st=null;
			lg.hp[i].end=null;
			lg.hp[i].hp=null;
			lg.hp[i]=null;
		}
		for(int i=0;i<lg.ev.length;i++){
			
			lg.ev[i].adedarg=null;
			lg.ev[i].adedfr=null;
			lg.ev[i].adedtr=null;
			lg.ev[i].adndarg=null;
			lg.ev[i].adndfr=null;
			lg.ev[i].adndtr=null;
			lg.ev[i].adTree=null;
			lg.ev[i].arg=null;
			lg.ev[i].child_hp=null;
			lg.ev[i].ed=null;
			lg.ev[i].event_site=null;
			lg.ev[i].fr=null;
			lg.ev[i].fr=null;
			lg.ev[i].hp=null;
			lg.ev[i].ko=null;
			lg.ev[i].oya1=null;
			lg.ev[i].oya2=null;
			lg.ev[i].parent_hp=null;
			lg.ev[i].rmedarg=null;
			lg.ev[i].rmedfr=null;
			lg.ev[i].rmedtr=null;
			lg.ev[i].rmndarg=null;
			lg.ev[i].rmndfr=null;
			lg.ev[i].rmndtr=null;
			lg.ev[i].rmTree=null;
			lg.ev[i]=null;
		}
		lg=null;
		tmpev = null;
		tmphaplotype = null;
		tmpnd = null;
		tmped = null;
		tmpgr = null;
		tmpgr2 = null;
		grall = null;
		tmpgr_2 = null;
		
		return retst;
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}

	public static String run4_2(int numsnp_,int iter,LogMult log,String indir,String infile,String outdir,String outfile, int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		
		Retrograde_Parameters rpara = new Retrograde_Parameters();
		
		
		int iteration = rpara.iteration;
		int num_iteration = rpara.num_iteration;
		double recratio = rpara.recratio;
		int max_iter = rpara.max_iter;
		int backrecdepth = rpara.backrecdepth;
		
		//int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int numsnp = numsnp_;//SNP�̐��A�z�񒷂ɂ�����
		/*
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		*/
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
//		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String rootdir = outdir;
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];	
		//String file = "/home/zumiaki/java/RetroGradetHP3toROOTnoFileAug22/tAvEnter/poolhaplotype";
		
		
		//Yamada's modify Aug24
		//String file = args[0];
		/*
		String file;
		String dir="C:\\retrohaplotype\\";
		String infile="poolhaplotype";
		
		file = dir + infile;
		*/
		String file = indir + infile;
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		//System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		//System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		//System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			//System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		//MultiTrial Log�o�^
		
		log.totalnd[iter]=tmpgr2[1].nodes.length;
		log.totaled[iter]=tmpgr2[1].edges.length;
		
		//Node type
		int nodetype[]=GraphStat.NodeType(tmpgr2[1]);
		log.root[iter]=nodetype[0];
		log.mutant[iter]=nodetype[1];
		log.rec[iter]=nodetype[2];
		
		//Event�W�v
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		log.numevent[iter]=num0+num1+num2+num3+num4;
		log.mut_new[iter]=num0;
		log.mut_new[iter]=num1;
		log.rec_new[iter]=num3;
		log.rec_no_new[iter]=num4;
		
		//haplotype���Ƃ̏W�v
		for(int i=0;i<lg.startHaplotype.length;i++){
			tmpnd=lg.startHaplotype[i].argnd;
			int ndtype=TaVtoGML.nodeType(tmpnd);
			if(ndtype==0){
				log.roots[i]++;
			}else if(ndtype==1){
				log.muts[i]++;
			}else if(ndtype==2){
				log.recs[i]++;
			}
			log.numedges[i][iter]=tmpnd.edge.length;
		}
		
		//haplotype�ԋ����̎Z�o
		log.distanceHpDir[iter]=GraphStat.dijkstra(tmpgr2[1],0);
		log.distanceHpNoDir[iter]=GraphStat.dijkstra(tmpgr2[1],1);
		
		
		
		//lg.printAll();
		//lg.printRetroMR();
		//lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		//System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outdir + "\\Graph_gmls\\"  + outfile + "_"+iter+ ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        //TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		xmlfile = outdir + "\\Graphs\\" + outfile + "_"+iter+".xml";//�m�[�h�E�G�b�W�̏��͍ڂ����A�����̃O���t�̏�����ׂ�̂Ɏg��
		String xmlfile_n_e = outdir + "\\Graph_n_es\\" + outfile + "_"+iter+"_n_e.xml";//Graph�̃m�[�h�E�G�b�W�̏��𓋍�
		String xmlfile_nd = outdir + "\\Nodes\\" + outfile + "_"+iter+"_nd.xml";
		String xmlfile_ed = outdir + "\\Edges\\" + outfile + "_"+iter+"_ed.xml";
		
		String outxml ="";//xmlfile�p
		String outxml_n_e="";
		outxml+=OutXML.HeaderXML();
		outxml_n_e+=OutXML.HeaderXML();
		
		
		outxml_n_e+="<!DOCTYPE Graph [\n";
		outxml_n_e+="<!ENTITY node SYSTEM \""+xmlfile_nd+"\">";	
		outxml_n_e+="<!ENTITY edge SYSTEM \""+xmlfile_ed+"\">";
		outxml_n_e+="]>";
		
		
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml_n_e+=OutXML.GraphHeaderXML();
		
		//outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		//outxml+=OutXML.Graph2XMLiter(iter,tmpgr2[1],0,lg.numsnp,lg);
		//Graph�̏����ڂ���
		outxml+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		outxml_n_e+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		//GML�e�L�X�g���ڂ���
		outxml+="<GML>\n" + text + "\n</GML>\n";
		outxml_n_e+="<GML>\n" + text + "\n</GML>\n";
		//Node��XML������A������ڂ���
		outxml_n_e+="&node"+";\n";
		//Edge��XML������A������ڂ���
		outxml_n_e+="&edge" + ";\n";
		outxml+=OutXML.GraphFooterXML();
		outxml_n_e+=OutXML.GraphFooterXML();
		//Node��xml�p��String
		String xml_nd="";
		//xml_nd+=OutXML.HeaderXML();
		xml_nd+=OutXML.NodeHeaderXML();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			xml_nd += "<Node>\n";
			xml_nd+= OutXML.Node2XMLTab(tmpgr2[1].nodes[i],1,lg.numsnp);
			xml_nd += "\n</Node>\n";
		}
		xml_nd+=OutXML.NodeFooterXML();
		//Edge��xml�p��String
		String xml_ed="";
		//xml_ed+=OutXML.HeaderXML();
		xml_ed+=OutXML.EdgeHeaderXML();
		for(int i=0;i<tmpgr2[1].edges.length;i++){
			xml_ed+="<Edge>\n";
			xml_ed+= OutXML.Edge2XMLTab(tmpgr2[1].edges[i],1);
			xml_ed+="\n</Edge>\n";
		}
		xml_ed+=OutXML.EdgeFooterXML();
		
		
		OutXML.out2File(xmlfile,outxml);
		OutXML.out2File(xmlfile_n_e,outxml_n_e);
		OutXML.out2File(xmlfile_nd,xml_nd);
		OutXML.out2File(xmlfile_ed,xml_ed);
		
		//return�p��String���쐬����
		String retst="";
		retst +=OutXML.Graph2XMLnoID(tmpgr2[1],0,lg.numsnp,lg);
		
		
		//�P���s�I������Ƃ���ŁAlog�ȊO��S��null�ɂ���
		for(int i=0;i<lg.nd.length;i++){
			
			lg.nd[i].edge=null;
			lg.nd[i].hp=null;
			lg.nd[i].ev=null;
			lg.nd[i].gr=null;
			lg.nd[i]=null;
		}
		for(int i=0;i<lg.ed.length;i++){
			
			lg.ed[i].end=null;
			lg.ed[i].start=null;
			lg.ed[i].ev=null;
			lg.ed[i].gr=null;
			lg.ed[i]=null;
		}
		for(int i=0;i<lg.gr.length;i++){
			
			lg.gr[i].edges=null;
			lg.gr[i].nodes=null;
			lg.gr[i].ev=null;
			lg.gr[i]=null;
		}
		for(int i=0;i<lg.hp.length;i++){
			
			lg.hp[i].argnd=null;
			lg.hp[i].forestnd=null;
			lg.hp[i].treend=null;
			lg.hp[i].st=null;
			lg.hp[i].end=null;
			lg.hp[i].hp=null;
			lg.hp[i]=null;
		}
		for(int i=0;i<lg.ev.length;i++){
			
			lg.ev[i].adedarg=null;
			lg.ev[i].adedfr=null;
			lg.ev[i].adedtr=null;
			lg.ev[i].adndarg=null;
			lg.ev[i].adndfr=null;
			lg.ev[i].adndtr=null;
			lg.ev[i].adTree=null;
			lg.ev[i].arg=null;
			lg.ev[i].child_hp=null;
			lg.ev[i].ed=null;
			lg.ev[i].event_site=null;
			lg.ev[i].fr=null;
			lg.ev[i].fr=null;
			lg.ev[i].hp=null;
			lg.ev[i].ko=null;
			lg.ev[i].oya1=null;
			lg.ev[i].oya2=null;
			lg.ev[i].parent_hp=null;
			lg.ev[i].rmedarg=null;
			lg.ev[i].rmedfr=null;
			lg.ev[i].rmedtr=null;
			lg.ev[i].rmndarg=null;
			lg.ev[i].rmndfr=null;
			lg.ev[i].rmndtr=null;
			lg.ev[i].rmTree=null;
			lg.ev[i]=null;
		}
		lg=null;
		tmpev = null;
		tmphaplotype = null;
		tmpnd = null;
		tmped = null;
		tmpgr = null;
		tmpgr2 = null;
		grall = null;
		tmpgr_2 = null;
		
		return retst;
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}
	
	/*
	 * run5��WF�V�~�����[�V�����̏o�̓t�@�C���`������̓t�@�C���`���Ƃ���
	 */
	public static String run5(int[] hpid_,int[] hpfreq_,IntArray4Hp[] specifiedHp_,int iter,LogMult log,String indir,String infile,String outdir,String outfile, int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		int specifiedHp[][];
		int hpid[];
		int hpfreq[];
		
		String file = indir + infile;
		FileReader fr = null;
		try{
			 fr = new FileReader(file);
			 System.out.println("A");
			 BufferedReader objBr=new BufferedReader(fr);
			 System.out.println("A");
			 int fileline=0;
				while(objBr.ready()){
					fileline++;
					int tokennum=0;
					StringTokenizer objTkn=new StringTokenizer(objBr.readLine(),"\t");
					while(objTkn.hasMoreTokens()){
						 System.out.println("file line " + fileline +
						 		" tokennum " + objTkn.nextToken());
						tokennum++;							   
					}
				}
				objBr.close();
		}catch(IOException e){
			System.out.println(e);
		}
		
		
		
		
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}

		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		lg.numsnp=haplinecol[1];
		
		//System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		//System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		//System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			//System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		//MultiTrial Log�o�^
		
		log.totalnd[iter]=tmpgr2[1].nodes.length;
		log.totaled[iter]=tmpgr2[1].edges.length;
		
		//Node type
		int nodetype[]=GraphStat.NodeType(tmpgr2[1]);
		log.root[iter]=nodetype[0];
		log.mutant[iter]=nodetype[1];
		log.rec[iter]=nodetype[2];
		
		//Event�W�v
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		log.numevent[iter]=num0+num1+num2+num3+num4;
		log.mut_new[iter]=num0;
		log.mut_new[iter]=num1;
		log.rec_new[iter]=num3;
		log.rec_no_new[iter]=num4;
		
		//haplotype���Ƃ̏W�v
		for(int i=0;i<lg.startHaplotype.length;i++){
			tmpnd=lg.startHaplotype[i].argnd;
			int ndtype=TaVtoGML.nodeType(tmpnd);
			if(ndtype==0){
				log.roots[i]++;
			}else if(ndtype==1){
				log.muts[i]++;
			}else if(ndtype==2){
				log.recs[i]++;
			}
			log.numedges[i][iter]=tmpnd.edge.length;
		}
		
		//haplotype�ԋ����̎Z�o
		log.distanceHpDir[iter]=GraphStat.dijkstra(tmpgr2[1],0);
		log.distanceHpNoDir[iter]=GraphStat.dijkstra(tmpgr2[1],1);
		
		
		
		//lg.printAll();
		//lg.printRetroMR();
		//lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		//System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outdir + "\\Graph_gmls\\"  + outfile + "_"+iter+ ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        //TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		xmlfile = outdir + "\\Graphs\\" + outfile + "_"+iter+".xml";//�m�[�h�E�G�b�W�̏��͍ڂ����A�����̃O���t�̏�����ׂ�̂Ɏg��
		String xmlfile_n_e = outdir + "\\Graph_n_es\\" + outfile + "_"+iter+"_n_e.xml";//Graph�̃m�[�h�E�G�b�W�̏��𓋍�
		String xmlfile_nd = outdir + "\\Nodes\\" + outfile + "_"+iter+"_nd.xml";
		String xmlfile_ed = outdir + "\\Edges\\" + outfile + "_"+iter+"_ed.xml";
		
		String outxml ="";//xmlfile�p
		String outxml_n_e="";
		outxml+=OutXML.HeaderXML();
		outxml_n_e+=OutXML.HeaderXML();
		
		
		outxml_n_e+="<!DOCTYPE Graph [\n";
		outxml_n_e+="<!ENTITY node SYSTEM \""+xmlfile_nd+"\">";	
		outxml_n_e+="<!ENTITY edge SYSTEM \""+xmlfile_ed+"\">";
		outxml_n_e+="]>";
		
		
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml_n_e+=OutXML.GraphHeaderXML();
		
		//outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		//outxml+=OutXML.Graph2XMLiter(iter,tmpgr2[1],0,lg.numsnp,lg);
		//Graph�̏����ڂ���
		outxml+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		outxml_n_e+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		//GML�e�L�X�g���ڂ���
		outxml+="<GML>\n" + text + "\n</GML>\n";
		outxml_n_e+="<GML>\n" + text + "\n</GML>\n";
		//Node��XML������A������ڂ���
		outxml_n_e+="&node"+";\n";
		//Edge��XML������A������ڂ���
		outxml_n_e+="&edge" + ";\n";
		outxml+=OutXML.GraphFooterXML();
		outxml_n_e+=OutXML.GraphFooterXML();
		//Node��xml�p��String
		String xml_nd="";
		//xml_nd+=OutXML.HeaderXML();
		xml_nd+=OutXML.NodeHeaderXML();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			xml_nd += "<Node>\n";
			xml_nd+= OutXML.Node2XMLTab(tmpgr2[1].nodes[i],1,lg.numsnp);
			xml_nd += "\n</Node>\n";
		}
		xml_nd+=OutXML.NodeFooterXML();
		//Edge��xml�p��String
		String xml_ed="";
		//xml_ed+=OutXML.HeaderXML();
		xml_ed+=OutXML.EdgeHeaderXML();
		for(int i=0;i<tmpgr2[1].edges.length;i++){
			xml_ed+="<Edge>\n";
			xml_ed+= OutXML.Edge2XMLTab(tmpgr2[1].edges[i],1);
			xml_ed+="\n</Edge>\n";
		}
		xml_ed+=OutXML.EdgeFooterXML();
		
		
		OutXML.out2File(xmlfile,outxml);
		OutXML.out2File(xmlfile_n_e,outxml_n_e);
		OutXML.out2File(xmlfile_nd,xml_nd);
		OutXML.out2File(xmlfile_ed,xml_ed);
		
		//return�p��String���쐬����
		String retst="";
		retst +=OutXML.Graph2XMLnoID(tmpgr2[1],0,lg.numsnp,lg);
		
		
		//�P���s�I������Ƃ���ŁAlog�ȊO��S��null�ɂ���
		for(int i=0;i<lg.nd.length;i++){
			
			lg.nd[i].edge=null;
			lg.nd[i].hp=null;
			lg.nd[i].ev=null;
			lg.nd[i].gr=null;
			lg.nd[i]=null;
		}
		for(int i=0;i<lg.ed.length;i++){
			
			lg.ed[i].end=null;
			lg.ed[i].start=null;
			lg.ed[i].ev=null;
			lg.ed[i].gr=null;
			lg.ed[i]=null;
		}
		for(int i=0;i<lg.gr.length;i++){
			
			lg.gr[i].edges=null;
			lg.gr[i].nodes=null;
			lg.gr[i].ev=null;
			lg.gr[i]=null;
		}
		for(int i=0;i<lg.hp.length;i++){
			
			lg.hp[i].argnd=null;
			lg.hp[i].forestnd=null;
			lg.hp[i].treend=null;
			lg.hp[i].st=null;
			lg.hp[i].end=null;
			lg.hp[i].hp=null;
			lg.hp[i]=null;
		}
		for(int i=0;i<lg.ev.length;i++){
			
			lg.ev[i].adedarg=null;
			lg.ev[i].adedfr=null;
			lg.ev[i].adedtr=null;
			lg.ev[i].adndarg=null;
			lg.ev[i].adndfr=null;
			lg.ev[i].adndtr=null;
			lg.ev[i].adTree=null;
			lg.ev[i].arg=null;
			lg.ev[i].child_hp=null;
			lg.ev[i].ed=null;
			lg.ev[i].event_site=null;
			lg.ev[i].fr=null;
			lg.ev[i].fr=null;
			lg.ev[i].hp=null;
			lg.ev[i].ko=null;
			lg.ev[i].oya1=null;
			lg.ev[i].oya2=null;
			lg.ev[i].parent_hp=null;
			lg.ev[i].rmedarg=null;
			lg.ev[i].rmedfr=null;
			lg.ev[i].rmedtr=null;
			lg.ev[i].rmndarg=null;
			lg.ev[i].rmndfr=null;
			lg.ev[i].rmndtr=null;
			lg.ev[i].rmTree=null;
			lg.ev[i]=null;
		}
		lg=null;
		tmpev = null;
		tmphaplotype = null;
		tmpnd = null;
		tmped = null;
		tmpgr = null;
		tmpgr2 = null;
		grall = null;
		tmpgr_2 = null;
		
		return retst;
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}
	
	public static String run5_2(int numsnp_,int[] hpid_,int[] hpfreq_,IntArray4Hp[] specifiedHp_,int iter,LogMult log,String indir,String infile,String outdir,String outfile, int NdLb,int EdLb,int 
			rootCol,int mutCol,int recCol,int mutEdcol,int recEdcol,int origin) {
		Log lg_sim;
		//String st[];
		//st = new String[0];
		Retrograde_Parameters rpara = new Retrograde_Parameters();
		
		
		int iteration = rpara.iteration;
		int num_iteration = rpara.num_iteration;
		double recratio = rpara.recratio;
		int max_iter = rpara.max_iter;
		int backrecdepth = rpara.backrecdepth;
		
		//int numsnp = 1000;//SNP�̐��A�z�񒷂ɂ�����
		int numsnp = numsnp_;//SNP�̐��A�z�񒷂ɂ�����
		/*
		int iteration =50;//mutation + recombination�̉�
		int num_iteration=0;
		double recratio = 0.4;//recombination - mutation �̕��z�m���@臒l������rec
		
		//lg_sim = simulation3_Retro.main(numsnp,iteration,num_iteration,recratio);
		//System.out.println("PostSimRetro1");
		//lg_sim.printAll();
		
		int max_iter = 1000;//retrograde iteration�̉�
		
		int backrecdepth = 100;//backRecNoParent�̐[��
		*/
		/*
		 * 
		 */
//		output setting C:\pajek\Pajek\Data
		//String rootdir = "C:\\pajek\\Pajek\\Data\\ry2";
		String rootdir = outdir;
		String outarg = rootdir + "\\out_arg.txt";
		String outforest = rootdir + "\\out_forest.txt";
		String outforestTr = rootdir + "\\out_forestTr.txt";
		String outfr_vine = rootdir + "\\out_fr_vine.txt";
		String outtrees = rootdir + "\\out_trees_";
		String outtrees_sf ="";
		String outpajek2 = rootdir + "\\out2.txt";
		String outevent = rootdir + "\\event.txt";
		
		
		//XML out
		
		String xmlfile = rootdir + "\\xmlout.xml";
		/*
		 * ������lg�����n�v���^�C�v�̃Z�b�g�́A�r���Ńn�v���^�C�v��drift out���Ă��Ȃ�
		 * ���ۂ�retrograde��ARG���č\�z���邽�߂ɂ́Adrift out���Č����̂���n�v���^�C�v�Z�b�g����X�^�[�g����K�v������
		 */
		
		/*
		 * �S�n�v���^�C�v�̂����A����SNP�̃A�������P�΂��̑��̏ꍇ�ɂ́A���̃}�C�i�[�A�����͂��̃n�v���^�C�v�ɐ��������̂Ƃ��A
		 * ���̃A�����𔽓]�������n�v���^�C�v�̎q�Ƃ���
		 * �e�n�v���^�C�v���Ȃ���΁A�o�^����
		 */
		Log lg;
		lg = new Log();//retrograde���L�^���邽�߂�Log
		Event tmpev;
		Haplotype tmphaplotype;
		//HaplotypeLoc tmphaplotype;
		Node tmpnd;
		Edge tmped;
		treeANDvine.Graph tmpgr;
		//graph setting
		int edgetype =1;//edge�͗L��
		
		
		
		lg.numsnp=numsnp;
		lg.iteration=iteration;
		lg.num_iteration = num_iteration;
		lg.recratio = recratio;
		lg.backrecdepth = backrecdepth;
		
		//retrograde�ɃO���t�̐��ゲ�ƂɋL�^����
		treeANDvine.Graph tmpgr2[];
		tmpgr2 = new treeANDvine.Graph[2];
		//���ׂĂ̌o�܂̑����}����邽�߂̃O���t��grall tmparr[1]
		treeANDvine.Graph grall;
		grall = new treeANDvine.Graph(lg.gr.length);
		lg.addGraph(grall);
		
		
		//�͂��߂̓n�v���^�C�v���G�b�W�Ȃ��̃m�[�h�Ƃ��ēo�^����
		
		tmpgr=new treeANDvine.Graph(lg.gr.length);//tmparr[0]
		tmpgr.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr);
		treeANDvine.Graph tmpgr_2;
		tmpgr_2 =new treeANDvine.Graph(lg.gr.length);
		tmpgr_2.range(0,numsnp,0,0,0,0);
		lg.addGraph(tmpgr_2);
		
		/* 20050822 yoshizumi*/ 
		/*
		Haplotype specifiedHp[];
		
		specifiedHp = new Haplotype[lg_sim.hp.length];
		for(int i=0;i<lg_sim.hp.length;i++){
			specifiedHp[i]=lg_sim.hp[i];
		}
		*/
		
		//�t�@�C������̃n�v���^�C�v�^�̓��͂͂���
		
		
		//Haplotype specifiedHp[];
		//specifiedHp = new Haplotype[lg_sim.hp.length];
		//for(int i=0;i<lg_sim.hp.length;i++){
		//	specifiedHp[i]=lg_sim.hp[i];
		//}
	
		//int specifiedHp[][];
		IntArray4Hp spHp[] = specifiedHp_;
		int specifiedHp[][] = new int[spHp.length][numsnp_];
		for(int i=0;i<spHp.length;i++){
			for(int j=0;j<numsnp_;j++){
				specifiedHp[i][j]=0;
			}
			for(int j=0;j<spHp[i].arr.length;j++){
				specifiedHp[i][spHp[i].arr[j]]=1;
			}
		}
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println("length " + specifiedHp[i].length);
			for(int j=0;j<specifiedHp[i].length;j++){
				System.out.println(specifiedHp[i][j]);
			}
			//System.out.println("\n");
		}
		int test=0;
		while(true){
			test++;
			if(test<0)break;
		}
		int hpid[] = hpid_;
		int hpfreq[]=hpfreq_;
		


		/*
		String file = indir + infile;
		FileReader fr = null;
		try{
			 fr = new FileReader(file);
			 System.out.println("A");
			 BufferedReader objBr=new BufferedReader(fr);
			 System.out.println("A");
			 int fileline=0;
				while(objBr.ready()){
					fileline++;
					int tokennum=0;
					StringTokenizer objTkn=new StringTokenizer(objBr.readLine(),"\t");
					while(objTkn.hasMoreTokens()){
						 System.out.println("file line " + fileline +
						 		" tokennum " + objTkn.nextToken());
						tokennum++;							   
					}
				}
				objBr.close();
		}catch(IOException e){
			System.out.println(e);
		}
		
		
		
		
		int haplinecol[]={0,0};
		try{
			haplinecol=MiscUtilRY.lineCol(file);
		}catch(IOException e){
			System.out.println(e);
		}
		tAvEnter.PoolhapRead phread= new tAvEnter.PoolhapRead();	
		specifiedHp = new int[0][0];
		try{
			specifiedHp = phread.poolhap(file);
		}catch(IOException e){
			System.out.println(e);
		}
		*/
		/*System.out.println("Check##############################################");
		for(int i=0;i<specifiedHp.length;i++){
			System.out.println(i+"banme");
			for(int j=0; j<specifiedHp[i].length;j++){
				System.out.print(specifiedHp[i][j]+"; ");
			}
			System.out.println("");
		}*/

		//System.out.println("pre function " +specifiedHp.length);
		//specifiedHp = MiscUtil.specifyHpList(specifiedHp);
		//System.out.println("post function " +specifiedHp.length);
		lg.numRetroStartNode=specifiedHp.length;
		//lg.numRetroStartNode=spHp.length;
		
		//lg.numsnp=haplinecol[1];
		lg.numsnp=numsnp_;
		System.out.println("lg.numsnp " + lg.numsnp);
		//System.out.println("Hapfile line col " + haplinecol[0] + " " + haplinecol[1]);
		
		for(int i=0;i<specifiedHp.length;i++){
		System.out.println("spHp.len " + spHp.length);
		//for(int i=0;i<spHp.length;i++){
			//tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i].hp);
			tmphaplotype=new Haplotype(lg.hp.length,specifiedHp[i]);
			/*
			System.out.println("i len " + i + " " + spHp[i].arr.length);
			if(spHp[i].arr.length==0){
				int[] tmp = new int[0];
				
				tmphaplotype=new Haplotype(lg.hp.length,tmp);
			}else{
				tmphaplotype=new Haplotype(lg.hp.length,spHp[i].arr);
			}
			*/
			
			lg.addHaplotype(tmphaplotype);
			int st[]={0};
			int end[]={lg.numsnp-1};
			tmphaplotype.addStEnd(st,end);
			tmpnd = new Node(lg.nd.length,tmpgr,tmpgr.nodes.length);
			tmphaplotype.addForestNode(tmpnd);
			tmpnd.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd);
			tmpgr.addNode(tmpgr,tmpnd);
			
			Node tmpnd2;
			tmpnd2 = new Node(lg.nd.length,tmpgr_2,tmpgr_2.nodes.length);
			tmphaplotype.addArgNode(tmpnd2);
			tmpnd2.addHaplotype(tmphaplotype);
			//int numsnp = tmpnd.hp[0].hp.length;
			//System.out.println("!!!!!!!!!!!numsnp " + numsnp);
			//lg.addHaplotype(tmphaplotype);
			lg.addNode(tmpnd2);
			tmpgr_2.addNode(tmpgr_2,tmpnd2);
			
		}
		lg.numRetroStartNode=lg.hp.length;
		//Start Nodelist
		lg.startNode = lg.nd;
		lg.startHaplotype=lg.hp;
		/*
		//����n�v���^�C�v�̃m�[�h���P��
		System.out.println("pre$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		RetroProcess.removeVertexSameHp(lg,tmpgr);
		RetroProcess.removeVertexSameHp(lg,tmpgr_2);
		System.out.println("post$$$$$$$$$$$$$ " + tmpgr.nodes.length);
		/*
		//grhist=MiscUtil.addGraphArr(grhist, tmpgr);
		//tmpgr.copy(lg,grall,tmpgr);
		//grall.range(0,numsnp,0,0,0,0);
		/*
		for(int i=0;i<tmpgr.nodes.length;i++){
			tmpgr.nodes[i].hp[0].addArgNode(grall.nodes[i]);
			
			//System.out.println("node's edge len " + tmpgr.nodes[i].edge.length);
		}
		*/
		//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
		//System.out.println("Haplotype�Z�b�g��" + grhist.length);
		
		//grhist[0].printGraphAllNodeEdge();
		tmpgr2[0]=tmpgr;
		
		//tmpgr2[1]=grall;
		tmpgr2[1]=tmpgr_2;
		
		//System.out.println("kkkkkkkkkkkkkkkkkkk");
		//lg.printAll();
		//tmpgr2[0].printGraphAll();
		//lg.printAll();
		//tmpgr2[1].printGraphAll();
		//System.out.println("wwwwwwwwwwwwwwwwwwwwwwwww");
		boolean loop = false;
		//loop = tmpgr2[1].judgeARGComplete();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			//tmpgr2[1].nodes[i].hp[0].printHaplotypeElem();
		}
		loop = tmpgr2[1].connectedGraph();
		int cnt_iter=0;
		int onemore=0;
		while(loop==false){
			
			
			tmpgr=new treeANDvine.Graph(lg.gr.length);
			tmpgr.range(0,numsnp,0,0,0,0);
			lg.addGraph(tmpgr);
			tmpgr2 = tmpgr2[0].retroUp(lg,tmpgr2[0],tmpgr2[1]);
			//System.out.println("iteration num " + cnt_iter + "loop " + loop);
			//tmpgr2[1].printGraphAllNodeEdge();
			//tmpgr2[0].printGraphAllNodeEdge();
			tmpgr2[1].circle();
			tmpgr2[0].circle();
			
				outtrees_sf = outtrees + cnt_iter + "_0" + ".txt";//"xxx0_0.txt"�t�@�C���͏����m�[�h���P�m�[�h�������O���t
				//tmpgr2[0].outVGJ_noLabel(outtrees_sf);
				outtrees_sf = outtrees + cnt_iter + "_1" + ".txt";//���߂�Back��BackMut�������ꍇ�A"xxx0_1.txt"�t�@�C���͏����m�[�h�Ɠ����̃m�[�h�ƂP�G�b�W�̃O���t
				//tmpgr2[1].outVGJ_noLabel(outtrees_sf);
			//grhist=tmpgr.addToGraphArr(grhist,tmpgr);
			//System.out.println("grhist�̒����@"+ grhist.length);
			//loop = tmpgr2[1].judgeARGComplete();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			//connected�ɂȂ��Ă�recombination�̐e��rec�łȂ����Ă��邾���ł́AARG�͊������Ȃ�
				//loop = tmpgr2[1].connectedGraph();//���̂Ƃ��딻�f�͂����K��false�ŕԂ��Ă���Aug13-2005
			
			if(onemore==0){
				if(tmpgr2[0].nodes.length==1){
					max_iter=cnt_iter+1;
					onemore=1;
				}
			}
			
			
			
			
			cnt_iter++;//�����܂ŉ񂵑�����Ƃ��́A�������R�����g�A�E�g
			if(cnt_iter>=max_iter){
				loop=true;
			}
		}
		
		//MultiTrial Log�o�^
		
		log.totalnd[iter]=tmpgr2[1].nodes.length;
		log.totaled[iter]=tmpgr2[1].edges.length;
		
		//Node type
		int nodetype[]=GraphStat.NodeType(tmpgr2[1]);
		log.root[iter]=nodetype[0];
		log.mutant[iter]=nodetype[1];
		log.rec[iter]=nodetype[2];
		
		//Event�W�v
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		log.numevent[iter]=num0+num1+num2+num3+num4;
		log.mut_new[iter]=num0;
		log.mut_new[iter]=num1;
		log.rec_new[iter]=num3;
		log.rec_no_new[iter]=num4;
		
		//haplotype���Ƃ̏W�v
		for(int i=0;i<lg.startHaplotype.length;i++){
			tmpnd=lg.startHaplotype[i].argnd;
			int ndtype=TaVtoGML.nodeType(tmpnd);
			if(ndtype==0){
				log.roots[i]++;
			}else if(ndtype==1){
				log.muts[i]++;
			}else if(ndtype==2){
				log.recs[i]++;
			}
			log.numedges[i][iter]=tmpnd.edge.length;
		}
		
		//haplotype�ԋ����̎Z�o
		log.distanceHpDir[iter]=GraphStat.dijkstra(tmpgr2[1],0);
		log.distanceHpNoDir[iter]=GraphStat.dijkstra(tmpgr2[1],1);
		
		
		
		//lg.printAll();
		//lg.printRetroMR();
		//lg.printRetroHp();
		boolean connection = tmpgr2[1].connectedGraph();
		//System.out.println("final ARG is connected? " + connection);
		Node rootNd[] = tmpgr2[1].listRootNode();
		String st = "root node num " + rootNd.length + "\n";
		for(int i=0;i<rootNd.length;i++){
			st += rootNd[i] +" ";
			
		}
		//System.out.println(st);
		
//		GMLlexer
		String text=tmpgr2[1].outVGJtoSt();
		//text = TaVtoGML.outVGJtoSt2(tmpgr2[1],2,1,3,1,2,0,3,lg.numsnp);
		//text = TaVtoGML.outVGJtoSt3(tmpgr2[1],3,1,3,1,2,0,3,lg.numsnp,1,lg.startNode);
		text = TaVtoGML.outVGJtoSt4(tmpgr2[1],NdLb,EdLb,
				rootCol,mutCol,recCol,mutEdcol,recEdcol,lg.numsnp,origin,lg.startHaplotype);
		
		String outgml=outdir + "\\Graph_gmls\\"  + outfile + "_"+iter+ ".gml";
		OutXML.out2File(outgml,text);
		
//		�E�B���h�E
        //TaVtoGML.String2GraphWindow(text);
        
//      XMLtest
		xmlfile = outdir + "\\Graphs\\" + outfile + "_"+iter+".xml";//�m�[�h�E�G�b�W�̏��͍ڂ����A�����̃O���t�̏�����ׂ�̂Ɏg��
		String xmlfile_n_e = outdir + "\\Graph_n_es\\" + outfile + "_"+iter+"_n_e.xml";//Graph�̃m�[�h�E�G�b�W�̏��𓋍�
		String xmlfile_nd = outdir + "\\Nodes\\" + outfile + "_"+iter+"_nd.xml";
		String xmlfile_ed = outdir + "\\Edges\\" + outfile + "_"+iter+"_ed.xml";
		
		String outxml ="";//xmlfile�p
		String outxml_n_e="";
		outxml+=OutXML.HeaderXML();
		outxml_n_e+=OutXML.HeaderXML();
		
		
		outxml_n_e+="<!DOCTYPE Graph [\n";
		outxml_n_e+="<!ENTITY node SYSTEM \""+xmlfile_nd+"\">";	
		outxml_n_e+="<!ENTITY edge SYSTEM \""+xmlfile_ed+"\">";
		outxml_n_e+="]>";
		
		
		//outxml+=OutXML.DTDGraph();
		outxml+=OutXML.GraphHeaderXML();
		outxml_n_e+=OutXML.GraphHeaderXML();
		
		//outxml+=OutXML.Graph2XML(tmpgr2[1],0,lg.numsnp,lg);
		//outxml+=OutXML.Graph2XMLiter(iter,tmpgr2[1],0,lg.numsnp,lg);
		//Graph�̏����ڂ���
		outxml+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		outxml_n_e+=OutXML.Graph2XMLiter2(iter,tmpgr2[1],0,lg.numsnp,lg);
		//GML�e�L�X�g���ڂ���
		outxml+="<GML>\n" + text + "\n</GML>\n";
		outxml_n_e+="<GML>\n" + text + "\n</GML>\n";
		//Node��XML������A������ڂ���
		outxml_n_e+="&node"+";\n";
		//Edge��XML������A������ڂ���
		outxml_n_e+="&edge" + ";\n";
		outxml+=OutXML.GraphFooterXML();
		outxml_n_e+=OutXML.GraphFooterXML();
		//Node��xml�p��String
		String xml_nd="";
		//xml_nd+=OutXML.HeaderXML();
		xml_nd+=OutXML.NodeHeaderXML();
		for(int i=0;i<tmpgr2[1].nodes.length;i++){
			xml_nd += "<Node>\n";
			xml_nd+= OutXML.Node2XMLTab(tmpgr2[1].nodes[i],1,lg.numsnp);
			xml_nd += "\n</Node>\n";
		}
		xml_nd+=OutXML.NodeFooterXML();
		//Edge��xml�p��String
		String xml_ed="";
		//xml_ed+=OutXML.HeaderXML();
		xml_ed+=OutXML.EdgeHeaderXML();
		for(int i=0;i<tmpgr2[1].edges.length;i++){
			xml_ed+="<Edge>\n";
			xml_ed+= OutXML.Edge2XMLTab(tmpgr2[1].edges[i],1);
			xml_ed+="\n</Edge>\n";
		}
		xml_ed+=OutXML.EdgeFooterXML();
		
		
		OutXML.out2File(xmlfile,outxml);
		OutXML.out2File(xmlfile_n_e,outxml_n_e);
		OutXML.out2File(xmlfile_nd,xml_nd);
		OutXML.out2File(xmlfile_ed,xml_ed);
		
		//return�p��String���쐬����
		String retst="";
		retst +=OutXML.Graph2XMLnoID(tmpgr2[1],0,lg.numsnp,lg);
		
		
		//�P���s�I������Ƃ���ŁAlog�ȊO��S��null�ɂ���
		for(int i=0;i<lg.nd.length;i++){
			
			lg.nd[i].edge=null;
			lg.nd[i].hp=null;
			lg.nd[i].ev=null;
			lg.nd[i].gr=null;
			lg.nd[i]=null;
		}
		for(int i=0;i<lg.ed.length;i++){
			
			lg.ed[i].end=null;
			lg.ed[i].start=null;
			lg.ed[i].ev=null;
			lg.ed[i].gr=null;
			lg.ed[i]=null;
		}
		for(int i=0;i<lg.gr.length;i++){
			
			lg.gr[i].edges=null;
			lg.gr[i].nodes=null;
			lg.gr[i].ev=null;
			lg.gr[i]=null;
		}
		for(int i=0;i<lg.hp.length;i++){
			
			lg.hp[i].argnd=null;
			lg.hp[i].forestnd=null;
			lg.hp[i].treend=null;
			lg.hp[i].st=null;
			lg.hp[i].end=null;
			lg.hp[i].hp=null;
			lg.hp[i]=null;
		}
		for(int i=0;i<lg.ev.length;i++){
			
			lg.ev[i].adedarg=null;
			lg.ev[i].adedfr=null;
			lg.ev[i].adedtr=null;
			lg.ev[i].adndarg=null;
			lg.ev[i].adndfr=null;
			lg.ev[i].adndtr=null;
			lg.ev[i].adTree=null;
			lg.ev[i].arg=null;
			lg.ev[i].child_hp=null;
			lg.ev[i].ed=null;
			lg.ev[i].event_site=null;
			lg.ev[i].fr=null;
			lg.ev[i].fr=null;
			lg.ev[i].hp=null;
			lg.ev[i].ko=null;
			lg.ev[i].oya1=null;
			lg.ev[i].oya2=null;
			lg.ev[i].parent_hp=null;
			lg.ev[i].rmedarg=null;
			lg.ev[i].rmedfr=null;
			lg.ev[i].rmedtr=null;
			lg.ev[i].rmndarg=null;
			lg.ev[i].rmndfr=null;
			lg.ev[i].rmndtr=null;
			lg.ev[i].rmTree=null;
			lg.ev[i]=null;
		}
		lg=null;
		tmpev = null;
		tmphaplotype = null;
		tmpnd = null;
		tmped = null;
		tmpgr = null;
		tmpgr2 = null;
		grall = null;
		tmpgr_2 = null;
		
		return retst;
		//System.out.println(outxml);
		/*
		//String text = textarea_.getText();
        StringBufferInputStream stream = new StringBufferInputStream(text);
        GMLlexer gmlLex = new GMLlexer(stream);
		//GMLlexer gmlLex=new GMLlexer(lexer);
        
        auburn.VGJ.graph.Graph graph_ = new auburn.VGJ.graph.Graph();
        boolean update = true;
        GraphUpdate update_;
        auburn.VGJ.graph.Graph newgraph = null;
        try
        {
           GMLobject GMLgraph = new GMLobject(gmlLex, null);
           GMLobject GMLtmp;
        
           // If the GML doesn't contain a graph, assume it is a graph.
           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
           if(GMLtmp != null)
              GMLgraph = GMLtmp;
           newgraph = new Graph(GMLgraph);
        
           graph_.copy(newgraph);
           //update_.update(true);
        }
        
        
           catch(ParseError error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage() +
                                                  " at line " + lexer.getLineNumber() + " at or near \""
                                                  + lexer.getStringval() + "\".", true);
              return true;
              */
		/*
           }
           catch(IOException error)
           {
           */
           	/*
              MessageDialog dg = new MessageDialog(this,
                                                  "Error", error.getMessage(), true);
              return true;
              */
		/*
           }
        
        
        
        //GraphWindow���J��
        
        //GraphWindow gw=new GraphWindow(newgraph);
           GraphWindow gw;
           gw = buildWindow_(newgraph);
        gw.pack();
        gw.show();
        */
        
        
	}
	
	
	private static GraphWindow buildWindow_(Graph gr_)
    {
		int appCount_ = 0;  	
		// Bring up an undirected graph editor window.
          
          	// The parameter to GraphWindow() indicates directed
          	// or undirected.
             //GraphWindow graph_editing_window = new GraphWindow(true);
		GraphWindow graph_editing_window = new GraphWindow(gr_);
          	// Here the algorithms are added.
             graph_editing_window.addAlgorithmMenu("Tree");
          
             ExampleAlg2 alg2 = new ExampleAlg2();
             graph_editing_window.addAlgorithm(alg2, "Random");
          
             TreeAlgorithm talg = new TreeAlgorithm('d');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Down");
          
             talg = new TreeAlgorithm('u');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Up");
          
             talg = new TreeAlgorithm('l');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Left");
          
             talg = new TreeAlgorithm('r');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Right");
          
          
             graph_editing_window.addAlgorithmMenu("CGD");
          
             CGDAlgorithm calg = new CGDAlgorithm();
             graph_editing_window.addAlgorithm(calg, "CGD", "CGD");
          
             calg = new CGDAlgorithm(true);
             graph_editing_window.addAlgorithm(calg, "CGD",
                "show CGD parse tree");
          
             Spring spring = new Spring();
             graph_editing_window.addAlgorithm(spring, "Spring");
          
             graph_editing_window.addAlgorithmMenu("Biconnectivity");
             BiconnectGraph make_biconnect = new BiconnectGraph(true);
             graph_editing_window.addAlgorithm (make_biconnect, 
                "Biconnectivity", "Remove Articulation Points");
             BiconnectGraph check_biconnect = new BiconnectGraph(false);
             graph_editing_window.addAlgorithm (check_biconnect, 
                "Biconnectivity", "Find Articulation Points");
          
             if (appCount_++ == 0)
                graph_editing_window.setTitle("VGJ v1.03");
             else
                graph_editing_window.setTitle("VGJ v1.03" + ": "
                   + appCount_);
          
             graph_editing_window.pack();
             graph_editing_window.show();

             return graph_editing_window;
    }

}
