/*
 * �쐬��: 2005/08/23
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;

/**
 * @author yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
public class GraphStat {
	public static int[] NodeType(treeANDvine.Graph g){
		int nodetype[]={0,0,0};//root,mutant,recombinant
		for(int i=0;i<g.nodes.length;i++){
			int numend=0;;
			for(int j=0;j<g.nodes[i].edge.length;j++){
				if(g.nodes[i].edge[j].end == g.nodes[i]){
					numend++;
				}
			}
			if(numend==0){
				nodetype[0]++;
			}else if(numend==1){
				nodetype[1]++;
			}else if(numend==2){
				nodetype[2]++;
			}
		}
		
		return nodetype;
	}

	//�G�b�W�̌������l���E�s�l������
	public static int[][] dijkstra(treeANDvine.Graph g, int dir){
		//dir=0�͌����l���Adir=1�͌����s�l��
		Node n[]=g.nodes;
		int ret[][];
		int prev[][];
		ret = new int[n.length][n.length];
		prev = new int[n.length][n.length];
		int numed=(g.edges.length+1)*10000000;
		for(int i=0;i<n.length;i++){
			for(int j=0;j<n.length;j++){
				if(i==j){
					ret[i][i]=0;
					prev[i][i]=i;
				}else{
					ret[i][j]=numed;
					
					prev[i][j]=-1;
				}
			}
			
		}
		int weight[][];
		weight = new int[n.length][n.length];
		for(int i=0;i<n.length;i++){
			for(int j=0;j<n.length;j++){
				if(i==j){
					weight[i][j]=0;
				}else{
					weight[i][j]=numed;
				}
				
			}
		}
		for(int i=0;i<g.edges.length;i++){
			Node start = g.edges[i].start;
			Node end = g.edges[i].end;
			int st=0;
			int en=0;
			for(int j=0;j<n.length;j++){
				if(start == n[j]){
					st =j;
				}
				if(end == n[j]){
					en =j;
				}
			}
			weight[st][en]=1;
			if(dir==1){
				weight[en][st]=1;
			}
		}
		for(int i=0;i<n.length;i++){
			boolean visited[];
			visited = new boolean[n.length];

			for(int j=0;j<n.length;j++){
				visited[j]=false;
			}
			
			int next=i;
			next = i;
			int j=0;
			int min=0;
			do{
				j=next;
				visited[j]=true;
				min = numed;
				for(int k=0;k<n.length;k++){
					if(visited[k]){
						
					}else{
						if(weight[j][k]<numed){
							if(ret[i][j]+weight[j][k]<ret[i][k]){
								ret[i][k]=ret[i][j]+weight[j][k];
								prev[i][k]=j;
							}
						}
						if(ret[i][k]<min){
							min=ret[i][k];
							next =k;
						}
					}
					
				}
			}while(min<numed);
			if(dir ==0)//System.out.println("�t�s�s�@����from i " + i + " ");
			if(dir==1)//System.out.println("�t�s �@����from i " + i + " ");
			for(int k=0;k<n.length;k++){
				if(ret[i][k]==numed){
					ret[i][k]=-1;
				}
				//System.out.println("k " + k + " " + ret[i][k]);
			}
			
			
		}
		
		return ret;
	}
	//�G�b�W�̌����𖳍l���B�t�s�A�B���B�s�\�͓��B�s�\
	public static int[][] dijkstraNoDir(treeANDvine.Graph g){
		Node n[]=g.nodes;
		int ret[][];
		int prev[][];
		ret = new int[n.length][n.length];
		prev = new int[n.length][n.length];
		int numed=g.edges.length+1;
		for(int i=0;i<n.length;i++){
			for(int j=0;j<n.length;j++){
				if(i==j){
					ret[i][i]=0;
					prev[i][i]=i;
				}else{
					ret[i][j]=numed;
					
					prev[i][j]=-1;
				}
			}
			
		}
		
		for(int i=0;i<n.length;i++){
			boolean visited[];
			visited = new boolean[n.length];

			for(int j=0;j<n.length;j++){
				visited[j]=false;
			}
			
			int next=i;
			next = i;
			int j=0;
			int min=0;
			do{
				j=next;
				visited[j]=true;
				min = numed;
				for(int k=0;k<n[j].edge.length;k++){
					
					if(n[j].edge[k].start==n[j] || n[j].edge[k].end==n[j]){
						int tmp = j;
					
						
						for(int l=0;l<n.length;l++){
							if(n[j].edge[k].end == n[l]){
								tmp=l;
							}
						}
						if(visited[tmp]){
							
						}else{
							if(ret[i][j]+1<ret[i][tmp]){
								ret[i][tmp]=ret[i][j]+1;
								prev[i][tmp]=j;
							}
							if(ret[i][tmp]<min){
								min=ret[i][tmp];
								next = tmp;
							}
						}
					}
				}
			}while(min<numed);
			System.out.println("�t�s�@����from i " + i + " ");
			for(int k=0;k<n.length;k++){
				if(ret[i][k]==numed){
					ret[i][k]=-1;
				}
				System.out.println("k " + k + " " + ret[i][k]);
			}
			
			
		}
		
		return ret;
	}

}
