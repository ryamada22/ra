/*
 * �쐬��: 2005/07/15
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




/**
 * @author yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
public class Cancel_WFSim2_2{
	/*
	 * WFSim�́ATreeAndVine�̂����A���F�̂�����A���̐e�q�֌W�����߂�_�ɓ�������
	 * �L�^�͐��ゲ�ƂƂ��A���ゲ�ƂɃI�u�W�F�N�g���폜���邱�Ƃŉ\�ɂ���
	 */	
	int endFlg=-1;
	String[] args;
	WrightFisherParameter_Ref wfp;
	boolean only1 = true;
	
	public Cancel_WFSim2_2(String[] args_,WrightFisherParameter_Ref wfp_){
		args = args_;
		wfp = wfp_;
        // �t���[�����쐬
        JFrame f=new JFrame("Controller");
        
        //�{�^���E�p�l�����t���[���ɓ���
        JButton b01=new JButton("Start & Restart");
        JButton b02=new JButton("Hold");
        JButton b03=new JButton("Cancel");
        b01.setActionCommand("Start & Restart");
        b01.addActionListener(new PushButtonActionListener(f));
        b02.setActionCommand("Hold");
        b02.addActionListener(new PushButtonActionListener(f));
        b03.setActionCommand("Exit");
        b03.addActionListener(new PushButtonActionListener(f));
        JPanel pb=new JPanel();
        pb.add(b01);
        pb.add(b02);
        pb.add(b03);
        f.getContentPane().add(pb);
        
        // �t���[����\��
        f.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
        f.setLocation(50, 50);
        f.setSize(300,75);
        f.setVisible(true);
        
        //�t���[���������A�v���P�[�V�����S�̂��I��
        f.addWindowListener(new WindowAdapter(){
         	public void windowClosing(WindowEvent e) {
         		//System.exit(0);
         	}
         });
	}
	
	public static void main(String[] args) {
		
		try{
//			WrightFisherParameters�ǂݍ���
			WrightFisherParameter wfp;
			wfp = new WrightFisherParameter();
			int region = wfp.region_length;
			int pop = wfp.population_size;//1���l�A���F�̂�2���{
			double nt_morgan_ratio = wfp.nt_morgan_ratio;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
			int num_gen = wfp.num_generation;
			double mut_rate = wfp.mutation_rate;
			double rec_rate = wfp.recombination_rate;
			double hapfreq4disp = wfp.hapfreq4disp;
			
			//���s���O
			//�����ʂ��ăJ�E���g
			int gen=0;//����
			int nd_tot=0;//�S���F��(node)
			int ed_tot=0;//�S�G�b�W
			int hp_nd_tot=0;
			
			
			//������ŃJ�E���g
			int num_ch=0;
			//int[][] haptype;//�n�v���^�C�v�^
			IntArray4Hp[] haptype;
			int[] num_hp;//�n�v���^�C�v���Ƃ̐l��
			int[] nd_hp;//���F�̂̃n�v���^�C�v�^
			
			//graph
			int[][] child;//oyaid���1�A�q�������2�A�l��koid
			child = null;
			int event[][];//oyaid���1�A�q�������2�A�l�̓C�x���gID
			event = null;
			int[] parent0;//koid���1�A�l��oyaid
			int[] parent1;//koid���2�A�l��oyaid2(���Ȃ����null)
			parent0=new int[pop*num_gen];
			parent1=new int[pop*num_gen];
			int[] eventtype;//eventid���1�A�^�C�v(coalescent(0),recombination(1))
			int[][] recsite;//eventid���1�A��������2�Arecombination�ʒu�̍�����ԍ����l
			int[][] mutsite;//eventid���1�A��������2�Amutation�ʒu���l
			eventtype=null;
			//recsite=null;
			mutsite=new int[pop][2];
			recsite=new int[pop][1];
			
			int pop_before;
			int[] freqhp_before;
			
			//�o�̓p�����^
			GMLoutParameters gmloutp;
			gmloutp = new GMLoutParameters();
			
			int NdLb=gmloutp.NdLb;
			int EdLb=gmloutp.EdLb;
			int rootCol=gmloutp.rootCol;
			int mutCol=gmloutp.mutCol;
			int recCol=gmloutp.recCol;
			int mutEdcol=gmloutp.mutEdcol;
			int recEdcol=gmloutp.recEdcol;
			int origin=gmloutp.origin;
			
			
			
			//output setting 
			
			String textlog="";
			String textvgj="";
			String textgen="";
			String textgenhp="";
			String textsvg="";
			
			
			String rootdir = "C:\\Java\\WrightFisher\\WFSimOut";
			//3 types(�S�́A�؂̏W�܂�A�X�̖�)�̃O���t�����t�@�C��
			//�S��
			
			String logfile=rootdir+"\\log.txt";
			String vgjfile=rootdir+"\\individual.gml";
			String svgfile=rootdir+"\\individual.svg";
			String freqsvgfile=rootdir+"\\hapfreq.svg";
			String genotypefile=rootdir+"\\hapallele_all_gen.txt";
			String freqdatafile=rootdir+"\\hapfreqdata_all_gen.txt";
			String genotypefile_last=rootdir+"\\hapallele_last_gen.txt";
			String freqdatafile_last=rootdir+"\\hapfreqdata_last_gen.txt";
			String freqvgjfile=rootdir+"\\hapfreq.gml";
			String parentchildfile =rootdir + "\\chparentchild.txt";
			String parentfile =rootdir + "\\chparent.txt";
			String childfile =rootdir + "\\chchild.txt";
			String parentchildfile2 =rootdir + "\\chparentchild2.txt";
			String parentfile2 =rootdir + "\\chparent2.txt";
			String childfile2 =rootdir + "\\chchild2.txt";
			String hpparentchildfile =rootdir + "\\hpparentchild.txt";
			String hpparentfile =rootdir + "\\hpparent.txt";
			String hpchildfile =rootdir + "\\hpchild.txt";
			String hpparentchildfile2 =rootdir + "\\hpparentchild2.txt";
			String hpparentfile2 =rootdir + "\\hpparent2.txt";
			String hpchildfile2 =rootdir + "\\hpchild2.txt";
			String hpidfile = rootdir + "\\hpid.txt";
			
			
			String haptypeFreq = rootdir + "\\haptypeFreq.txt";
			String snplist_last = rootdir + "\\snplist_last.txt";
			
			BufferedWriter bw1;
			BufferedWriter bw2;
			BufferedWriter bw3;
			BufferedWriter bw4;
			BufferedWriter bw5;
			BufferedWriter bw6;
			BufferedWriter bw7;
			BufferedWriter bw8;
			BufferedWriter bw9;
			BufferedWriter bw10;
			BufferedWriter bw11;
			BufferedWriter bw12;
			BufferedWriter bw13;
			BufferedWriter bw14;
			BufferedWriter bw15;
			BufferedWriter bw16;
			BufferedWriter bw17;
			BufferedWriter bw18;
			BufferedWriter bw19;
			BufferedWriter bw20;
			BufferedWriter bw21;
			BufferedWriter bw22;
			BufferedWriter bw23;
			
			bw1=null;
			bw2=null;
			bw3=null;
			bw4=null;
			bw5=null;
			bw6=null;
			bw7=null;
			bw8=null;
			bw9=null;
			bw10=null;
			bw11=null;
			bw12=null;
			bw13=null;
			bw14=null;
			bw15=null;
			bw16=null;
			bw17=null;
			bw18=null;
			bw19=null;
			bw20=null;
			bw21=null;
			bw22=null;
			bw23=null;
			try{
				bw1 = new BufferedWriter(new FileWriter(vgjfile));
				bw2 = new BufferedWriter(new FileWriter(svgfile));
				bw3 = new BufferedWriter(new FileWriter(genotypefile));
				bw4 = new BufferedWriter(new FileWriter(freqsvgfile));
				bw5 = new BufferedWriter(new FileWriter(freqdatafile));
				bw6 = new BufferedWriter(new FileWriter(freqvgjfile));
				bw7 = new BufferedWriter(new FileWriter(genotypefile_last));
				bw8 = new BufferedWriter(new FileWriter(freqdatafile_last));
				bw9 = new BufferedWriter(new FileWriter(parentchildfile));
				bw10 = new BufferedWriter(new FileWriter(parentfile));
				bw11 = new BufferedWriter(new FileWriter(childfile));
				bw12 = new BufferedWriter(new FileWriter(parentchildfile2));
				bw13 = new BufferedWriter(new FileWriter(parentfile2));
				bw14 = new BufferedWriter(new FileWriter(childfile2));
				bw15 = new BufferedWriter(new FileWriter(hpparentchildfile));
				bw16 = new BufferedWriter(new FileWriter(hpparentfile));
				bw17 = new BufferedWriter(new FileWriter(hpchildfile));
				bw18 = new BufferedWriter(new FileWriter(hpparentchildfile2));
				bw19 = new BufferedWriter(new FileWriter(hpparentfile2));
				bw20 = new BufferedWriter(new FileWriter(hpchildfile2));
				bw21 = new BufferedWriter(new FileWriter(hpidfile));
				bw22 = new BufferedWriter(new FileWriter(haptypeFreq));
				bw23 = new BufferedWriter(new FileWriter(snplist_last));
			}catch(Exception e){
				
				System.out.println(e);

			}
			
			/*
			String genoutroot=rootdir+"\\gen";
			
			
			String outarg = rootdir + "\\out_arg.txt";
			//�g�����ɂ�蕪�������u�؁v�̏W�܂�(�u�сv)
			String outforest = rootdir + "\\out_forest.txt";
			String outforestTr = rootdir + "\\out_forestTr.txt";
			String outfr_vine = rootdir + "\\out_fr_vine.txt";
			//�X�́u�؁v
			String outtrees = rootdir + "\\out_trees_";
			String outtrees_sf ="";
			String outpajek2 = rootdir + "\\out2.txt";
			String outevent = rootdir + "\\event.txt";
			*/
			
			//simulation settings
			//int numsnp = 200;//SNP�̐��A�z�񒷂ɂ�����
			int numsnp = wfp.region_length;//SNP�̐��A�z�񒷂ɂ�����
			//int iteration =100;//mutation + recombination�̉�
			int iteration = wfp.num_generation;//���㐔
			

			
			textvgj=TaVtoGML.outVGJtoSt5header(textvgj);
			int svgsize;
			svgsize = Math.max(pop,num_gen);
			textsvg=TaVtoGML.outSVGtoSt5header(textsvg,svgsize);
			OutXML.out3File(bw1,textvgj);
			OutXML.out3File(bw2,textsvg);
			OutXML.out3File(bw4,textsvg);
			OutXML.out3File(bw6,textvgj);
			String headerhapfreq = ">Length of region(nt)\t"+ region+"\n"
			+">No.total chromosomes\t" + pop +"\n" +
					">nt/1cM\t"+ nt_morgan_ratio +"\n"+
					">No.generation\t" + num_gen + "\n"+
					">Mutation rate\t" + mut_rate + "\n"+ 
					">Recombination rate/1cM\t"+rec_rate +"\n" +
					">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+
					"\n>Haplotype id\tNo.chromosomes\tMutation sites\n";
			OutXML.out3File(bw8,headerhapfreq);
			
			//Root
			//simulation�J�n�̃n�v���^�C�v����
//			�S���F�͕̂ψقȂ��A����n�v���^�C�v
			System.out.println("Root Generation is in progress");
			IntArray4Hp tmpintarray4hp;
			tmpintarray4hp=new IntArray4Hp();
			haptype = new IntArray4Hp[1];
			haptype[0]=tmpintarray4hp;
			//haptype[0].arr=null;
			//haptype[0][0]=-9;
			String[] genotype;
			genotype = new String[1];
			//genotype[0] = "\n";
			genotype[0] = "";
			
			nd_hp = new int[pop];
			int[] gen_tot_id;
			gen_tot_id = new int[pop];
			
			int[] nd_loc_x;
			nd_loc_x = new int[pop];
			int[] nd_loc_y;
			nd_loc_y = new int[pop];
			
			int[] hp_loc_x;
			int[] hp_loc_y;
			hp_loc_x=new int[1];
			hp_loc_y=new int[1];
			
			int[] hp_nd;
			hp_nd = new int[pop];
			//String freqdataout="generation\t" + gen + "\n";
			String freqdataout="generation\t" + gen + "\n";
			OutXML.out3File(bw5,freqdataout);
			OutXML.out3File(bw3,freqdataout);
			
			for(int i=0;i<pop;i++){
				
				nd_hp[i]=0;
				gen_tot_id[i]=nd_tot;
				String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,0,gen,i
						,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				//textvgj+=vgj;
				nd_loc_x[i]=gen*pop;
				nd_loc_y[i]=i*pop;
				OutXML.out3File(bw1,vgj);
				String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,nd_loc_x[i],nd_loc_y[i]=i*pop,0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				OutXML.out3File(bw2,svg);
				
				String hpkata = genotype[nd_hp[i]];
				//System.out.println("hpkata " + hpkata);
				hpkata +=i + "\t" + hpkata + "\n";
				OutXML.out3File(bw3,hpkata);
			
						
				nd_tot++;

			}
			pop_before = pop;
			//root generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
			
			int[] freqhp;
			freqhp = new int[haptype.length];
			for(int i=0;i<haptype.length;i++){
				freqhp[i]=0;
			}
			for(int i=0;i<nd_hp.length;i++){
				freqhp[nd_hp[i]]++;
			}
			int roothpcnt=0;
			
			for(int i=0;i<haptype.length;i++){
				if(freqhp[i]>0){
					String hpid="0\t" + roothpcnt + "\t" + i+"\n";
					OutXML.out3File(bw21,hpid);
					
					String hpkata = "";
					
					for(int k=0;k<haptype[i].arr.length;k++){
						
						hpkata += haptype[i].arr[k] + " ";
					}
					freqdataout=roothpcnt + "\t" + i +"\t" + freqhp[i] + "\t" + hpkata + "\n";
					OutXML.out3File(bw5,freqdataout);
					hp_loc_x[i]=gen*pop;
					hp_loc_y[i]=roothpcnt*pop;
					double freqdb=(double)(freqhp[i])/(double)(pop);
					String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqdb,
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					OutXML.out3File(bw4,freqsvg);
					String freqvgj=TaVtoGML.outVGJtoSt5Node_URL(hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					hp_nd[i]=hp_nd_tot;
					hp_nd_tot++;
					OutXML.out3File(bw6,freqvgj);
					
					roothpcnt++;
				}
				
			}
			freqhp_before = freqhp;
			gen++;
			
			for(int i=gen;i<num_gen;i++){
				System.out.println("Generation " + i + "/" + num_gen + " is in progress.");
				//freqdataout="generation\t" + gen + "\n";
				freqdataout="generation\t" + gen + "\n";
				OutXML.out3File(bw5,freqdataout);
				OutXML.out3File(bw3,freqdataout);
				
				int pop_now=pop;
				int[] nd_hp_tmp;
				nd_hp_tmp = new int[pop_now];
				int[] gen_tot_id_tmp;
				gen_tot_id_tmp = new int[pop_now];
				int[] nd_loc_x_tmp;
				nd_loc_x_tmp = new int[pop_now];
				int[] nd_loc_y_tmp;
				nd_loc_y_tmp = new int[pop_now];
				int[] hp_nd_tmp;
				hp_nd_tmp = new int[hp_nd.length+pop_now];
				//ch�e�q�y�A�L�^�p�A���C
				IntArray4Hp choya;
				IntArray4Hp chko;
				//hp�e�q�y�A�L�^�p�A���C
				IntArray4Hp hpoya;
				IntArray4Hp hpko;
				//haptype�u��
				IntArray4Hp[] haptype_before;
				haptype_before = haptype;
				
				choya = new IntArray4Hp();
				chko = new IntArray4Hp();
				hpoya = new IntArray4Hp();
				hpko = new IntArray4Hp();
				
				for(int j=0;j<pop;j++){
					double rand0 = Math.random();
					double rec_freq = rec_rate*region/nt_morgan_ratio;
					
					if(rand0>rec_freq){//No recombination
						double rand1 = Math.random();
						int tmpoya = (int)(rand1*nd_hp.length);
						choya.addelem(tmpoya);
						chko.addelem(j);
						
						IntArray4Hp tmp_hpkata;
						tmp_hpkata=new IntArray4Hp();
						double rand_mut = Math.random();
						if(rand_mut<=mut_rate){
							//System.out.println("mutation!!");
							double rand_mut_site = Math.random();
							int mut_site_tmp =(int)(rand_mut_site*region);
							mutsite[j][0]=mut_site_tmp;
							IntArray4Hp tmp_tmp_hpkata;
							tmp_tmp_hpkata = new IntArray4Hp();
							boolean judge=true;
							boolean judgeyet=true;
							if(haptype[nd_hp[tmpoya]].arr.length==0){
								
								tmp_tmp_hpkata.addelem(mutsite[j][0]);
								
								nd_hp_tmp[j]=haptype.length;
								IntArray4Hp[] tmp_haptype;
								tmp_haptype = new IntArray4Hp[haptype.length+1];
								for(int x=0;x<haptype.length;x++){
									tmp_haptype[x]=haptype[x];
									
								}
								tmp_haptype[haptype.length]=tmp_tmp_hpkata;
								
								haptype = null;
								haptype=tmp_haptype;
								
							}else{
								int counter=0;
								for(int k=0;k<haptype[nd_hp[tmpoya]].arr.length;k++){
									
									if(haptype[nd_hp[tmpoya]].arr[k]==mutsite[j][0]){
										
										tmp_tmp_hpkata.addelem(mutsite[j][0]);
										
										judge=false;
										judgeyet=false;
										//System.out.println("eaqual");
									}else if(haptype[nd_hp[tmpoya]].arr[k]<mutsite[j][0]){
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										//System.out.println("more than");
									}else if(haptype[nd_hp[tmpoya]].arr[k]>mutsite[j][0]){
										//System.out.println("less than");
										if(judgeyet){
											tmp_tmp_hpkata.addelem(mutsite[j][0]);
											counter++;
											judgeyet=false;
										}
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										
									
									}
									
								}
								if(judgeyet){
									//System.out.println("add");
									tmp_tmp_hpkata.addelem(mutsite[j][0]);
									counter++;
								}
								boolean noidhp=true;
								for(int x=0;x<haptype.length;x++){
									boolean identicalhp = true;
									if(haptype[x].arr.length==tmp_tmp_hpkata.arr.length){
										for(int y=0;y<tmp_tmp_hpkata.arr.length;y++){
											if(haptype[x].arr[y]!=tmp_tmp_hpkata.arr[y]){
												identicalhp=false;
												break;
											}
										}
										if(identicalhp){//�Vhptype�ł͂Ȃ�
											//nd_hp_tmp[j]=nd_hp[x];
											nd_hp_tmp[j]=x;
											noidhp=false;
											
											break;
										}
									}
								}
								if(noidhp){
									nd_hp_tmp[j]=haptype.length;
									IntArray4Hp[] tmp_haptype;
									tmp_haptype = new IntArray4Hp[haptype.length+1];
									for(int x=0;x<haptype.length;x++){
										tmp_haptype[x]=haptype[x];
										
									}
									
									tmp_haptype[haptype.length]=tmp_tmp_hpkata;
									
									haptype = null;
									haptype=tmp_haptype;
								}
							}
							if(judge){
								tmp_hpkata=tmp_tmp_hpkata;
								}
							
						}else{
							tmp_hpkata=haptype[nd_hp[tmpoya]];
							nd_hp_tmp[j]=nd_hp[tmpoya];
							
						}
						//hppair�o�^
						boolean newpair=true;
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
									//System.out.println("##�o�^���Ȃ� " + j);
									newpair=false;
								}
								
							}
						}
						if(newpair){
							hpoya.addelem(nd_hp[tmpoya]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						gen_tot_id_tmp[j]=nd_tot;
						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,1,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i*pop_now;
						nd_loc_y_tmp[j]=j*pop_now;
						//textvgj+=vgj;
						OutXML.out3File(bw1,vgj);
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,1,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw2,svg);
						
						String hpkata = j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + "\t";
						}
						hpkata += "\n";
						OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,0,gen_tot_id[tmpoya],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(0, nd_loc_x[tmpoya],nd_loc_y[tmpoya],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//textvgj+=vgj_ed;
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya];
						
						nd_tot++;
						ed_tot++;
					}else{
						//�g��������
						//System.out.println("recombination");
						double rand1 = Math.random();
						double rand2 = Math.random();
						int tmpoya1 = (int)(rand1*nd_hp.length);
						int tmpoya2 = (int)(rand2*(nd_hp.length-1));
						if(tmpoya2<=tmpoya1){
							tmpoya2++;
						}
						choya.addelem(tmpoya1);
						chko.addelem(j);
						choya.addelem(tmpoya2);
						chko.addelem(j);
						//�g�����ʒu
						double rand3 = Math.random();
						int rec = (int)(rand3*region);
						
						recsite[j][0]=rec;
						
						//�Q��oyahap�ɏ�L�Ɠ���������mutation���N�����A���̏�ŁA�V�n�v���^�C�v�����
						IntArray4Hp hptmpoya1 = haptype[nd_hp[tmpoya1]];
						IntArray4Hp hptmpoya2 = haptype[nd_hp[tmpoya2]];
						IntArray4Hp tmphap;
						tmphap = new IntArray4Hp();
						
						double rand_event1 = Math.random();
						double rand_event2 = Math.random();
						if(rand_event1<=mut_rate){
							double rand_mut_site1 = Math.random();
							int mut_site_tmp1 =(int)(rand_mut_site1*region);
							mutsite[j][0]=mut_site_tmp1;
							boolean judge1=true;
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									if(mutsite[j][0]>hptmpoya1.arr[k]){
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}else if(mutsite[j][0]==hptmpoya1.arr[k]){
										tmphap.addelem(mutsite[j][0]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
										judge1=false;
									}else if(mutsite[j][0]<hptmpoya1.arr[k]){
										if(judge1){
											tmphap.addelem(mutsite[j][0]);
											//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
											judge1=false;
										}
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}
								}
							}
							if(judge1){
								if(mutsite[j][0]<=recsite[j][0]){
									tmphap.addelem(mutsite[j][0]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}else{
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									tmphap.addelem(hptmpoya1.arr[k]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}
						if(rand_event2<=mut_rate){
							double rand_mut_site2 = Math.random();
							int mut_site_tmp2 =(int)(rand_mut_site2*region);
							mutsite[j][1]=mut_site_tmp2;
							boolean judge2=true;
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									if(mutsite[j][1]>hptmpoya2.arr[k]){
										tmphap.addelem(hptmpoya2.arr[k]);
									}else if(mutsite[j][1]==hptmpoya2.arr[k]){
										tmphap.addelem(mutsite[j][1]);
										judge2=false;
									}else if(mutsite[j][1]<hptmpoya2.arr[k]){
										if(judge2){
											tmphap.addelem(mutsite[j][1]);
											judge2=false;
										}
										tmphap.addelem(hptmpoya2.arr[k]);
									}
								}
							}
							if(judge2){
								if(mutsite[j][1]>recsite[j][0]){
									tmphap.addelem(mutsite[j][1]);
								}
							}
						}else{
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									tmphap.addelem(hptmpoya2.arr[k]);
								}
							}
						}
						
						//����haplotype�ɂ��łɑ��݂��邩
						
						boolean noidhp=true;
						//int max_mutsite=0;
						
						for(int x=0;x<haptype.length;x++){
							boolean identicalhp = true;
							if(haptype[x].arr.length==tmphap.arr.length){
								//if(haptype[x].arr.length>max_mutsite){
									//max_mutsite=haptype[x].arr.length;
								//}
								for(int y=0;y<tmphap.arr.length;y++){
									if(haptype[x].arr[y]!=tmphap.arr[y]){
										identicalhp=false;
										break;
									}
								}
								if(identicalhp){//�Vhptype�ł͂Ȃ�
									
									//nd_hp_tmp[j]=nd_hp[x];
									nd_hp_tmp[j]=x;
									
									noidhp=false;
									
									break;
								}
							}
						}
						//if(tmp_tmp_hpkata.arr.length>max_mutsite){
							//max_mutsite = tmp_tmp_hpkata.arr.length;
						//}
						if(noidhp){
							
							nd_hp_tmp[j]=haptype.length;
							IntArray4Hp[] tmp_haptype;
							tmp_haptype = new IntArray4Hp[haptype.length+1];
							for(int x=0;x<haptype.length;x++){
								tmp_haptype[x]=haptype[x];
								
							}
							
							tmp_haptype[haptype.length]=tmphap;
							
							haptype = null;
							haptype = new IntArray4Hp[tmp_haptype.length];
							haptype=tmp_haptype;
						}
//						hppair�o�^
						boolean newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya1]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya1]);
							hpko.addelem(nd_hp_tmp[j]);
						}
//						hppair�o�^
						newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya2]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya2]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						//nd_hp_tmp[j]=nd_hp[tmpoya1];//�����̓n�v���^�C�v��{�C�œo�^����Ƃ��ɂ́A�ς���
//						
						gen_tot_id_tmp[j]=nd_tot;
						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,2,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i*pop_now;
						nd_loc_y_tmp[j]=j*pop_now;
						//textvgj+=vgj;
						OutXML.out3File(bw1,vgj);
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,2,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw2,svg);
						
						
						String hpkata = "";
						hpkata +=j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + " ";
						}
						hpkata += "\n";
						OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya1],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya1],nd_loc_y[tmpoya1],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						ed_tot++;
						//textvgj+=vgj_ed;
						vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya2],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya2],nd_loc_y[tmpoya2],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya1];
						parent1[nd_tot]=gen_tot_id[tmpoya2];
						
						ed_tot++;
						nd_tot++;
					}
					
				}

				
//				���� generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
				//freqdataout="generation\t" + gen + "\n";
				//OutXML.out3File(bw5,freqdataout);
				freqhp = new int[haptype.length];
				for(int j=0;j<haptype.length;j++){
					freqhp[j]=0;
				}
				for(int j=0;j<nd_hp_tmp.length;j++){
					//System.out.println("j,nd_hp_tmp[j] "+j + " " + nd_hp_tmp[j]);
					freqhp[nd_hp_tmp[j]]++;
				}
				int hptypecnt=0;
				int[] hp_loc_x_tmp;
				int[] hp_loc_y_tmp;
				hp_loc_x_tmp = new int[haptype.length];
				hp_loc_y_tmp = new int[haptype.length];
				//System.out.println("haptype.len " + haptype.length);
				for(int j=0;j<haptype.length;j++){
					double freqdb=(double)(freqhp[j])/(double)(pop_now); 
					//if(freqhp[j]>0){
					//if(freqdb>hapfreq4disp){
						
						
						String hpkata = "";
						
						for(int k=0;k<haptype[j].arr.length;k++){
							
							hpkata += haptype[j].arr[k] + " ";
						}
						freqdataout=hptypecnt + "\t" + j+"\t" + freqhp[j] + "\t" + hpkata + "\n";
						String haplong="";
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw5,freqdataout);
							if(i==num_gen-1){
								OutXML.out3File(bw8,freqdataout);
							}
						}
						
						hp_loc_x_tmp[j]=gen*pop_now;
						hp_loc_y_tmp[j]=hptypecnt*pop_now;
						
						String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqdb,
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw4,freqsvg);
						}
						
						String freqvgj=TaVtoGML.outVGJtoSt5Node_URL(hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw6,freqvgj);
						}
						
						hp_nd_tmp[j]=hp_nd_tot;
						hp_nd_tot++;
						
						for(int k=0;k<hpoya.arr.length;k++){
							if(hpko.arr[k]==j){
								String hp_svg_ed=TaVtoGML.outSVGtoSt5Edge(1, 
										hp_loc_x[hpoya.arr[k]],hp_loc_y[hpoya.arr[k]],hp_loc_x_tmp[j],
										hp_loc_y_tmp[j],NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								if(freqdb>hapfreq4disp){
									OutXML.out3File(bw4,hp_svg_ed);
								}
								
								String hp_vgj_ed=TaVtoGML.outVGJtoSt5Edge(hp_nd_tmp[j],2,hp_nd[hpoya.arr[k]],
										NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								if(freqdb>hapfreq4disp){
									OutXML.out3File(bw6,hp_vgj_ed);
								}
								
							}
						}
						String hpid=i + "\t" + hptypecnt + "\t" + j+"\n";
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw21,hpid);
						}
						
						
						hptypecnt++;
					//}
					
				}
				//output parent,child of ch
				for(int j=0;j<pop_before;j++){
					String textchild = i-1 + "\t" + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textchild2 = i-1 + " " + j +"\t";
						if(choya.arr[k]==j){
							textchild += i + "\t" + chko.arr[k] + "\t";
							textchild2 += i + "\t" + chko.arr[k] + "\t\n";
							OutXML.out3File(bw12,"parent\t");
							OutXML.out3File(bw12,textchild2);
							
							OutXML.out3File(bw14,textchild2);
						}
					}
					textchild += "\n";
					OutXML.out3File(bw9,"parent\t");
					OutXML.out3File(bw9,textchild);
					OutXML.out3File(bw11,textchild);
				}
				for(int j=0;j<pop_now;j++){
					String textparent = i + "\t" + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textparent2 = i + "\t" + j +"\t";
						if(chko.arr[k]==j){
							textparent += i-1 + "\t" + choya.arr[k] + "\t";
							textparent2 += i-1 + "\t" + choya.arr[k] + "\t\n";
							OutXML.out3File(bw12,"child\t");
							OutXML.out3File(bw12,textparent2);
							OutXML.out3File(bw13,textparent2);
						}
					}
					textparent += "\n";
					OutXML.out3File(bw9,"child\t");
					OutXML.out3File(bw9,textparent);
					OutXML.out3File(bw10,textparent);
				}
//				output parent,child of hp
				for(int j=0;j<haptype_before.length;j++){
					if(freqhp_before[j]>0){
						String textchild = i-1 + "\t" + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textchild2 = i-1 + "\t" + j +"\t";
							if(hpoya.arr[k]==j){
								textchild += i + "\t" + hpko.arr[k] + "\t";
								textchild2 += i + "\t" + hpko.arr[k] + "\t\n";
								OutXML.out3File(bw18,"parent\t");
								OutXML.out3File(bw18,textchild2);
								
								OutXML.out3File(bw20,textchild2);
							}
						}
						textchild += "\n";
						OutXML.out3File(bw15,"parent\t");
						OutXML.out3File(bw15,textchild);
						OutXML.out3File(bw17,textchild);
					}
					
				}
				int freqhpcnt=0;
				for(int j=0;j<haptype.length;j++){
					if(freqhp[j]>0){
						String textparent = i + "\t" + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textparent2 = i + "\t" + j +"\t";
							if(hpko.arr[k]==j){
								textparent += i-1 + "\t" + hpoya.arr[k] + "\t";
								textparent2 += i-1 + "\t" + hpoya.arr[k] + "\t\n";
								OutXML.out3File(bw18,"child\t");
								OutXML.out3File(bw18,textparent2);
								OutXML.out3File(bw19,textparent2);
							}
						}
						textparent += "\n";
						OutXML.out3File(bw15,"child\t");
						OutXML.out3File(bw15,textparent);
						OutXML.out3File(bw16,textparent);
					}
					
				}
				
				pop_before = pop_now;
				
				nd_hp = null;
				nd_hp = new int[nd_hp_tmp.length];
				nd_hp = nd_hp_tmp;
				gen_tot_id = null;
				gen_tot_id = gen_tot_id_tmp;
				nd_loc_x=null;
				nd_loc_y=null;
				nd_loc_x=nd_loc_x_tmp;
				nd_loc_y=nd_loc_y_tmp;
				hp_loc_x=null;
				hp_loc_y=null;
				hp_loc_x=hp_loc_x_tmp;
				hp_loc_y=hp_loc_y_tmp;
				hp_nd = null;
				freqhp_before = freqhp;
				hp_nd = hp_nd_tmp;

				gen++;
			}
			
			textvgj="";
			textvgj=TaVtoGML.outVGJtoSt5footer(textvgj);
			OutXML.out3File(bw1,textvgj);
			textsvg="";
			textsvg=TaVtoGML.outSVGtoSt5footer(textsvg);
			OutXML.out3File(bw2,textsvg);
			OutXML.out3File(bw4,textsvg);
			OutXML.out3File(bw6,textvgj);
			//OutXML.out2File(vgjfile,textvgj);
			bw1.close();
			bw2.close();
			bw3.close();
			bw4.close();
			bw5.close();
			bw6.close();
			bw7.close();
			bw8.close();
			bw9.close();
			bw10.close();
			bw11.close();
			bw12.close();
			bw13.close();
			bw14.close();
			bw15.close();
			bw16.close();
			bw17.close();
			bw18.close();
			bw19.close();
			bw20.close();
			bw21.close();
			
		}catch(Exception e){
			System.out.println(e);
		}
		

	}

	public static void main2(String[] args,WrightFisherParameter_Ref wfp_) {
		try{
//			WrightFisherParameters�ǂݍ���
			//WrightFisherParameter wfp;
			//wfp = new WrightFisherParameter();
			WrightFisherParameter_Ref wfp = new WrightFisherParameter_Ref();
			wfp = wfp_;
			int region = wfp.region_length;
			int pop = wfp.population_size;//1���l�A���F�̂�2���{
			double nt_morgan_ratio = wfp.nt_morgan_ratio;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
			int num_gen = wfp.num_generation;
			double mut_rate = wfp.mutation_rate;
			double rec_rate = wfp.recombination_rate;
			double hapfreq4disp = wfp.hapfreq4disp;
			
			//���s���O
			//�����ʂ��ăJ�E���g
			int gen=0;//����
			int nd_tot=0;//�S���F��(node)
			int ed_tot=0;//�S�G�b�W
			int hp_nd_tot=0;
			
			
			//������ŃJ�E���g
			int num_ch=0;
			//int[][] haptype;//�n�v���^�C�v�^
			IntArray4Hp[] haptype;
			int[] num_hp;//�n�v���^�C�v���Ƃ̐l��
			int[] nd_hp;//���F�̂̃n�v���^�C�v�^
			
			//graph
			int[][] child;//oyaid���1�A�q�������2�A�l��koid
			child = null;
			int event[][];//oyaid���1�A�q�������2�A�l�̓C�x���gID
			event = null;
			int[] parent0;//koid���1�A�l��oyaid
			int[] parent1;//koid���2�A�l��oyaid2(���Ȃ����null)
			parent0=new int[pop*num_gen];
			parent1=new int[pop*num_gen];
			int[] eventtype;//eventid���1�A�^�C�v(coalescent(0),recombination(1))
			int[][] recsite;//eventid���1�A��������2�Arecombination�ʒu�̍�����ԍ����l
			int[][] mutsite;//eventid���1�A��������2�Amutation�ʒu���l
			eventtype=null;
			//recsite=null;
			mutsite=new int[pop][2];
			recsite=new int[pop][1];
			
			int pop_before;
			int[] freqhp_before;
			
			//�o�̓p�����^
			GMLoutParameters gmloutp;
			gmloutp = new GMLoutParameters();
			
			int NdLb=gmloutp.NdLb;
			int EdLb=gmloutp.EdLb;
			int rootCol=gmloutp.rootCol;
			int mutCol=gmloutp.mutCol;
			int recCol=gmloutp.recCol;
			int mutEdcol=gmloutp.mutEdcol;
			int recEdcol=gmloutp.recEdcol;
			int origin=gmloutp.origin;
			
			
			
			//output setting 
			
			String textlog="";
			String textvgj="";
			String textgen="";
			String textgenhp="";
			String textsvg="";
			String texthaptypeFreq="";
			
			//String rootdir = "C:\\Java\\WrightFisher\\WFSimOut";
			String rootdir = args[0];
			//3 types(�S�́A�؂̏W�܂�A�X�̖�)�̃O���t�����t�@�C��
			//�S��
			
			String logfile=rootdir+"\\log.txt";
			String vgjfile=rootdir+"\\individual.gml";
			String svgfile=rootdir+"\\individual.svg";
			String freqsvgfile=rootdir+"\\hapfreq.svg";
			String genotypefile=rootdir+"\\hapallele_all_gen.txt";
			String freqdatafile=rootdir+"\\hapfreqdata_all_gen.txt";
			String genotypefile_last=rootdir+"\\hapallele_last_gen.txt";
			String freqdatafile_last=rootdir+"\\hapfreqdata_last_gen.txt";
			String freqvgjfile=rootdir+"\\hapfreq.gml";
			String parentchildfile =rootdir + "\\chparentchild.txt";
			String parentfile =rootdir + "\\chparent.txt";
			String childfile =rootdir + "\\chchild.txt";
			String parentchildfile2 =rootdir + "\\chparentchild2.txt";
			String parentfile2 =rootdir + "\\chparent2.txt";
			String childfile2 =rootdir + "\\chchild2.txt";
			String hpparentchildfile =rootdir + "\\hpparentchild.txt";
			String hpparentfile =rootdir + "\\hpparent.txt";
			String hpchildfile =rootdir + "\\hpchild.txt";
			String hpparentchildfile2 =rootdir + "\\hpparentchild2.txt";
			String hpparentfile2 =rootdir + "\\hpparent2.txt";
			String hpchildfile2 =rootdir + "\\hpchild2.txt";
			String hpidfile = rootdir + "\\hpid.txt";
			String haptypeFreq = rootdir + "\\haptypeFreq.txt";
			BufferedWriter bw1;
			BufferedWriter bw2;
			BufferedWriter bw3;
			BufferedWriter bw4;
			BufferedWriter bw5;
			BufferedWriter bw6;
			BufferedWriter bw7;
			BufferedWriter bw8;
			BufferedWriter bw9;
			BufferedWriter bw10;
			BufferedWriter bw11;
			BufferedWriter bw12;
			BufferedWriter bw13;
			BufferedWriter bw14;
			BufferedWriter bw15;
			BufferedWriter bw16;
			BufferedWriter bw17;
			BufferedWriter bw18;
			BufferedWriter bw19;
			BufferedWriter bw20;
			BufferedWriter bw21;
			BufferedWriter bw22;
			
			bw1=null;
			bw2=null;
			bw3=null;
			bw4=null;
			bw5=null;
			bw6=null;
			bw7=null;
			bw8=null;
			bw9=null;
			bw10=null;
			bw11=null;
			bw12=null;
			bw13=null;
			bw14=null;
			bw15=null;
			bw16=null;
			bw17=null;
			bw18=null;
			bw19=null;
			bw20=null;
			bw21=null;
			bw22=null;
			
			try{
				bw1 = new BufferedWriter(new FileWriter(vgjfile));
				bw2 = new BufferedWriter(new FileWriter(svgfile));
				bw3 = new BufferedWriter(new FileWriter(genotypefile));
				bw4 = new BufferedWriter(new FileWriter(freqsvgfile));
				bw5 = new BufferedWriter(new FileWriter(freqdatafile));
				bw6 = new BufferedWriter(new FileWriter(freqvgjfile));
				bw7 = new BufferedWriter(new FileWriter(genotypefile_last));
				bw8 = new BufferedWriter(new FileWriter(freqdatafile_last));
				bw9 = new BufferedWriter(new FileWriter(parentchildfile));
				bw10 = new BufferedWriter(new FileWriter(parentfile));
				bw11 = new BufferedWriter(new FileWriter(childfile));
				bw12 = new BufferedWriter(new FileWriter(parentchildfile2));
				bw13 = new BufferedWriter(new FileWriter(parentfile2));
				bw14 = new BufferedWriter(new FileWriter(childfile2));
				bw15 = new BufferedWriter(new FileWriter(hpparentchildfile));
				bw16 = new BufferedWriter(new FileWriter(hpparentfile));
				bw17 = new BufferedWriter(new FileWriter(hpchildfile));
				bw18 = new BufferedWriter(new FileWriter(hpparentchildfile2));
				bw19 = new BufferedWriter(new FileWriter(hpparentfile2));
				bw20 = new BufferedWriter(new FileWriter(hpchildfile2));
				bw21 = new BufferedWriter(new FileWriter(hpidfile));
				bw22 = new BufferedWriter(new FileWriter(haptypeFreq));
			}catch(Exception e){
				
				System.out.println(e);

			}
			
			/*
			String genoutroot=rootdir+"\\gen";
			
			
			String outarg = rootdir + "\\out_arg.txt";
			//�g�����ɂ�蕪�������u�؁v�̏W�܂�(�u�сv)
			String outforest = rootdir + "\\out_forest.txt";
			String outforestTr = rootdir + "\\out_forestTr.txt";
			String outfr_vine = rootdir + "\\out_fr_vine.txt";
			//�X�́u�؁v
			String outtrees = rootdir + "\\out_trees_";
			String outtrees_sf ="";
			String outpajek2 = rootdir + "\\out2.txt";
			String outevent = rootdir + "\\event.txt";
			*/
			
			//simulation settings
			//int numsnp = 200;//SNP�̐��A�z�񒷂ɂ�����
			int numsnp = wfp.region_length;//SNP�̐��A�z�񒷂ɂ�����
			//int iteration =100;//mutation + recombination�̉�
			int iteration = wfp.num_generation;//���㐔
			

			
			textvgj=TaVtoGML.outVGJtoSt5header(textvgj);
			int svgsize;
			svgsize = Math.max(pop,num_gen);
			textsvg=TaVtoGML.outSVGtoSt5header(textsvg,svgsize);
			OutXML.out3File(bw1,textvgj);
			OutXML.out3File(bw2,textsvg);
			OutXML.out3File(bw4,textsvg);
			OutXML.out3File(bw6,textvgj);
			String headerhapfreq = ">Length of region(nt)\t"+ region+"\n"
			+">No.total chromosomes\t" + pop +"\n" +
					">nt/1cM\t"+ nt_morgan_ratio +"\n"+
					">No.generation\t" + num_gen + "\n"+
					">Mutation rate\t" + mut_rate + "\n"+ 
					">Recombination rate/1cM\t"+rec_rate +"\n" +
					">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+
					"\n>Haplotype id\tNo.chromosomes\tMutation sites\n";
			OutXML.out3File(bw8,headerhapfreq);
			
			//Root
			//simulation�J�n�̃n�v���^�C�v����
//			�S���F�͕̂ψقȂ��A����n�v���^�C�v
			System.out.println("Root Generation is in progress");
			IntArray4Hp tmpintarray4hp;
			tmpintarray4hp=new IntArray4Hp();
			haptype = new IntArray4Hp[1];
			haptype[0]=tmpintarray4hp;
			//haptype[0].arr=null;
			//haptype[0][0]=-9;
			String[] genotype;
			genotype = new String[1];
			//genotype[0] = "\n";
			genotype[0] = "";
			
			nd_hp = new int[pop];
			int[] gen_tot_id;
			gen_tot_id = new int[pop];
			
			int[] nd_loc_x;
			nd_loc_x = new int[pop];
			int[] nd_loc_y;
			nd_loc_y = new int[pop];
			
			int[] hp_loc_x;
			int[] hp_loc_y;
			hp_loc_x=new int[1];
			hp_loc_y=new int[1];
			
			int[] hp_nd;
			hp_nd = new int[pop];
			//String freqdataout="generation\t" + gen + "\n";
			String freqdataout="generation\t" + gen + "\n";
			OutXML.out3File(bw5,freqdataout);
			OutXML.out3File(bw3,freqdataout);
			
			for(int i=0;i<pop;i++){
				
				nd_hp[i]=0;
				gen_tot_id[i]=nd_tot;
				String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,0,gen,i
						,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				//textvgj+=vgj;
				nd_loc_x[i]=gen*pop;
				nd_loc_y[i]=i*pop;
				OutXML.out3File(bw1,vgj);
				String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,nd_loc_x[i],nd_loc_y[i],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				OutXML.out3File(bw2,svg);
				
				String hpkata = genotype[nd_hp[i]];
				//System.out.println("hpkata " + hpkata);
				hpkata +=i + "\t" + hpkata + "\n";
				OutXML.out3File(bw3,hpkata);
			
						
				nd_tot++;

			}
			pop_before = pop;
			//root generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
			
			int[] freqhp;
			freqhp = new int[haptype.length];
			for(int i=0;i<haptype.length;i++){
				freqhp[i]=0;
			}
			for(int i=0;i<nd_hp.length;i++){
				freqhp[nd_hp[i]]++;
			}
			int roothpcnt=0;
			
			for(int i=0;i<haptype.length;i++){
				if(freqhp[i]>0){
					String hpid="0\t" + roothpcnt + "\t" + i+"\n";
					OutXML.out3File(bw21,hpid);
					
					String hpkata = "";
					
					for(int k=0;k<haptype[i].arr.length;k++){
						
						hpkata += haptype[i].arr[k] + " ";
					}
					freqdataout=roothpcnt + "\t" + i +"\t" + freqhp[i] + "\t" + hpkata + "\n";
					OutXML.out3File(bw5,freqdataout);
					hp_loc_x[i]=gen*pop;
					hp_loc_y[i]=roothpcnt*pop;
					double freqdb=(double)(freqhp[i])/(double)(pop);
					String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqdb,
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					OutXML.out3File(bw4,freqsvg);
					String freqvgj=TaVtoGML.outVGJtoSt5Node_URL(hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					hp_nd[i]=hp_nd_tot;
					hp_nd_tot++;
					OutXML.out3File(bw6,freqvgj);
					
					roothpcnt++;
				}
				
			}
			freqhp_before = freqhp;
			gen++;
			
			for(int i=gen;i<num_gen;i++){
				System.out.println("Generation " + i + "/" + num_gen + " is in progress.");
				//freqdataout="generation\t" + gen + "\n";
				freqdataout="generation\t" + gen + "\n";
				OutXML.out3File(bw5,freqdataout);
				OutXML.out3File(bw3,freqdataout);
				
				int pop_now=pop;
				int[] nd_hp_tmp;
				nd_hp_tmp = new int[pop_now];
				int[] gen_tot_id_tmp;
				gen_tot_id_tmp = new int[pop_now];
				int[] nd_loc_x_tmp;
				nd_loc_x_tmp = new int[pop_now];
				int[] nd_loc_y_tmp;
				nd_loc_y_tmp = new int[pop_now];
				int[] hp_nd_tmp;
				hp_nd_tmp = new int[hp_nd.length+pop_now];
				//ch�e�q�y�A�L�^�p�A���C
				IntArray4Hp choya;
				IntArray4Hp chko;
				//hp�e�q�y�A�L�^�p�A���C
				IntArray4Hp hpoya;
				IntArray4Hp hpko;
				//haptype�u��
				IntArray4Hp[] haptype_before;
				haptype_before = haptype;
				
				choya = new IntArray4Hp();
				chko = new IntArray4Hp();
				hpoya = new IntArray4Hp();
				hpko = new IntArray4Hp();
				
				for(int j=0;j<pop;j++){
					double rand0 = Math.random();
					double rec_freq = rec_rate*region/nt_morgan_ratio;
					
					if(rand0>rec_freq){//No recombination
						double rand1 = Math.random();
						int tmpoya = (int)(rand1*nd_hp.length);
						choya.addelem(tmpoya);
						chko.addelem(j);
						
						IntArray4Hp tmp_hpkata;
						tmp_hpkata=new IntArray4Hp();
						double rand_mut = Math.random();
						if(rand_mut<=mut_rate){
							//System.out.println("mutation!!");
							double rand_mut_site = Math.random();
							int mut_site_tmp =(int)(rand_mut_site*region);
							mutsite[j][0]=mut_site_tmp;
							IntArray4Hp tmp_tmp_hpkata;
							tmp_tmp_hpkata = new IntArray4Hp();
							boolean judge=true;
							boolean judgeyet=true;
							if(haptype[nd_hp[tmpoya]].arr.length==0){
								
								tmp_tmp_hpkata.addelem(mutsite[j][0]);
								
								nd_hp_tmp[j]=haptype.length;
								IntArray4Hp[] tmp_haptype;
								tmp_haptype = new IntArray4Hp[haptype.length+1];
								for(int x=0;x<haptype.length;x++){
									tmp_haptype[x]=haptype[x];
									
								}
								tmp_haptype[haptype.length]=tmp_tmp_hpkata;
								
								haptype = null;
								haptype=tmp_haptype;
								
							}else{
								int counter=0;
								for(int k=0;k<haptype[nd_hp[tmpoya]].arr.length;k++){
									
									if(haptype[nd_hp[tmpoya]].arr[k]==mutsite[j][0]){
										
										tmp_tmp_hpkata.addelem(mutsite[j][0]);
										
										judge=false;
										judgeyet=false;
										//System.out.println("eaqual");
									}else if(haptype[nd_hp[tmpoya]].arr[k]<mutsite[j][0]){
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										//System.out.println("more than");
									}else if(haptype[nd_hp[tmpoya]].arr[k]>mutsite[j][0]){
										//System.out.println("less than");
										if(judgeyet){
											tmp_tmp_hpkata.addelem(mutsite[j][0]);
											counter++;
											judgeyet=false;
										}
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										
									
									}
									
								}
								if(judgeyet){
									//System.out.println("add");
									tmp_tmp_hpkata.addelem(mutsite[j][0]);
									counter++;
								}
								boolean noidhp=true;
								for(int x=0;x<haptype.length;x++){
									boolean identicalhp = true;
									if(haptype[x].arr.length==tmp_tmp_hpkata.arr.length){
										for(int y=0;y<tmp_tmp_hpkata.arr.length;y++){
											if(haptype[x].arr[y]!=tmp_tmp_hpkata.arr[y]){
												identicalhp=false;
												break;
											}
										}
										if(identicalhp){//�Vhptype�ł͂Ȃ�
											//nd_hp_tmp[j]=nd_hp[x];
											nd_hp_tmp[j]=x;
											noidhp=false;
											
											break;
										}
									}
								}
								if(noidhp){
									nd_hp_tmp[j]=haptype.length;
									IntArray4Hp[] tmp_haptype;
									tmp_haptype = new IntArray4Hp[haptype.length+1];
									for(int x=0;x<haptype.length;x++){
										tmp_haptype[x]=haptype[x];
										
									}
									
									tmp_haptype[haptype.length]=tmp_tmp_hpkata;
									
									haptype = null;
									haptype=tmp_haptype;
								}
							}
							if(judge){
								tmp_hpkata=tmp_tmp_hpkata;
								}
							
						}else{
							tmp_hpkata=haptype[nd_hp[tmpoya]];
							nd_hp_tmp[j]=nd_hp[tmpoya];
							
						}
						//hppair�o�^
						boolean newpair=true;
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
									//System.out.println("##�o�^���Ȃ� " + j);
									newpair=false;
								}
								
							}
						}
						if(newpair){
							hpoya.addelem(nd_hp[tmpoya]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						gen_tot_id_tmp[j]=nd_tot;
						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,1,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i*pop_now;
						nd_loc_y_tmp[j]=j*pop_now;
						//textvgj+=vgj;
						OutXML.out3File(bw1,vgj);
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,1,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw2,svg);
						
						String hpkata = j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + " ";
						}
						hpkata += "\n";
						OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,0,gen_tot_id[tmpoya],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(0, nd_loc_x[tmpoya],nd_loc_y[tmpoya],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//textvgj+=vgj_ed;
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya];
						
						nd_tot++;
						ed_tot++;
					}else{
						//�g��������
						//System.out.println("recombination");
						double rand1 = Math.random();
						double rand2 = Math.random();
						int tmpoya1 = (int)(rand1*nd_hp.length);
						int tmpoya2 = (int)(rand2*(nd_hp.length-1));
						if(tmpoya2<=tmpoya1){
							tmpoya2++;
						}
						choya.addelem(tmpoya1);
						chko.addelem(j);
						choya.addelem(tmpoya2);
						chko.addelem(j);
						//�g�����ʒu
						double rand3 = Math.random();
						int rec = (int)(rand3*region);
						
						recsite[j][0]=rec;
						
						//�Q��oyahap�ɏ�L�Ɠ���������mutation���N�����A���̏�ŁA�V�n�v���^�C�v�����
						IntArray4Hp hptmpoya1 = haptype[nd_hp[tmpoya1]];
						IntArray4Hp hptmpoya2 = haptype[nd_hp[tmpoya2]];
						IntArray4Hp tmphap;
						tmphap = new IntArray4Hp();
						
						double rand_event1 = Math.random();
						double rand_event2 = Math.random();
						if(rand_event1<=mut_rate){
							double rand_mut_site1 = Math.random();
							int mut_site_tmp1 =(int)(rand_mut_site1*region);
							mutsite[j][0]=mut_site_tmp1;
							boolean judge1=true;
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									if(mutsite[j][0]>hptmpoya1.arr[k]){
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}else if(mutsite[j][0]==hptmpoya1.arr[k]){
										tmphap.addelem(mutsite[j][0]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
										judge1=false;
									}else if(mutsite[j][0]<hptmpoya1.arr[k]){
										if(judge1){
											tmphap.addelem(mutsite[j][0]);
											//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
											judge1=false;
										}
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}
								}
							}
							if(judge1){
								if(mutsite[j][0]<=recsite[j][0]){
									tmphap.addelem(mutsite[j][0]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}else{
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									tmphap.addelem(hptmpoya1.arr[k]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}
						if(rand_event2<=mut_rate){
							double rand_mut_site2 = Math.random();
							int mut_site_tmp2 =(int)(rand_mut_site2*region);
							mutsite[j][1]=mut_site_tmp2;
							boolean judge2=true;
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									if(mutsite[j][1]>hptmpoya2.arr[k]){
										tmphap.addelem(hptmpoya2.arr[k]);
									}else if(mutsite[j][1]==hptmpoya2.arr[k]){
										tmphap.addelem(mutsite[j][1]);
										judge2=false;
									}else if(mutsite[j][1]<hptmpoya2.arr[k]){
										if(judge2){
											tmphap.addelem(mutsite[j][1]);
											judge2=false;
										}
										tmphap.addelem(hptmpoya2.arr[k]);
									}
								}
							}
							if(judge2){
								if(mutsite[j][1]>recsite[j][0]){
									tmphap.addelem(mutsite[j][1]);
								}
							}
						}else{
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									tmphap.addelem(hptmpoya2.arr[k]);
								}
							}
						}
						
						//����haplotype�ɂ��łɑ��݂��邩
						
						boolean noidhp=true;
						//int max_mutsite=0;
						
						for(int x=0;x<haptype.length;x++){
							boolean identicalhp = true;
							if(haptype[x].arr.length==tmphap.arr.length){
								//if(haptype[x].arr.length>max_mutsite){
									//max_mutsite=haptype[x].arr.length;
								//}
								for(int y=0;y<tmphap.arr.length;y++){
									if(haptype[x].arr[y]!=tmphap.arr[y]){
										identicalhp=false;
										break;
									}
								}
								if(identicalhp){//�Vhptype�ł͂Ȃ�
									
									//nd_hp_tmp[j]=nd_hp[x];
									nd_hp_tmp[j]=x;
									
									noidhp=false;
									
									break;
								}
							}
						}
						//if(tmp_tmp_hpkata.arr.length>max_mutsite){
							//max_mutsite = tmp_tmp_hpkata.arr.length;
						//}
						if(noidhp){
							
							nd_hp_tmp[j]=haptype.length;
							IntArray4Hp[] tmp_haptype;
							tmp_haptype = new IntArray4Hp[haptype.length+1];
							for(int x=0;x<haptype.length;x++){
								tmp_haptype[x]=haptype[x];
								
							}
							
							tmp_haptype[haptype.length]=tmphap;
							
							haptype = null;
							haptype = new IntArray4Hp[tmp_haptype.length];
							haptype=tmp_haptype;
						}
//						hppair�o�^
						boolean newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya1]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya1]);
							hpko.addelem(nd_hp_tmp[j]);
						}
//						hppair�o�^
						newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya2]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya2]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						//nd_hp_tmp[j]=nd_hp[tmpoya1];//�����̓n�v���^�C�v��{�C�œo�^����Ƃ��ɂ́A�ς���
//						
						gen_tot_id_tmp[j]=nd_tot;
						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,2,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i*pop_now;
						nd_loc_y_tmp[j]=j*pop_now;
						//textvgj+=vgj;
						OutXML.out3File(bw1,vgj);
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,2,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw2,svg);
						
						
						String hpkata = "";
						hpkata +=j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + "\t";
						}
						hpkata += "\n";
						OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya1],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya1],nd_loc_y[tmpoya1],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						ed_tot++;
						//textvgj+=vgj_ed;
						vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya2],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya2],nd_loc_y[tmpoya2],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya1];
						parent1[nd_tot]=gen_tot_id[tmpoya2];
						
						ed_tot++;
						nd_tot++;
					}
					
				}

				
//				���� generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
				//freqdataout="generation\t" + gen + "\n";
				//OutXML.out3File(bw5,freqdataout);
				freqhp = new int[haptype.length];
				for(int j=0;j<haptype.length;j++){
					freqhp[j]=0;
				}
				for(int j=0;j<nd_hp_tmp.length;j++){
					//System.out.println("j,nd_hp_tmp[j] "+j + " " + nd_hp_tmp[j]);
					freqhp[nd_hp_tmp[j]]++;
				}
				int hptypecnt=0;
				int[] hp_loc_x_tmp;
				int[] hp_loc_y_tmp;
				hp_loc_x_tmp = new int[haptype.length];
				hp_loc_y_tmp = new int[haptype.length];
				//System.out.println("haptype.len " + haptype.length);
				for(int j=0;j<haptype.length;j++){
					double freqdb=(double)(freqhp[j])/(double)(pop_now); 
					//if(freqhp[j]>0){
					if(freqdb>hapfreq4disp){
						
						
						String hpkata = "";
						int initial=0;
						int end=region;
						texthaptypeFreq ="";
						for(int k=0;k<haptype[j].arr.length;k++){
							
							hpkata += haptype[j].arr[k] + "\t";
							if(i==num_gen-1){
								for(int x=initial;x<haptype[j].arr[k];x++){
									texthaptypeFreq += 0;
								}
								texthaptypeFreq +=1;
								initial = haptype[j].arr[k]+1;
							}
							
						}
						if(i==num_gen-1){
							if(haptype[j].arr.length==0){
								for(int x=0;x<region;x++){
									texthaptypeFreq +=0;
								}
							}else{
								for(int x=haptype[j].arr[haptype[j].arr.length-1]+1;x<region;x++){
									texthaptypeFreq+=0;
								}
							}
						}
						texthaptypeFreq+="\n";
						
						freqdataout=hptypecnt + "\t" + j+"\t" + freqhp[j] + "\t" + hpkata + "\n";
						
						OutXML.out3File(bw5,freqdataout);
						if(i==num_gen-1){
							OutXML.out3File(bw8,freqdataout);
							OutXML.out3File(bw22,texthaptypeFreq);
						}
						hp_loc_x_tmp[j]=gen*pop_now;
						hp_loc_y_tmp[j]=hptypecnt*pop_now;
						
						String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqdb,
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						
						OutXML.out3File(bw4,freqsvg);
						String freqvgj=TaVtoGML.outVGJtoSt5Node_URL(hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw6,freqvgj);
						hp_nd_tmp[j]=hp_nd_tot;
						hp_nd_tot++;
						
						for(int k=0;k<hpoya.arr.length;k++){
							if(hpko.arr[k]==j){
								String hp_svg_ed=TaVtoGML.outSVGtoSt5Edge(1, 
										hp_loc_x[hpoya.arr[k]],hp_loc_y[hpoya.arr[k]],hp_loc_x_tmp[j],
										hp_loc_y_tmp[j],NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								OutXML.out3File(bw4,hp_svg_ed);
								String hp_vgj_ed=TaVtoGML.outVGJtoSt5Edge(hp_nd_tmp[j],2,hp_nd[hpoya.arr[k]],
										NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								
								OutXML.out3File(bw6,hp_vgj_ed);
							}
						}
						String hpid=i + "\t" + hptypecnt + "\t" + j+"\n";
						OutXML.out3File(bw21,hpid);
						
						hptypecnt++;
					}
					
				}
				//output parent,child of ch
				for(int j=0;j<pop_before;j++){
					String textchild = i-1 + "\t" + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textchild2 = i-1 + "\t" + j +"\t";
						if(choya.arr[k]==j){
							textchild += i + "\t" + chko.arr[k] + "\t";
							textchild2 += i + "\t" + chko.arr[k] + "\t\n";
							OutXML.out3File(bw12,"parent\t");
							OutXML.out3File(bw12,textchild2);
							
							OutXML.out3File(bw14,textchild2);
						}
					}
					textchild += "\n";
					OutXML.out3File(bw9,"parent\t");
					OutXML.out3File(bw9,textchild);
					OutXML.out3File(bw11,textchild);
				}
				for(int j=0;j<pop_now;j++){
					String textparent = i + "\t" + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textparent2 = i + "\t" + j +"\t";
						if(chko.arr[k]==j){
							textparent += i-1 + "\t" + choya.arr[k] + "\t";
							textparent2 += i-1 + "\t" + choya.arr[k] + "\t\n";
							OutXML.out3File(bw12,"child\t");
							OutXML.out3File(bw12,textparent2);
							OutXML.out3File(bw13,textparent2);
						}
					}
					textparent += "\n";
					OutXML.out3File(bw9,"child\t");
					OutXML.out3File(bw9,textparent);
					OutXML.out3File(bw10,textparent);
				}
//				output parent,child of hp
				for(int j=0;j<haptype_before.length;j++){
					if(freqhp_before[j]>0){
						String textchild = i-1 + "\t" + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textchild2 = i-1 + "\t" + j +"\t";
							if(hpoya.arr[k]==j){
								textchild += i + "\t" + hpko.arr[k] + "\t";
								textchild2 += i + "\t" + hpko.arr[k] + "\t\n";
								OutXML.out3File(bw18,"parent\t");
								OutXML.out3File(bw18,textchild2);
								
								OutXML.out3File(bw20,textchild2);
							}
						}
						textchild += "\n";
						OutXML.out3File(bw15,"parent\t");
						OutXML.out3File(bw15,textchild);
						OutXML.out3File(bw17,textchild);
					}
					
				}
				int freqhpcnt=0;
				for(int j=0;j<haptype.length;j++){
					if(freqhp[j]>0){
						String textparent = i + "\t" + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textparent2 = i + "\t" + j +"\t";
							if(hpko.arr[k]==j){
								textparent += i-1 + "\t" + hpoya.arr[k] + "\t";
								textparent2 += i-1 + "\t" + hpoya.arr[k] + "\t\n";
								OutXML.out3File(bw18,"child\t");
								OutXML.out3File(bw18,textparent2);
								OutXML.out3File(bw19,textparent2);
							}
						}
						textparent += "\n";
						OutXML.out3File(bw15,"child\t");
						OutXML.out3File(bw15,textparent);
						OutXML.out3File(bw16,textparent);
					}
					
				}
				
				pop_before = pop_now;
				
				nd_hp = null;
				nd_hp = new int[nd_hp_tmp.length];
				nd_hp = nd_hp_tmp;
				gen_tot_id = null;
				gen_tot_id = gen_tot_id_tmp;
				nd_loc_x=null;
				nd_loc_y=null;
				nd_loc_x=nd_loc_x_tmp;
				nd_loc_y=nd_loc_y_tmp;
				hp_loc_x=null;
				hp_loc_y=null;
				hp_loc_x=hp_loc_x_tmp;
				hp_loc_y=hp_loc_y_tmp;
				hp_nd = null;
				freqhp_before = freqhp;
				hp_nd = hp_nd_tmp;

				gen++;
			}
			
			textvgj="";
			textvgj=TaVtoGML.outVGJtoSt5footer(textvgj);
			OutXML.out3File(bw1,textvgj);
			textsvg="";
			textsvg=TaVtoGML.outSVGtoSt5footer(textsvg);
			OutXML.out3File(bw2,textsvg);
			OutXML.out3File(bw4,textsvg);
			OutXML.out3File(bw6,textvgj);
			//OutXML.out2File(vgjfile,textvgj);
			bw1.close();
			bw2.close();
			bw3.close();
			bw4.close();
			bw5.close();
			bw6.close();
			bw7.close();
			bw8.close();
			bw9.close();
			bw10.close();
			bw11.close();
			bw12.close();
			bw13.close();
			bw14.close();
			bw15.close();
			bw16.close();
			bw17.close();
			bw18.close();
			bw19.close();
			bw20.close();
			bw21.close();
			bw22.close();
			
		}catch(Exception e){
			System.out.println(e);
		}
		

	}
	
	public class MyThread extends Thread{
		String[] args;
		WrightFisherParameter_Ref wfp;
    	//�R���X�g���N�^
        MyThread(String[] args_,WrightFisherParameter_Ref wfp_){
        	args=args_;
        	wfp=wfp_;
        }

        public void run(){
        	
        	
        	
        	
        	
        	try{
//    			WrightFisherParameters�ǂݍ���
    			//WrightFisherParameter wfp;
    			//wfp = new WrightFisherParameter();
    			//WrightFisherParameter_Ref wfp = new WrightFisherParameter_Ref();
    			//wfp = wfp_;
    			int region = wfp.region_length;
    			int pop = wfp.population_size;//1���l�A���F�̂�2���{
    			double nt_morgan_ratio = wfp.nt_morgan_ratio;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
    			int num_gen = wfp.num_generation;
    			double mut_rate = wfp.mutation_rate;
    			double rec_rate = wfp.recombination_rate;
    			double hapfreq4disp = wfp.hapfreq4disp;
    			
    			//���s���O
    			//�����ʂ��ăJ�E���g
    			int gen=0;//����
    			int nd_tot=0;//�S���F��(node)
    			int ed_tot=0;//�S�G�b�W
    			int hp_nd_tot=0;
    			
    			
    			//������ŃJ�E���g
    			int num_ch=0;
    			//int[][] haptype;//�n�v���^�C�v�^
    			IntArray4Hp[] haptype;
    			int[] num_hp;//�n�v���^�C�v���Ƃ̐l��
    			int[] nd_hp;//���F�̂̃n�v���^�C�v�^
    			
    			//graph
    			int[][] child;//oyaid���1�A�q�������2�A�l��koid
    			child = null;
    			int event[][];//oyaid���1�A�q�������2�A�l�̓C�x���gID
    			event = null;
    			int[] parent0;//koid���1�A�l��oyaid
    			int[] parent1;//koid���2�A�l��oyaid2(���Ȃ����null)
    			parent0=new int[pop*num_gen];
    			parent1=new int[pop*num_gen];
    			int[] eventtype;//eventid���1�A�^�C�v(coalescent(0),recombination(1))
    			int[][] recsite;//eventid���1�A��������2�Arecombination�ʒu�̍�����ԍ����l
    			int[][] mutsite;//eventid���1�A��������2�Amutation�ʒu���l
    			eventtype=null;
    			//recsite=null;
    			mutsite=new int[pop][2];
    			recsite=new int[pop][1];
    			
    			int pop_before;
    			int[] freqhp_before;
    			
    			//�o�̓p�����^
    			GMLoutParameters gmloutp;
    			gmloutp = new GMLoutParameters();
    			
    			int NdLb=gmloutp.NdLb;
    			int EdLb=gmloutp.EdLb;
    			int rootCol=gmloutp.rootCol;
    			int mutCol=gmloutp.mutCol;
    			int recCol=gmloutp.recCol;
    			int mutEdcol=gmloutp.mutEdcol;
    			int recEdcol=gmloutp.recEdcol;
    			int origin=gmloutp.origin;
    			
    			
    			
    			//output setting 
    			
    			String textlog="";
    			String textvgj="";
    			String textgen="";
    			String textgenhp="";
    			String textsvg="";
    			String texthaptypeFreq="";
    			
    			//String rootdir = "C:\\Java\\WrightFisher\\WFSimOut";
    			String rootdir = args[0] + "\\" + args[1]+"_";
    			//3 types(�S�́A�؂̏W�܂�A�X�̖�)�̃O���t�����t�@�C��
    			//�S��
    			
    			String logfile=rootdir+"log.txt";
    			String vgjfile=rootdir+"FIG_G_individual.gml";//bw1
    			String svgfile=rootdir+"FIG_S_individual.svg";//bw2
    			
    			String genotypefile=rootdir+"DATA_ch_allgen.txt";//bw3
    			String freqsvgfile=rootdir+"FIG_S_hapfreq.svg";//bw4
    			String freqsvgfileAll=rootdir+"FIG_S_hapfreqAll.svg";//bw4All
    			String freqdatafile=rootdir+"DATA_hp_common_allgen.txt";//bw5
    			String freqdatafileAll=rootdir+"DATA_hp_all_allgen.txt";//bw5All
    			String freqvgjfile=rootdir+"FIG_G_hapfreq.gml";//bw6
    			String freqvgjfileAll=rootdir+"FIG_G_hapfreqAll.gml";//bw6All
    			String genotypefile_last=rootdir+"DATA_ch_lastgen.txt";//bw7
    			String freqdatafile_last=rootdir+"DATA_hp_common_lastgen.txt";//bw8
    			String freqdatafile_lastAll=rootdir+"DATA_hp_all_lastgen.txt";//bw8All
    			
    			String parentchildfile =rootdir + "GRAPH_ch_parentchild_1.txt";//bw9
    			String childfile =rootdir + "GRAPH_ch_child_1.txt";//bw10
    			String parentfile =rootdir + "GRAPH_ch_parent_1.txt";//bw11
    			String parentchildfile2 =rootdir + "GRAPH_ch_parentchild_2.txt";//bw12
    			String parentfile2 =rootdir + "GRAPH_ch_parent_2.txt";//bw13
    			String childfile2 =rootdir + "GRAPH_ch_child_2.txt";//bw14
    			String hpparentchildfile =rootdir + "GRAPH_hp_parentchild_1.txt";//bw15
    			String hpparentfile =rootdir + "GRAPH_hp_parent_1.txt";//bw16
    			String hpchildfile =rootdir + "GRAPH_hp_child_1.txt";//bw17
    			String hpparentchildfile2 =rootdir + "GRAPH_hp_parentchild_2.txt";//bw18
    			String hpparentfile2 =rootdir + "GRAPH_hp_parent_2.txt";//bw19
    			String hpchildfile2 =rootdir + "GRAPH_hp_child_2.txt";//bw20
    			String hpidfile = rootdir + "DATA_hpid_common_allgen.txt";//bw21
    			String hpidfileAll = rootdir + "DATA_hpid_all_allgen.txt";//bw21All
    			String haptypeFreq = rootdir + "DATA_hpseq_common_lastgen.txt";//bw22
    			String haptypeFreqAll = rootdir + "DATA_hpseq_all_lastgen.txt";//bw22All
    			String snplist_last = rootdir + "DATA_snplist_lastgen.txt";//bw23
    			
    			/*
    			String haptypeFreqCommon = rootdir + "\\DATA_haptypeFreqCommon.txt";//bw24
    			String haptypeFreqAllCommon = rootdir + "\\DATA_haptypeFreqAllCommon.txt";//bw24All
    			String snplist_lastCommon = rootdir + "\\DATA_snplist_lastCommon.txt";//bw25
    			*/
    			
    			BufferedWriter bw1;
    			BufferedWriter bw2;
    			BufferedWriter bw3;
    			
    			BufferedWriter bw4;
    			BufferedWriter bw4All;
    			BufferedWriter bw5;
    			BufferedWriter bw5All;
    			BufferedWriter bw6;
    			BufferedWriter bw6All;
    			BufferedWriter bw7;
    			
    			BufferedWriter bw8;
    			BufferedWriter bw8All;
    			BufferedWriter bw9;
    			BufferedWriter bw10;
    			BufferedWriter bw11;
    			BufferedWriter bw12;
    			BufferedWriter bw13;
    			BufferedWriter bw14;
    			BufferedWriter bw15;
    			BufferedWriter bw16;
    			BufferedWriter bw17;
    			BufferedWriter bw18;
    			BufferedWriter bw19;
    			BufferedWriter bw20;
    			BufferedWriter bw21;
    			BufferedWriter bw21All;
    			BufferedWriter bw22;
    			BufferedWriter bw22All;
    			BufferedWriter bw23;
    			
    			/*
    			BufferedWriter bw24;
    			BufferedWriter bw24All;
    			BufferedWriter bw25;
    			*/
    			
    			bw1=null;
    			bw2=null;
    			bw3=null;
    			
    			bw4=null;
    			bw4All=null;
    			bw5=null;
    			bw5All=null;
    			bw6=null;
    			bw6All=null;
    			bw7=null;
    			
    			bw8=null;
    			bw8All=null;
    			bw9=null;
    			bw10=null;
    			bw11=null;
    			bw12=null;
    			bw13=null;
    			bw14=null;
    			bw15=null;
    			bw16=null;
    			bw17=null;
    			bw18=null;
    			bw19=null;
    			bw20=null;
    			bw21=null;
    			bw21All=null;
    			bw22=null;
    			bw22All=null;
    			bw23=null;
    			/*
    			bw24=null;
    			bw24All=null;
    			bw25=null;
    			*/
    			try{
    				bw1 = new BufferedWriter(new FileWriter(vgjfile));
    				bw2 = new BufferedWriter(new FileWriter(svgfile));
    				bw3 = new BufferedWriter(new FileWriter(genotypefile));
    				
    				bw4 = new BufferedWriter(new FileWriter(freqsvgfile));
    				bw4All = new BufferedWriter(new FileWriter(freqsvgfileAll));
    				bw5 = new BufferedWriter(new FileWriter(freqdatafile));
    				bw5All = new BufferedWriter(new FileWriter(freqdatafileAll));
    				bw6 = new BufferedWriter(new FileWriter(freqvgjfile));
    				bw6All = new BufferedWriter(new FileWriter(freqvgjfileAll));
    				bw7 = new BufferedWriter(new FileWriter(genotypefile_last));
    				bw8 = new BufferedWriter(new FileWriter(freqdatafile_last));
    				bw8All = new BufferedWriter(new FileWriter(freqdatafile_lastAll));
    				bw9 = new BufferedWriter(new FileWriter(parentchildfile));
    				bw10 = new BufferedWriter(new FileWriter(parentfile));
    				bw11 = new BufferedWriter(new FileWriter(childfile));
    				bw12 = new BufferedWriter(new FileWriter(parentchildfile2));
    				bw13 = new BufferedWriter(new FileWriter(parentfile2));
    				bw14 = new BufferedWriter(new FileWriter(childfile2));
    				bw15 = new BufferedWriter(new FileWriter(hpparentchildfile));
    				bw16 = new BufferedWriter(new FileWriter(hpparentfile));
    				bw17 = new BufferedWriter(new FileWriter(hpchildfile));
    				bw18 = new BufferedWriter(new FileWriter(hpparentchildfile2));
    				bw19 = new BufferedWriter(new FileWriter(hpparentfile2));
    				bw20 = new BufferedWriter(new FileWriter(hpchildfile2));
    				bw21 = new BufferedWriter(new FileWriter(hpidfile));
    				bw21All = new BufferedWriter(new FileWriter(hpidfileAll));
    				bw22 = new BufferedWriter(new FileWriter(haptypeFreq));
    				bw22All = new BufferedWriter(new FileWriter(haptypeFreqAll));
    				bw23 = new BufferedWriter(new FileWriter(snplist_last));
    				/*
    				bw24 = new BufferedWriter(new FileWriter(haptypeFreqCommon));
    				bw24All = new BufferedWriter(new FileWriter(haptypeFreqAllCommon));
    				bw25 = new BufferedWriter(new FileWriter(snplist_lastCommon));
    				*/
    			}catch(Exception e){
    				
    				System.out.println(e);

    			}
    			
    			/*
    			String genoutroot=rootdir+"\\gen";
    			
    			
    			String outarg = rootdir + "\\out_arg.txt";
    			//�g�����ɂ�蕪�������u�؁v�̏W�܂�(�u�сv)
    			String outforest = rootdir + "\\out_forest.txt";
    			String outforestTr = rootdir + "\\out_forestTr.txt";
    			String outfr_vine = rootdir + "\\out_fr_vine.txt";
    			//�X�́u�؁v
    			String outtrees = rootdir + "\\out_trees_";
    			String outtrees_sf ="";
    			String outpajek2 = rootdir + "\\out2.txt";
    			String outevent = rootdir + "\\event.txt";
    			*/
    			
    			//simulation settings
    			//int numsnp = 200;//SNP�̐��A�z�񒷂ɂ�����
    			int numsnp = wfp.region_length;//SNP�̐��A�z�񒷂ɂ�����
    			//int iteration =100;//mutation + recombination�̉�
    			int iteration = wfp.num_generation;//���㐔
    			

    			
    			textvgj=TaVtoGML.outVGJtoSt5header(textvgj);
    			int svgsize;
    			svgsize = Math.max(pop,num_gen);
    			textsvg=TaVtoGML.outSVGtoSt5header(textsvg,svgsize);
    			OutXML.out3File(bw1,textvgj);
    			OutXML.out3File(bw2,textsvg);
    			OutXML.out3File(bw4,textsvg);
    			OutXML.out3File(bw4All,textsvg);
    			OutXML.out3File(bw6,textvgj);
    			OutXML.out3File(bw6All,textvgj);
    			String headerhapfreq = ">Length of region(nt)\t"+ region+"\n"
    			+">No.total chromosomes\t" + pop +"\n" +
    					">nt/1cM\t"+ nt_morgan_ratio +"\n"+
    					">No.generation\t" + num_gen + "\n"+
    					">Mutation rate\t" + mut_rate + "\n"+ 
    					">Recombination rate/1cM\t"+rec_rate +"\n" +
    					">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+
    					"\n>Serial id\tHaplotype id\tNo.chromosomes\tMutation sites\n";
    			OutXML.out3File(bw8,headerhapfreq);
    			//OutXML.out3File(bw8All,headerhapfreq);
    			
    			//Root
    			//simulation�J�n�̃n�v���^�C�v����
//    			�S���F�͕̂ψقȂ��A����n�v���^�C�v
    			System.out.println("Root Generation is in progress");
    			IntArray4Hp tmpintarray4hp;
    			tmpintarray4hp=new IntArray4Hp();
    			haptype = new IntArray4Hp[1];
    			haptype[0]=tmpintarray4hp;
    			//haptype[0].arr=null;
    			//haptype[0][0]=-9;
    			String[] genotype;
    			genotype = new String[1];
    			//genotype[0] = "\n";
    			genotype[0] = "";
    			
    			nd_hp = new int[pop];
    			int[] gen_tot_id;
    			gen_tot_id = new int[pop];
    			
    			int[] nd_loc_x;
    			nd_loc_x = new int[pop];
    			int[] nd_loc_y;
    			nd_loc_y = new int[pop];
    			
    			int[] hp_loc_x;
    			int[] hp_loc_y;
    			hp_loc_x=new int[1];
    			hp_loc_y=new int[1];
    			
    			int[] hp_nd;
    			hp_nd = new int[pop];
    			//String freqdataout="generation\t" + gen + "\n";
    			String freqdataout="generation\t" + gen + "\n";
    			OutXML.out3File(bw5,freqdataout);
    			OutXML.out3File(bw5All,freqdataout);
    			OutXML.out3File(bw3,freqdataout);
    			
    			
    			for(int i=0;i<pop;i++){
    				
    				nd_hp[i]=0;
    				gen_tot_id[i]=nd_tot;
    				String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,0,gen,i
    						,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
    				//textvgj+=vgj;
    				nd_loc_x[i]=gen*pop;
    				nd_loc_y[i]=i*pop;
    				OutXML.out3File(bw1,vgj);
    				String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,nd_loc_x[i],nd_loc_y[i],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
    				OutXML.out3File(bw2,svg);
    				
    				String hpkata = genotype[nd_hp[i]];
    				//System.out.println("hpkata " + hpkata);
    				hpkata +=i + "\t" + hpkata + "\n";
    				OutXML.out3File(bw3,hpkata);
    			
    						
    				nd_tot++;

    			}
    			pop_before = pop;
    			//root generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
    			
    			int[] freqhp;
    			freqhp = new int[haptype.length];
    			for(int i=0;i<haptype.length;i++){
    				freqhp[i]=0;
    			}
    			for(int i=0;i<nd_hp.length;i++){
    				freqhp[nd_hp[i]]++;
    			}
    			int roothpcnt=0;
    			
    			for(int i=0;i<haptype.length;i++){
    				if(freqhp[i]>0){
    					String hpid="0\t" + roothpcnt + "\t" + i+"\n";
    					OutXML.out3File(bw21,hpid);
    					OutXML.out3File(bw21All,hpid);
    					String hpkata = "";
    					
    					for(int k=0;k<haptype[i].arr.length;k++){
    						
    						hpkata += haptype[i].arr[k] + "\t";
    					}
    					freqdataout=roothpcnt + "\t" + i +"\t" + freqhp[i] + "\t" + hpkata + "\n";
    					OutXML.out3File(bw5,freqdataout);
    					OutXML.out3File(bw5All,freqdataout);
    					hp_loc_x[i]=gen*pop;
    					hp_loc_y[i]=roothpcnt*pop;
    					double freqdb=(double)(freqhp[i])/(double)(pop);
    					String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqdb,
    							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
    					OutXML.out3File(bw4,freqsvg);
    					OutXML.out3File(bw4All,freqsvg);
    					//String freqvgj=TaVtoGML.outVGJtoSt5Node(hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
    							//NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
    					String freqvgj=TaVtoGML.outVGJtoSt6Node_URL(hpkata,hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
    							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
    					hp_nd[i]=hp_nd_tot;
    					hp_nd_tot++;
    					OutXML.out3File(bw6,freqvgj);
    					OutXML.out3File(bw6All,freqvgj);
    					
    					roothpcnt++;
    				}
    				
    			}
    			freqhp_before = freqhp;
    			gen++;
    			boolean stopflg = true;
    			for(int i=gen;i<num_gen;i++){
    				
    				if(endFlg==1){
    					sleep(1000);
    					i=gen;
    					System.out.println("held @ iteration " + i);
    				}
    				if(endFlg==2){
    					sleep(1000);
    					System.out.println("stopped @ iteration " + i);
    					if(stopflg){
    						//i=num_gen-1;
    						num_gen=i+1;
    					}
    					
    					//num_gen=i+1;
    				}
    				if(endFlg==0||i==num_gen-1){
    					System.out.println("Generation " + i + "/" + num_gen + " is in progress.");
        				//freqdataout="generation\t" + gen + "\n";
        				freqdataout="generation\t" + gen + "\n";
        				OutXML.out3File(bw5,freqdataout);
        				OutXML.out3File(bw5All,freqdataout);
        				OutXML.out3File(bw3,freqdataout);
        				
        				int pop_now=pop;
        				int[] nd_hp_tmp;
        				nd_hp_tmp = new int[pop_now];
        				int[] gen_tot_id_tmp;
        				gen_tot_id_tmp = new int[pop_now];
        				int[] nd_loc_x_tmp;
        				nd_loc_x_tmp = new int[pop_now];
        				int[] nd_loc_y_tmp;
        				nd_loc_y_tmp = new int[pop_now];
        				int[] hp_nd_tmp;
        				hp_nd_tmp = new int[hp_nd.length+pop_now];
        				//ch�e�q�y�A�L�^�p�A���C
        				IntArray4Hp choya;
        				IntArray4Hp chko;
        				//hp�e�q�y�A�L�^�p�A���C
        				IntArray4Hp hpoya;
        				IntArray4Hp hpko;
        				//haptype�u��
        				IntArray4Hp[] haptype_before;
        				haptype_before = haptype;
        				
        				choya = new IntArray4Hp();
        				chko = new IntArray4Hp();
        				hpoya = new IntArray4Hp();
        				hpko = new IntArray4Hp();
        				
        				for(int j=0;j<pop;j++){
        					double rand0 = Math.random();
        					double rec_freq = rec_rate*region/nt_morgan_ratio;
        					
        					if(rand0>rec_freq){//No recombination
        						double rand1 = Math.random();
        						int tmpoya = (int)(rand1*nd_hp.length);
        						choya.addelem(tmpoya);
        						chko.addelem(j);
        						
        						IntArray4Hp tmp_hpkata;
        						tmp_hpkata=new IntArray4Hp();
        						double rand_mut = Math.random();
        						if(rand_mut<=mut_rate){
        							//System.out.println("mutation!!");
        							double rand_mut_site = Math.random();
        							int mut_site_tmp =(int)(rand_mut_site*region);
        							mutsite[j][0]=mut_site_tmp;
        							IntArray4Hp tmp_tmp_hpkata;
        							tmp_tmp_hpkata = new IntArray4Hp();
        							boolean judge=true;
        							boolean judgeyet=true;
        							if(haptype[nd_hp[tmpoya]].arr.length==0){
        								
        								tmp_tmp_hpkata.addelem(mutsite[j][0]);
        								
        								nd_hp_tmp[j]=haptype.length;
        								IntArray4Hp[] tmp_haptype;
        								tmp_haptype = new IntArray4Hp[haptype.length+1];
        								for(int x=0;x<haptype.length;x++){
        									tmp_haptype[x]=haptype[x];
        									
        								}
        								tmp_haptype[haptype.length]=tmp_tmp_hpkata;
        								
        								haptype = null;
        								haptype=tmp_haptype;
        								
        							}else{
        								int counter=0;
        								for(int k=0;k<haptype[nd_hp[tmpoya]].arr.length;k++){
        									
        									if(haptype[nd_hp[tmpoya]].arr[k]==mutsite[j][0]){
        										
        										tmp_tmp_hpkata.addelem(mutsite[j][0]);
        										
        										judge=false;
        										judgeyet=false;
        										//System.out.println("eaqual");
        									}else if(haptype[nd_hp[tmpoya]].arr[k]<mutsite[j][0]){
        										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
        										counter++;
        										//System.out.println("more than");
        									}else if(haptype[nd_hp[tmpoya]].arr[k]>mutsite[j][0]){
        										//System.out.println("less than");
        										if(judgeyet){
        											tmp_tmp_hpkata.addelem(mutsite[j][0]);
        											counter++;
        											judgeyet=false;
        										}
        										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
        										counter++;
        										
        									
        									}
        									
        								}
        								if(judgeyet){
        									//System.out.println("add");
        									tmp_tmp_hpkata.addelem(mutsite[j][0]);
        									counter++;
        								}
        								boolean noidhp=true;
        								for(int x=0;x<haptype.length;x++){
        									boolean identicalhp = true;
        									if(haptype[x].arr.length==tmp_tmp_hpkata.arr.length){
        										for(int y=0;y<tmp_tmp_hpkata.arr.length;y++){
        											if(haptype[x].arr[y]!=tmp_tmp_hpkata.arr[y]){
        												identicalhp=false;
        												break;
        											}
        										}
        										if(identicalhp){//�Vhptype�ł͂Ȃ�
        											//nd_hp_tmp[j]=nd_hp[x];
        											nd_hp_tmp[j]=x;
        											noidhp=false;
        											
        											break;
        										}
        									}
        								}
        								if(noidhp){
        									nd_hp_tmp[j]=haptype.length;
        									IntArray4Hp[] tmp_haptype;
        									tmp_haptype = new IntArray4Hp[haptype.length+1];
        									for(int x=0;x<haptype.length;x++){
        										tmp_haptype[x]=haptype[x];
        										
        									}
        									
        									tmp_haptype[haptype.length]=tmp_tmp_hpkata;
        									
        									haptype = null;
        									haptype=tmp_haptype;
        								}
        							}
        							if(judge){
        								tmp_hpkata=tmp_tmp_hpkata;
        								}
        							
        						}else{
        							tmp_hpkata=haptype[nd_hp[tmpoya]];
        							nd_hp_tmp[j]=nd_hp[tmpoya];
        							
        						}
        						//hppair�o�^
        						boolean newpair=true;
        						for(int x=0;x<hpoya.arr.length;x++){
        							if(nd_hp[tmpoya]==hpoya.arr[x]){
        								if(nd_hp_tmp[j]==hpko.arr[x]){
        									//System.out.println("##�o�^���Ȃ� " + j);
        									newpair=false;
        								}
        								
        							}
        						}
        						if(newpair){
        							hpoya.addelem(nd_hp[tmpoya]);
        							hpko.addelem(nd_hp_tmp[j]);
        						}
        						gen_tot_id_tmp[j]=nd_tot;
        						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,1,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						nd_loc_x_tmp[j]=i*pop_now;
        						nd_loc_y_tmp[j]=j*pop_now;
        						//textvgj+=vgj;
        						OutXML.out3File(bw1,vgj);
        						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,1,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						OutXML.out3File(bw2,svg);
        						
        						String hpkata = j + "\t";
        						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
        							hpkata += haptype[nd_hp_tmp[j]].arr[k] + " ";
        						}
        						hpkata += "\n";
        						OutXML.out3File(bw3,hpkata);
        						if(i==num_gen-1){
        							System.out.println("kata out1");
        							OutXML.out3File(bw7,hpkata);
        						}
        						
        						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,0,gen_tot_id[tmpoya],NdLb,EdLb,
        								rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						String svg_ed=TaVtoGML.outSVGtoSt5Edge(0, nd_loc_x[tmpoya],nd_loc_y[tmpoya],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
        								rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						//textvgj+=vgj_ed;
        						OutXML.out3File(bw1,vgj_ed);
        						OutXML.out3File(bw2,svg_ed);
        						parent0[nd_tot]=gen_tot_id[tmpoya];
        						
        						nd_tot++;
        						ed_tot++;
        					}else{
        						//�g��������
        						//System.out.println("recombination");
        						double rand1 = Math.random();
        						double rand2 = Math.random();
        						int tmpoya1 = (int)(rand1*nd_hp.length);
        						int tmpoya2 = (int)(rand2*(nd_hp.length-1));
        						if(tmpoya2<=tmpoya1){
        							tmpoya2++;
        						}
        						choya.addelem(tmpoya1);
        						chko.addelem(j);
        						choya.addelem(tmpoya2);
        						chko.addelem(j);
        						//�g�����ʒu
        						double rand3 = Math.random();
        						int rec = (int)(rand3*region);
        						
        						recsite[j][0]=rec;
        						
        						//�Q��oyahap�ɏ�L�Ɠ���������mutation���N�����A���̏�ŁA�V�n�v���^�C�v�����
        						IntArray4Hp hptmpoya1 = haptype[nd_hp[tmpoya1]];
        						IntArray4Hp hptmpoya2 = haptype[nd_hp[tmpoya2]];
        						IntArray4Hp tmphap;
        						tmphap = new IntArray4Hp();
        						
        						double rand_event1 = Math.random();
        						double rand_event2 = Math.random();
        						if(rand_event1<=mut_rate){
        							double rand_mut_site1 = Math.random();
        							int mut_site_tmp1 =(int)(rand_mut_site1*region);
        							mutsite[j][0]=mut_site_tmp1;
        							boolean judge1=true;
        							for(int k=0;k<hptmpoya1.arr.length;k++){
        								if(hptmpoya1.arr[k]<=recsite[j][0]){
        									if(mutsite[j][0]>hptmpoya1.arr[k]){
        										tmphap.addelem(hptmpoya1.arr[k]);
        										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
        									}else if(mutsite[j][0]==hptmpoya1.arr[k]){
        										tmphap.addelem(mutsite[j][0]);
        										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
        										judge1=false;
        									}else if(mutsite[j][0]<hptmpoya1.arr[k]){
        										if(judge1){
        											tmphap.addelem(mutsite[j][0]);
        											//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
        											judge1=false;
        										}
        										tmphap.addelem(hptmpoya1.arr[k]);
        										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
        									}
        								}
        							}
        							if(judge1){
        								if(mutsite[j][0]<=recsite[j][0]){
        									tmphap.addelem(mutsite[j][0]);
        									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
        								}
        							}
        						}else{
        							for(int k=0;k<hptmpoya1.arr.length;k++){
        								if(hptmpoya1.arr[k]<=recsite[j][0]){
        									tmphap.addelem(hptmpoya1.arr[k]);
        									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
        								}
        							}
        						}
        						if(rand_event2<=mut_rate){
        							double rand_mut_site2 = Math.random();
        							int mut_site_tmp2 =(int)(rand_mut_site2*region);
        							mutsite[j][1]=mut_site_tmp2;
        							boolean judge2=true;
        							for(int k=0;k<hptmpoya2.arr.length;k++){
        								if(hptmpoya2.arr[k]>recsite[j][0]){
        									if(mutsite[j][1]>hptmpoya2.arr[k]){
        										tmphap.addelem(hptmpoya2.arr[k]);
        									}else if(mutsite[j][1]==hptmpoya2.arr[k]){
        										tmphap.addelem(mutsite[j][1]);
        										judge2=false;
        									}else if(mutsite[j][1]<hptmpoya2.arr[k]){
        										if(judge2){
        											tmphap.addelem(mutsite[j][1]);
        											judge2=false;
        										}
        										tmphap.addelem(hptmpoya2.arr[k]);
        									}
        								}
        							}
        							if(judge2){
        								if(mutsite[j][1]>recsite[j][0]){
        									tmphap.addelem(mutsite[j][1]);
        								}
        							}
        						}else{
        							for(int k=0;k<hptmpoya2.arr.length;k++){
        								if(hptmpoya2.arr[k]>recsite[j][0]){
        									tmphap.addelem(hptmpoya2.arr[k]);
        								}
        							}
        						}
        						
        						//����haplotype�ɂ��łɑ��݂��邩
        						
        						boolean noidhp=true;
        						//int max_mutsite=0;
        						
        						for(int x=0;x<haptype.length;x++){
        							boolean identicalhp = true;
        							if(haptype[x].arr.length==tmphap.arr.length){
        								//if(haptype[x].arr.length>max_mutsite){
        									//max_mutsite=haptype[x].arr.length;
        								//}
        								for(int y=0;y<tmphap.arr.length;y++){
        									if(haptype[x].arr[y]!=tmphap.arr[y]){
        										identicalhp=false;
        										break;
        									}
        								}
        								if(identicalhp){//�Vhptype�ł͂Ȃ�
        									
        									//nd_hp_tmp[j]=nd_hp[x];
        									nd_hp_tmp[j]=x;
        									
        									noidhp=false;
        									
        									break;
        								}
        							}
        						}
        						//if(tmp_tmp_hpkata.arr.length>max_mutsite){
        							//max_mutsite = tmp_tmp_hpkata.arr.length;
        						//}
        						if(noidhp){
        							
        							nd_hp_tmp[j]=haptype.length;
        							IntArray4Hp[] tmp_haptype;
        							tmp_haptype = new IntArray4Hp[haptype.length+1];
        							for(int x=0;x<haptype.length;x++){
        								tmp_haptype[x]=haptype[x];
        								
        							}
        							
        							tmp_haptype[haptype.length]=tmphap;
        							
        							haptype = null;
        							haptype = new IntArray4Hp[tmp_haptype.length];
        							haptype=tmp_haptype;
        						}
//        						hppair�o�^
        						boolean newpair=true;
        						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
        						for(int x=0;x<hpoya.arr.length;x++){
        							if(nd_hp[tmpoya1]==hpoya.arr[x]){
        								if(nd_hp_tmp[j]==hpko.arr[x]){
//        									�o�^���Ȃ�
        									newpair=false;
        								}
        								
        							}
        						}
        						if(newpair){
        							//System.out.println("hpoya�o�^");
        							hpoya.addelem(nd_hp[tmpoya1]);
        							hpko.addelem(nd_hp_tmp[j]);
        						}
//        						hppair�o�^
        						newpair=true;
        						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
        						for(int x=0;x<hpoya.arr.length;x++){
        							if(nd_hp[tmpoya2]==hpoya.arr[x]){
        								if(nd_hp_tmp[j]==hpko.arr[x]){
//        									�o�^���Ȃ�
        									newpair=false;
        								}
        								
        							}
        						}
        						if(newpair){
        							//System.out.println("hpoya�o�^");
        							hpoya.addelem(nd_hp[tmpoya2]);
        							hpko.addelem(nd_hp_tmp[j]);
        						}
        						//nd_hp_tmp[j]=nd_hp[tmpoya1];//�����̓n�v���^�C�v��{�C�œo�^����Ƃ��ɂ́A�ς���
//        						
        						gen_tot_id_tmp[j]=nd_tot;
        						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,2,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						nd_loc_x_tmp[j]=i*pop_now;
        						nd_loc_y_tmp[j]=j*pop_now;
        						//textvgj+=vgj;
        						OutXML.out3File(bw1,vgj);
        						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,2,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						OutXML.out3File(bw2,svg);
        						
        						
        						String hpkata = "";
        						hpkata +=j + "\t";
        						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
        							
        							hpkata += haptype[nd_hp_tmp[j]].arr[k] + "\t";
        						}
        						hpkata += "\n";
        						OutXML.out3File(bw3,hpkata);
        						if(i==num_gen-1){
        							System.out.println("kata out2");
        							OutXML.out3File(bw7,hpkata);
        						}
        						
        						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya1],NdLb,EdLb,
        								rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						String svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya1],nd_loc_y[tmpoya1],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
        								rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						OutXML.out3File(bw1,vgj_ed);
        						OutXML.out3File(bw2,svg_ed);
        						ed_tot++;
        						//textvgj+=vgj_ed;
        						vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya2],NdLb,EdLb,
        								rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya2],nd_loc_y[tmpoya2],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
        								rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						OutXML.out3File(bw1,vgj_ed);
        						OutXML.out3File(bw2,svg_ed);
        						parent0[nd_tot]=gen_tot_id[tmpoya1];
        						parent1[nd_tot]=gen_tot_id[tmpoya2];
        						
        						ed_tot++;
        						nd_tot++;
        					}
        					
        				}

        				
//        				���� generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
        				//freqdataout="generation\t" + gen + "\n";
        				//OutXML.out3File(bw5,freqdataout);
        				freqhp = new int[haptype.length];
        				for(int j=0;j<haptype.length;j++){
        					freqhp[j]=0;
        				}
        				for(int j=0;j<nd_hp_tmp.length;j++){
        					//System.out.println("j,nd_hp_tmp[j] "+j + " " + nd_hp_tmp[j]);
        					freqhp[nd_hp_tmp[j]]++;
        				}
        				int hptypecnt=0;
        				int[] hp_loc_x_tmp;
        				int[] hp_loc_y_tmp;
        				hp_loc_x_tmp = new int[haptype.length];
        				hp_loc_y_tmp = new int[haptype.length];
        				//System.out.println("haptype.len " + haptype.length);
        				if(i==num_gen-1){
        					System.out.println("kata out3");
        					headerhapfreq = ">Length of region(nt)\t"+ region+"\n"
			    			+">No.total chromosomes\t" + pop +"\n" +
			    					">nt/1cM\t"+ nt_morgan_ratio +"\n"+
			    					">No.generation\t" + num_gen + "\n"+
			    					">Mutation rate\t" + mut_rate + "\n"+ 
			    					">Recombination rate/1cM\t"+rec_rate +"\n" +
			    					">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+
			    					"\n>Serial id\tHaplotype id\tNo.chromosomes\tMutation sites\n";
			    			//OutXML.out3File(bw8,headerhapfreq);
			    			OutXML.out3File(bw8All,headerhapfreq);
        				}
        				for(int j=0;j<haptype.length;j++){
        					double freqdb=(double)(freqhp[j])/(double)(pop_now); 
        					if(freqhp[j]>0){
        					//if(freqdb>hapfreq4disp){
        						
        						
        						String hpkata = "";
        						
        						for(int k=0;k<haptype[j].arr.length;k++){
        							
        							hpkata += haptype[j].arr[k] + "\t";
        							
        							
        						}
        						
        						
        						texthaptypeFreq+="\n";
        						
        						freqdataout=hptypecnt + "\t" + j+"\t" + freqhp[j] + "\t" + hpkata + "\n";
        						if(freqdb>hapfreq4disp){
        							OutXML.out3File(bw5,freqdataout);
        							if(i==num_gen-1){
        								System.out.println("kata out4");
        								OutXML.out3File(bw8,freqdataout);
        								//OutXML.out3File(bw22,texthaptypeFreq);
        							}
        						}
        						OutXML.out3File(bw5All,freqdataout);
        						
        						if(i==num_gen-1){
        							System.out.println("kata out5");
        							OutXML.out3File(bw8All,freqdataout);
        							//OutXML.out3File(bw22,texthaptypeFreq);
        						}
        						hp_loc_x_tmp[j]=gen*pop_now;
        						hp_loc_y_tmp[j]=hptypecnt*pop_now;
        						
        						String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqdb,
        								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						
        						if(freqdb>hapfreq4disp){
        							OutXML.out3File(bw4,freqsvg);
        						}
        						OutXML.out3File(bw4All,freqsvg);
        						
        						//String freqvgj=TaVtoGML.outVGJtoSt5Node(hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
        								//NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						String freqvgj=TaVtoGML.outVGJtoSt6Node_URL(hpkata,hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
        								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
        						if(freqdb>hapfreq4disp){
        							OutXML.out3File(bw6,freqvgj);
        						}
        						OutXML.out3File(bw6All,freqvgj);
        						hp_nd_tmp[j]=hp_nd_tot;
        						hp_nd_tot++;
        						
        						for(int k=0;k<hpoya.arr.length;k++){
        							if(hpko.arr[k]==j){
        								String hp_svg_ed=TaVtoGML.outSVGtoSt5Edge(1, 
        										hp_loc_x[hpoya.arr[k]],hp_loc_y[hpoya.arr[k]],hp_loc_x_tmp[j],
        										hp_loc_y_tmp[j],NdLb,EdLb,
        										rootCol,mutCol,recCol,mutEdcol,recEdcol);
        								if(freqdb>hapfreq4disp){
        									OutXML.out3File(bw4,hp_svg_ed);
        								}
        								OutXML.out3File(bw4All,hp_svg_ed);
        								
        								String hp_vgj_ed=TaVtoGML.outVGJtoSt5Edge(hp_nd_tmp[j],2,hp_nd[hpoya.arr[k]],
        										NdLb,EdLb,
        										rootCol,mutCol,recCol,mutEdcol,recEdcol);
        								if(freqdb>hapfreq4disp){
        									OutXML.out3File(bw6,hp_vgj_ed);
        								}
        								OutXML.out3File(bw6All,hp_vgj_ed);
        							}
        						}
        						String hpid=i + "\t" + hptypecnt + "\t" + j+"\n";
        						if(freqdb>hapfreq4disp){
        							OutXML.out3File(bw21,hpid);
        						}
        						OutXML.out3File(bw21All,hpid);
        						
        						hptypecnt++;
        					}
        					
        				}
        				//output parent,child of ch
        				for(int j=0;j<pop_before;j++){
        					String textchild = i-1 + "\t" + j +"\t";
        					
        					for(int k=0;k<choya.arr.length;k++){
        						String textchild2 = i-1 + "\t" + j +"\t";
        						if(choya.arr[k]==j){
        							textchild += i + "\t" + chko.arr[k] + "\t";
        							textchild2 += i + "\t" + chko.arr[k] + "\t\n";
        							OutXML.out3File(bw12,"parent\t");
        							OutXML.out3File(bw12,textchild2);
        							
        							OutXML.out3File(bw14,textchild2);
        						}
        					}
        					textchild += "\n";
        					OutXML.out3File(bw9,"parent\t");
        					OutXML.out3File(bw9,textchild);
        					OutXML.out3File(bw11,textchild);
        				}
        				for(int j=0;j<pop_now;j++){
        					String textparent = i + "\t" + j +"\t";
        					
        					for(int k=0;k<choya.arr.length;k++){
        						String textparent2 = i + "\t" + j +"\t";
        						if(chko.arr[k]==j){
        							textparent += i-1 + "\t" + choya.arr[k] + "\t";
        							textparent2 += i-1 + "\t" + choya.arr[k] + "\t\n";
        							OutXML.out3File(bw12,"child\t");
        							OutXML.out3File(bw12,textparent2);
        							OutXML.out3File(bw13,textparent2);
        						}
        					}
        					textparent += "\n";
        					OutXML.out3File(bw9,"child\t");
        					OutXML.out3File(bw9,textparent);
        					OutXML.out3File(bw10,textparent);
        				}
//        				output parent,child of hp
        				for(int j=0;j<haptype_before.length;j++){
        					if(freqhp_before[j]>0){
        						String textchild = i-1 + "\t" + j +"\t";
        						
        						for(int k=0;k<hpoya.arr.length;k++){
        							String textchild2 = i-1 + "\t" + j +"\t";
        							if(hpoya.arr[k]==j){
        								textchild += i + "\t" + hpko.arr[k] + "\t";
        								textchild2 += i + "\t" + hpko.arr[k] + "\t\n";
        								OutXML.out3File(bw18,"parent\t");
        								OutXML.out3File(bw18,textchild2);
        								
        								OutXML.out3File(bw20,textchild2);
        							}
        						}
        						textchild += "\n";
        						OutXML.out3File(bw15,"parent\t");
        						OutXML.out3File(bw15,textchild);
        						OutXML.out3File(bw17,textchild);
        					}
        					
        				}
        				int freqhpcnt=0;
        				for(int j=0;j<haptype.length;j++){
        					if(freqhp[j]>0){
        						String textparent = i + "\t" + j +"\t";
        						
        						for(int k=0;k<hpoya.arr.length;k++){
        							String textparent2 = i + "\t" + j +"\t";
        							if(hpko.arr[k]==j){
        								textparent += i-1 + "\t" + hpoya.arr[k] + "\t";
        								textparent2 += i-1 + "\t" + hpoya.arr[k] + "\t\n";
        								OutXML.out3File(bw18,"child\t");
        								OutXML.out3File(bw18,textparent2);
        								OutXML.out3File(bw19,textparent2);
        							}
        						}
        						textparent += "\n";
        						OutXML.out3File(bw15,"child\t");
        						OutXML.out3File(bw15,textparent);
        						OutXML.out3File(bw16,textparent);
        					}
        					
        				}
        				
        				pop_before = pop_now;
        				
        				nd_hp = null;
        				nd_hp = new int[nd_hp_tmp.length];
        				nd_hp = nd_hp_tmp;
        				gen_tot_id = null;
        				gen_tot_id = gen_tot_id_tmp;
        				nd_loc_x=null;
        				nd_loc_y=null;
        				nd_loc_x=nd_loc_x_tmp;
        				nd_loc_y=nd_loc_y_tmp;
        				hp_loc_x=null;
        				hp_loc_y=null;
        				hp_loc_x=hp_loc_x_tmp;
        				hp_loc_y=hp_loc_y_tmp;
        				hp_nd = null;
        				freqhp_before = freqhp;
        				hp_nd = hp_nd_tmp;
//        				Last generation �Ńn�v���^�C�v�^�������o��
        				//���������^�T�C�g�̂�
        				if(i==num_gen-1){
        					IntArray4Hp[] common;
        					int positivehp=0;
        					for(int x=0;x<haptype.length;x++){
        						if(freqhp[x]>0){
        							positivehp++;
        						}
        					}
        					common = new IntArray4Hp[positivehp];
        					positivehp=0;
        					for(int x=0;x<haptype.length;x++){
        						if(freqhp[x]>0){
        							common[positivehp] = new IntArray4Hp();
        							common[positivehp] = haptype[x];
        							positivehp++;
        						}
        					}
        					System.out.println("kata out6");
        					MiscUtil2 ms = new MiscUtil2();
        					//int[] snplist = ms.snpList(haptype);
        					int[] snplist = ms.snpList(common);
        					System.out.println("kata out6.5");
        					//System.out.println("snplist");
        					String textsnplist="";
        					for(int x=0;x<snplist.length;x++){
        						textsnplist += snplist[x] + "\t";
        						//System.out.println(snplist[x]);/
        					}
        					OutXML.out3File(bw23,textsnplist);
        					System.out.println("kata out7");
        					int hapkata[][]= new int[haptype.length][snplist.length];
        					for(int j=0;j<haptype.length;j++){
        						for(int k=0;k<snplist.length;k++){
        							hapkata[j][k]=0;
        						}
        					}
        					for(int j=0;j<haptype.length;j++){
        						for(int k=0;k<haptype[j].arr.length;k++){
        							for(int l=0;l<snplist.length;l++){
        								if(haptype[j].arr[k]==snplist[l]){
        									hapkata[j][l]=1;
        								}
        							}
        							
        						}
        					}
        					System.out.println("kata out8");
        					for(int j=0;j<haptype.length;j++){
        						double freqdb=(double)(freqhp[j])/(double)(pop_now); 
        						if(freqhp[j]>0){
        							
        								
        							texthaptypeFreq ="";
        							for(int k=0;k<snplist.length;k++){
        								texthaptypeFreq += hapkata[j][k];
        							}
        								
        							texthaptypeFreq+="\n";
        							if(freqdb>hapfreq4disp){
        								OutXML.out3File(bw22,texthaptypeFreq);
        								
        							}
        							OutXML.out3File(bw22All,texthaptypeFreq);
        						}
        					}
        					System.out.println("kata out9");
        					//common haplotype�݂̂�
        					int commonHpnum=0;
        					for(int j=0;j<haptype.length;j++){
        						double freqdb=(double)(freqhp[j])/(double)(pop_now); 
        						if(freqhp[j]>0){
        							if(freqdb>hapfreq4disp){
        								commonHpnum++;
        							}
        						}
        					}
        					/*
        					IntArray4Hp[] commonHaptype = new IntArray4Hp[commonHpnum];
        					int commonHpcnt=0;
        					for(int j=0;j<haptype.length;j++){
        						double freqdb=(double)(freqhp[j])/(double)(pop_now); 
        						if(freqhp[j]>0){
        							if(freqdb>hapfreq4disp){
        								commonHaptype[commonHpcnt] = new IntArray4Hp();
        								for(int k=0;k<haptype[j].arr.length;k++){
        									commonHaptype[commonHpcnt].addelem(haptype[i].arr[k]);
        								}
        								commonHpcnt++;
        							}
        						}
        					}
        					snplist = ms.snpList(commonHaptype);
        					textsnplist="";
        					for(int x=0;x<snplist.length;x++){
        						textsnplist += snplist[x] + "\t";
        						//System.out.println(snplist[x]);/
        					}
        					OutXML.out3File(bw25,textsnplist);
        					
        					int commonhapkata[][]= new int[commonHaptype.length][snplist.length];
        					for(int j=0;j<commonHaptype.length;j++){
        						for(int k=0;k<snplist.length;k++){
        							commonhapkata[j][k]=0;
        						}
        					}
        					for(int j=0;j<commonHaptype.length;j++){
        						for(int k=0;k<commonHaptype[j].arr.length;k++){
        							for(int l=0;l<snplist.length;l++){
        								if(commonHaptype[j].arr[k]==snplist[l]){
        									commonhapkata[j][l]=1;
        								}
        							}
        							
        						}
        					}
        					
        					for(int j=0;j<commonHaptype.length;j++){
        						//double freqdb=(double)(freqhp[j])/(double)(pop_now); 
        						//if(freqhp[j]>0){
        							//if(freqdb>hapfreq4disp){
        								
        								texthaptypeFreq ="";
        								for(int k=0;k<snplist.length;k++){
        									texthaptypeFreq += commonhapkata[j][k];
        								}
        								
        								texthaptypeFreq+="\n";
        								OutXML.out3File(bw24,texthaptypeFreq);
        								
        							//}
        							OutXML.out3File(bw24All,texthaptypeFreq);
        						//}
        					}
        					*/
        				}
        				
        				gen++;System.out.println("gen++ i " + i);
    				}
    				
    				
    			}
    			
    			
    			textvgj="";
    			textvgj=TaVtoGML.outVGJtoSt5footer(textvgj);
    			OutXML.out3File(bw1,textvgj);
    			textsvg="";
    			textsvg=TaVtoGML.outSVGtoSt5footer(textsvg);
    			OutXML.out3File(bw2,textsvg);
    			OutXML.out3File(bw4,textsvg);
    			OutXML.out3File(bw4All,textsvg);
    			OutXML.out3File(bw6,textvgj);
    			OutXML.out3File(bw6All,textvgj);
    			//OutXML.out2File(vgjfile,textvgj);
    			bw1.close();
    			bw2.close();
    			bw3.close();
    			bw4.close();
    			bw4All.close();
    			bw5.close();
    			bw5All.close();
    			bw6.close();
    			bw6All.close();
    			bw7.close();
    			bw8.close();
    			bw8All.close();
    			bw9.close();
    			bw10.close();
    			bw11.close();
    			bw12.close();
    			bw13.close();
    			bw14.close();
    			bw15.close();
    			bw16.close();
    			bw17.close();
    			bw18.close();
    			bw19.close();
    			bw20.close();
    			bw21.close();
    			bw21All.close();
    			bw22.close();
    			bw22All.close();
    			bw23.close();
    			/*
    			bw24.close();
    			bw24All.close();
    			bw25.close();
    			*/
    			

    			String mss0 = "  �V�~�����[�V�����I��(Cancel�����ꍇ���r���܂ł̌��ʂ��o�͂���Ă��܂�)�B";
            	String mss1 = "  VGJ�E�B���h�E�̃��j���[�o�[����AFile Open (GML)�ɂ�gml�g���q�̂���";
            	String mss2 = "  �t�@�C����I�Ԃƕ`�}����܂��Bsvg�g���q�̃t�@�C���̓u���E�U�ɂĕ\������܂��B";
            	String mss3 = "  ���̑��̏o�̓t�@�C���̓V�~�����[�V�������ʂ𗘗p���邽�߂̂��̂ł��B";
    	        JFrame fa = new JFrame("Directions");
    	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
    	        JLabel dir0 = new JLabel(mss0);
    	        JLabel dir1 = new JLabel(mss1);
    	    	JLabel dir2 = new JLabel(mss2);
    	    	JLabel dir3 = new JLabel(mss3);
    	    	JPanel pdir0;
    	    	JPanel pdir1;
    	    	JPanel pdir2;
    	    	JPanel pdir3;
    	    	pdir0 = new JPanel();
    	    	pdir1 = new JPanel();
    	    	pdir2 = new JPanel();
    	    	pdir3 = new JPanel();
    	    	pdir0.add(dir0);
    	    	pdir1.add(dir1);
    	    	pdir2.add(dir2);
    	    	pdir3.add(dir3);
    	    	fa.getContentPane().add(pdir0);
    	    	fa.getContentPane().add(pdir1);
    	    	fa.getContentPane().add(pdir2);
    	    	fa.getContentPane().add(pdir3);
    	    	fa.setLocation(300,500);
    	        fa.setSize(600,300);
    	        fa.setVisible(true);
    	        
    		}catch(Exception e){
    			System.out.println(e);
    		}
    		

            
            
        }
    }
    //�{�^���N���b�N���̃A�N�V�������X�i
    private class PushButtonActionListener implements ActionListener{
        JFrame f = null;
        public PushButtonActionListener(JFrame af) {
               this.f = af;
        }
        //"Start"�{�^���������ꂽ��AendFlg��0(MyThread�����s�������)�ɂ��āAMyThread���J�n����
        //"Cancel"�{�^���������ꂽ��AendFlg��1(MyThread�����s���Ȃ�����)�ɂ���B
        //���̌��ʁAMyThread�̃��[�v���~�܂�
        
        public void actionPerformed(ActionEvent ae){
        	JFrame jf = new JFrame("Message");
        	JLabel jl = new JLabel("");
        	JPanel jp = new JPanel();
        	
        	
            if(ae.getActionCommand()=="Start & Restart"){
            	endFlg=0;
            	if(only1){
            		MyThread mt = new MyThread(args,wfp);
            		mt.start();
            		only1 = false;
            	}
            	
            	
            	
            }else if(ae.getActionCommand()=="Hold"){
            	endFlg = 1;
            	//jl = new JLabel("");
            	//jp = new JPanel();
            	jf.getContentPane().remove(jp);
            	jp=null;
            	jl=null;
            	jl = new JLabel("You can restart");
            	
            }else if(ae.getActionCommand()=="Exit"){
            	endFlg = 2;
            	//jl = new JLabel("");
            	//jp = new JPanel();
            	jf.getContentPane().remove(jp);
            	jp=null;
            	//jl=null;
            	//jl = new JLabel("Outputs so far are available");
            	
            }
//          �L�����Z����A���b�Z�[�W���o���A�ăX�^�[�g�𑣂�
        	//JLabel jl = new JLabel("You can restart");
            if(endFlg==1){
            	jf.getContentPane().removeAll();
            	jp = new JPanel();
        	
            	jp.add(jl);
            	jf.getContentPane().add(jp);
            	jf.setLocation(75, 150);
            	jf.setSize(200,100);
            	jf.setVisible(true);
            }else{
            	
            }
        	
        }    
    }
	
    
    
    public  static void main3(String[] args,WrightFisherParameter_Ref wfp_) {
		//Cancel_WFSim2_2 wf = new Cancel_WFSim2_2();
		
		try{
//			WrightFisherParameters�ǂݍ���
			//WrightFisherParameter wfp;
			//wfp = new WrightFisherParameter();
			WrightFisherParameter_Ref wfp = new WrightFisherParameter_Ref();
			wfp = wfp_;
			int region = wfp.region_length;
			int pop = wfp.population_size;//1���l�A���F�̂�2���{
			double nt_morgan_ratio = wfp.nt_morgan_ratio;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
			int num_gen = wfp.num_generation;
			double mut_rate = wfp.mutation_rate;
			double rec_rate = wfp.recombination_rate;
			double hapfreq4disp = wfp.hapfreq4disp;
			
			//���s���O
			//�����ʂ��ăJ�E���g
			int gen=0;//����
			int nd_tot=0;//�S���F��(node)
			int ed_tot=0;//�S�G�b�W
			int hp_nd_tot=0;
			
			
			//������ŃJ�E���g
			int num_ch=0;
			//int[][] haptype;//�n�v���^�C�v�^
			IntArray4Hp[] haptype;
			int[] num_hp;//�n�v���^�C�v���Ƃ̐l��
			int[] nd_hp;//���F�̂̃n�v���^�C�v�^
			
			//graph
			int[][] child;//oyaid���1�A�q�������2�A�l��koid
			child = null;
			int event[][];//oyaid���1�A�q�������2�A�l�̓C�x���gID
			event = null;
			int[] parent0;//koid���1�A�l��oyaid
			int[] parent1;//koid���2�A�l��oyaid2(���Ȃ����null)
			parent0=new int[pop*num_gen];
			parent1=new int[pop*num_gen];
			int[] eventtype;//eventid���1�A�^�C�v(coalescent(0),recombination(1))
			int[][] recsite;//eventid���1�A��������2�Arecombination�ʒu�̍�����ԍ����l
			int[][] mutsite;//eventid���1�A��������2�Amutation�ʒu���l
			eventtype=null;
			//recsite=null;
			mutsite=new int[pop][2];
			recsite=new int[pop][1];
			
			int pop_before;
			int[] freqhp_before;
			
			//�o�̓p�����^
			GMLoutParameters gmloutp;
			gmloutp = new GMLoutParameters();
			
			int NdLb=gmloutp.NdLb;
			int EdLb=gmloutp.EdLb;
			int rootCol=gmloutp.rootCol;
			int mutCol=gmloutp.mutCol;
			int recCol=gmloutp.recCol;
			int mutEdcol=gmloutp.mutEdcol;
			int recEdcol=gmloutp.recEdcol;
			int origin=gmloutp.origin;
			
			
			
			//output setting 
			
			String textlog="";
			String textvgj="";
			String textgen="";
			String textgenhp="";
			String textsvg="";
			String texthaptypeFreq="";
			
			//String rootdir = "C:\\Java\\WrightFisher\\WFSimOut";
			String rootdir = args[0];
			//3 types(�S�́A�؂̏W�܂�A�X�̖�)�̃O���t�����t�@�C��
			//�S��
			
			String logfile=rootdir+"\\log.txt";
			String vgjfile=rootdir+"\\FIG_G_individual.gml";//bw1
			String svgfile=rootdir+"\\FIG_S_individual.svg";//bw2
			
			String genotypefile=rootdir+"\\DATA_ch_allgen.txt";//bw3
			String freqsvgfile=rootdir+"\\FIG_S_hapfreq.svg";//bw4
			String freqsvgfileAll=rootdir+"\\FIG_S_hapfreqAll.svg";//bw4All
			String freqdatafile=rootdir+"\\DATA_hp_common_allgen.txt";//bw5
			String freqdatafileAll=rootdir+"\\DATA_hp_all_allgen.txt";//bw5All
			String freqvgjfile=rootdir+"\\FIG_G_hapfreq.gml";//bw6
			String freqvgjfileAll=rootdir+"\\FIG_G_hapfreqAll.gml";//bw6All
			String genotypefile_last=rootdir+"\\DATA_ch_lastgen.txt";//bw7
			String freqdatafile_last=rootdir+"\\DATA_hp_common_lastgen.txt";//bw8
			String freqdatafile_lastAll=rootdir+"\\DATA_hp_all_lastgen.txt";//bw8All
			
			String parentchildfile =rootdir + "\\GRAPH_ch_parentchild_1.txt";//bw9
			String childfile =rootdir + "\\GRAPH_ch_child_1.txt";//bw10
			String parentfile =rootdir + "\\GRAPH_ch_parent_1.txt";//bw11
			String parentchildfile2 =rootdir + "\\GRAPH_ch_parentchild_2.txt";//bw12
			String parentfile2 =rootdir + "\\GRAPH_ch_parent_2.txt";//bw13
			String childfile2 =rootdir + "\\GRAPH_ch_child_2.txt";//bw14
			String hpparentchildfile =rootdir + "\\GRAPH_hp_parentchild_1.txt";//bw15
			String hpparentfile =rootdir + "\\GRAPH_hp_parent_1.txt";//bw16
			String hpchildfile =rootdir + "\\GRAPH_hp_child_1.txt";//bw17
			String hpparentchildfile2 =rootdir + "\\GRAPH_hp_parentchild_2.txt";//bw18
			String hpparentfile2 =rootdir + "\\GRAPH_hp_parent_2.txt";//bw19
			String hpchildfile2 =rootdir + "\\GRAPH_hp_child_2.txt";//bw20
			String hpidfile = rootdir + "\\DATA_hpid_common_allgen.txt";//bw21
			String hpidfileAll = rootdir + "\\DATA_hpid_all_allgen.txt";//bw21All
			String haptypeFreq = rootdir + "\\DATA_hpseq_common_lastgen.txt";//bw22
			String haptypeFreqAll = rootdir + "\\DATA_hpseq_all_lastgen.txt";//bw22All
			String snplist_last = rootdir + "\\DATA_snplist_lastgen.txt";//bw23
			/*
			String haptypeFreqCommon = rootdir + "\\DATA_haptypeFreqCommon.txt";//bw24
			String haptypeFreqAllCommon = rootdir + "\\DATA_haptypeFreqAllCommon.txt";//bw24All
			String snplist_lastCommon = rootdir + "\\DATA_snplist_lastCommon.txt";//bw25
			*/
			
			BufferedWriter bw1;
			BufferedWriter bw2;
			BufferedWriter bw3;
			
			BufferedWriter bw4;
			BufferedWriter bw4All;
			BufferedWriter bw5;
			BufferedWriter bw5All;
			BufferedWriter bw6;
			BufferedWriter bw6All;
			BufferedWriter bw7;
			
			BufferedWriter bw8;
			BufferedWriter bw8All;
			BufferedWriter bw9;
			BufferedWriter bw10;
			BufferedWriter bw11;
			BufferedWriter bw12;
			BufferedWriter bw13;
			BufferedWriter bw14;
			BufferedWriter bw15;
			BufferedWriter bw16;
			BufferedWriter bw17;
			BufferedWriter bw18;
			BufferedWriter bw19;
			BufferedWriter bw20;
			BufferedWriter bw21;
			BufferedWriter bw21All;
			BufferedWriter bw22;
			BufferedWriter bw22All;
			BufferedWriter bw23;
			
			/*
			BufferedWriter bw24;
			BufferedWriter bw24All;
			BufferedWriter bw25;
			*/
			
			bw1=null;
			bw2=null;
			bw3=null;
			
			bw4=null;
			bw4All=null;
			bw5=null;
			bw5All=null;
			bw6=null;
			bw6All=null;
			bw7=null;
			
			bw8=null;
			bw8All=null;
			bw9=null;
			bw10=null;
			bw11=null;
			bw12=null;
			bw13=null;
			bw14=null;
			bw15=null;
			bw16=null;
			bw17=null;
			bw18=null;
			bw19=null;
			bw20=null;
			bw21=null;
			bw21All=null;
			bw22=null;
			bw22All=null;
			bw23=null;
			/*
			bw24=null;
			bw24All=null;
			bw25=null;
			*/
			try{
				bw1 = new BufferedWriter(new FileWriter(vgjfile));
				bw2 = new BufferedWriter(new FileWriter(svgfile));
				bw3 = new BufferedWriter(new FileWriter(genotypefile));
				
				bw4 = new BufferedWriter(new FileWriter(freqsvgfile));
				bw4All = new BufferedWriter(new FileWriter(freqsvgfileAll));
				bw5 = new BufferedWriter(new FileWriter(freqdatafile));
				bw5All = new BufferedWriter(new FileWriter(freqdatafileAll));
				bw6 = new BufferedWriter(new FileWriter(freqvgjfile));
				bw6All = new BufferedWriter(new FileWriter(freqvgjfileAll));
				bw7 = new BufferedWriter(new FileWriter(genotypefile_last));
				bw8 = new BufferedWriter(new FileWriter(freqdatafile_last));
				bw8All = new BufferedWriter(new FileWriter(freqdatafile_lastAll));
				bw9 = new BufferedWriter(new FileWriter(parentchildfile));
				bw10 = new BufferedWriter(new FileWriter(parentfile));
				bw11 = new BufferedWriter(new FileWriter(childfile));
				bw12 = new BufferedWriter(new FileWriter(parentchildfile2));
				bw13 = new BufferedWriter(new FileWriter(parentfile2));
				bw14 = new BufferedWriter(new FileWriter(childfile2));
				bw15 = new BufferedWriter(new FileWriter(hpparentchildfile));
				bw16 = new BufferedWriter(new FileWriter(hpparentfile));
				bw17 = new BufferedWriter(new FileWriter(hpchildfile));
				bw18 = new BufferedWriter(new FileWriter(hpparentchildfile2));
				bw19 = new BufferedWriter(new FileWriter(hpparentfile2));
				bw20 = new BufferedWriter(new FileWriter(hpchildfile2));
				bw21 = new BufferedWriter(new FileWriter(hpidfile));
				bw21All = new BufferedWriter(new FileWriter(hpidfileAll));
				bw22 = new BufferedWriter(new FileWriter(haptypeFreq));
				bw22All = new BufferedWriter(new FileWriter(haptypeFreqAll));
				bw23 = new BufferedWriter(new FileWriter(snplist_last));
				/*
				bw24 = new BufferedWriter(new FileWriter(haptypeFreqCommon));
				bw24All = new BufferedWriter(new FileWriter(haptypeFreqAllCommon));
				bw25 = new BufferedWriter(new FileWriter(snplist_lastCommon));
				*/
			}catch(Exception e){
				
				System.out.println(e);

			}
			
			/*
			String genoutroot=rootdir+"\\gen";
			
			
			String outarg = rootdir + "\\out_arg.txt";
			//�g�����ɂ�蕪�������u�؁v�̏W�܂�(�u�сv)
			String outforest = rootdir + "\\out_forest.txt";
			String outforestTr = rootdir + "\\out_forestTr.txt";
			String outfr_vine = rootdir + "\\out_fr_vine.txt";
			//�X�́u�؁v
			String outtrees = rootdir + "\\out_trees_";
			String outtrees_sf ="";
			String outpajek2 = rootdir + "\\out2.txt";
			String outevent = rootdir + "\\event.txt";
			*/
			
			//simulation settings
			//int numsnp = 200;//SNP�̐��A�z�񒷂ɂ�����
			int numsnp = wfp.region_length;//SNP�̐��A�z�񒷂ɂ�����
			//int iteration =100;//mutation + recombination�̉�
			int iteration = wfp.num_generation;//���㐔
			

			
			textvgj=TaVtoGML.outVGJtoSt5header(textvgj);
			int svgsize;
			svgsize = Math.max(pop,num_gen);
			textsvg=TaVtoGML.outSVGtoSt5header(textsvg,svgsize);
			OutXML.out3File(bw1,textvgj);
			OutXML.out3File(bw2,textsvg);
			OutXML.out3File(bw4,textsvg);
			OutXML.out3File(bw4All,textsvg);
			OutXML.out3File(bw6,textvgj);
			OutXML.out3File(bw6All,textvgj);
			String headerhapfreq = ">Length of region(nt)\t"+ region+"\n"
			+">No.total chromosomes\t" + pop +"\n" +
					">nt/1cM\t"+ nt_morgan_ratio +"\n"+
					">No.generation\t" + num_gen + "\n"+
					">Mutation rate\t" + mut_rate + "\n"+ 
					">Recombination rate/1cM\t"+rec_rate +"\n" +
					">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+
					"\n>Serial id\tHaplotype id\tNo.chromosomes\tMutation sites\n";
			OutXML.out3File(bw8,headerhapfreq);
			OutXML.out3File(bw8All,headerhapfreq);
			
			//Root
			//simulation�J�n�̃n�v���^�C�v����
//			�S���F�͕̂ψقȂ��A����n�v���^�C�v
			System.out.println("Root Generation is in progress");
			IntArray4Hp tmpintarray4hp;
			tmpintarray4hp=new IntArray4Hp();
			haptype = new IntArray4Hp[1];
			haptype[0]=tmpintarray4hp;
			//haptype[0].arr=null;
			//haptype[0][0]=-9;
			String[] genotype;
			genotype = new String[1];
			//genotype[0] = "\n";
			genotype[0] = "";
			
			nd_hp = new int[pop];
			int[] gen_tot_id;
			gen_tot_id = new int[pop];
			
			int[] nd_loc_x;
			nd_loc_x = new int[pop];
			int[] nd_loc_y;
			nd_loc_y = new int[pop];
			
			int[] hp_loc_x;
			int[] hp_loc_y;
			hp_loc_x=new int[1];
			hp_loc_y=new int[1];
			
			int[] hp_nd;
			hp_nd = new int[pop];
			//String freqdataout="generation\t" + gen + "\n";
			String freqdataout="generation\t" + gen + "\n";
			OutXML.out3File(bw5,freqdataout);
			OutXML.out3File(bw5All,freqdataout);
			OutXML.out3File(bw3,freqdataout);
			
			
			for(int i=0;i<pop;i++){
				
				nd_hp[i]=0;
				gen_tot_id[i]=nd_tot;
				String vgj=TaVtoGML.outVGJtoSt5Node(nd_tot,0,gen,i
						,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				//textvgj+=vgj;
				nd_loc_x[i]=gen*pop;
				nd_loc_y[i]=i*pop;
				OutXML.out3File(bw1,vgj);
				String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,nd_loc_x[i],nd_loc_y[i],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				OutXML.out3File(bw2,svg);
				
				String hpkata = genotype[nd_hp[i]];
				//System.out.println("hpkata " + hpkata);
				hpkata +=i + "\t" + hpkata + "\n";
				OutXML.out3File(bw3,hpkata);
			
						
				nd_tot++;

			}
			pop_before = pop;
			//root generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
			
			int[] freqhp;
			freqhp = new int[haptype.length];
			for(int i=0;i<haptype.length;i++){
				freqhp[i]=0;
			}
			for(int i=0;i<nd_hp.length;i++){
				freqhp[nd_hp[i]]++;
			}
			int roothpcnt=0;
			
			for(int i=0;i<haptype.length;i++){
				if(freqhp[i]>0){
					String hpid="0\t" + roothpcnt + "\t" + i+"\n";
					OutXML.out3File(bw21,hpid);
					OutXML.out3File(bw21All,hpid);
					String hpkata = "";
					
					for(int k=0;k<haptype[i].arr.length;k++){
						
						hpkata += haptype[i].arr[k] + "\t";
					}
					freqdataout=roothpcnt + "\t" + i +"\t" + freqhp[i] + "\t" + hpkata + "\n";
					OutXML.out3File(bw5,freqdataout);
					OutXML.out3File(bw5All,freqdataout);
					hp_loc_x[i]=gen*pop;
					hp_loc_y[i]=roothpcnt*pop;
					double freqdb=(double)(freqhp[i])/(double)(pop);
					String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqdb,
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					OutXML.out3File(bw4,freqsvg);
					OutXML.out3File(bw4All,freqsvg);
					//String freqvgj=TaVtoGML.outVGJtoSt5Node(hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
							//NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					String freqvgj=TaVtoGML.outVGJtoSt6Node(hpkata,hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					hp_nd[i]=hp_nd_tot;
					hp_nd_tot++;
					OutXML.out3File(bw6,freqvgj);
					OutXML.out3File(bw6All,freqvgj);
					
					roothpcnt++;
				}
				
			}
			freqhp_before = freqhp;
			gen++;
			
			for(int i=gen;i<num_gen;i++){
				System.out.println("Generation " + i + "/" + num_gen + " is in progress.");
				//freqdataout="generation\t" + gen + "\n";
				freqdataout="generation\t" + gen + "\n";
				OutXML.out3File(bw5,freqdataout);
				OutXML.out3File(bw5All,freqdataout);
				OutXML.out3File(bw3,freqdataout);
				
				int pop_now=pop;
				int[] nd_hp_tmp;
				nd_hp_tmp = new int[pop_now];
				int[] gen_tot_id_tmp;
				gen_tot_id_tmp = new int[pop_now];
				int[] nd_loc_x_tmp;
				nd_loc_x_tmp = new int[pop_now];
				int[] nd_loc_y_tmp;
				nd_loc_y_tmp = new int[pop_now];
				int[] hp_nd_tmp;
				hp_nd_tmp = new int[hp_nd.length+pop_now];
				//ch�e�q�y�A�L�^�p�A���C
				IntArray4Hp choya;
				IntArray4Hp chko;
				//hp�e�q�y�A�L�^�p�A���C
				IntArray4Hp hpoya;
				IntArray4Hp hpko;
				//haptype�u��
				IntArray4Hp[] haptype_before;
				haptype_before = haptype;
				
				choya = new IntArray4Hp();
				chko = new IntArray4Hp();
				hpoya = new IntArray4Hp();
				hpko = new IntArray4Hp();
				
				for(int j=0;j<pop;j++){
					double rand0 = Math.random();
					double rec_freq = rec_rate*region/nt_morgan_ratio;
					
					if(rand0>rec_freq){//No recombination
						double rand1 = Math.random();
						int tmpoya = (int)(rand1*nd_hp.length);
						choya.addelem(tmpoya);
						chko.addelem(j);
						
						IntArray4Hp tmp_hpkata;
						tmp_hpkata=new IntArray4Hp();
						double rand_mut = Math.random();
						if(rand_mut<=mut_rate){
							//System.out.println("mutation!!");
							double rand_mut_site = Math.random();
							int mut_site_tmp =(int)(rand_mut_site*region);
							mutsite[j][0]=mut_site_tmp;
							IntArray4Hp tmp_tmp_hpkata;
							tmp_tmp_hpkata = new IntArray4Hp();
							boolean judge=true;
							boolean judgeyet=true;
							if(haptype[nd_hp[tmpoya]].arr.length==0){
								
								tmp_tmp_hpkata.addelem(mutsite[j][0]);
								
								nd_hp_tmp[j]=haptype.length;
								IntArray4Hp[] tmp_haptype;
								tmp_haptype = new IntArray4Hp[haptype.length+1];
								for(int x=0;x<haptype.length;x++){
									tmp_haptype[x]=haptype[x];
									
								}
								tmp_haptype[haptype.length]=tmp_tmp_hpkata;
								
								haptype = null;
								haptype=tmp_haptype;
								
							}else{
								int counter=0;
								for(int k=0;k<haptype[nd_hp[tmpoya]].arr.length;k++){
									
									if(haptype[nd_hp[tmpoya]].arr[k]==mutsite[j][0]){
										
										tmp_tmp_hpkata.addelem(mutsite[j][0]);
										
										judge=false;
										judgeyet=false;
										//System.out.println("eaqual");
									}else if(haptype[nd_hp[tmpoya]].arr[k]<mutsite[j][0]){
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										//System.out.println("more than");
									}else if(haptype[nd_hp[tmpoya]].arr[k]>mutsite[j][0]){
										//System.out.println("less than");
										if(judgeyet){
											tmp_tmp_hpkata.addelem(mutsite[j][0]);
											counter++;
											judgeyet=false;
										}
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										
									
									}
									
								}
								if(judgeyet){
									//System.out.println("add");
									tmp_tmp_hpkata.addelem(mutsite[j][0]);
									counter++;
								}
								boolean noidhp=true;
								for(int x=0;x<haptype.length;x++){
									boolean identicalhp = true;
									if(haptype[x].arr.length==tmp_tmp_hpkata.arr.length){
										for(int y=0;y<tmp_tmp_hpkata.arr.length;y++){
											if(haptype[x].arr[y]!=tmp_tmp_hpkata.arr[y]){
												identicalhp=false;
												break;
											}
										}
										if(identicalhp){//�Vhptype�ł͂Ȃ�
											//nd_hp_tmp[j]=nd_hp[x];
											nd_hp_tmp[j]=x;
											noidhp=false;
											
											break;
										}
									}
								}
								if(noidhp){
									nd_hp_tmp[j]=haptype.length;
									IntArray4Hp[] tmp_haptype;
									tmp_haptype = new IntArray4Hp[haptype.length+1];
									for(int x=0;x<haptype.length;x++){
										tmp_haptype[x]=haptype[x];
										
									}
									
									tmp_haptype[haptype.length]=tmp_tmp_hpkata;
									
									haptype = null;
									haptype=tmp_haptype;
								}
							}
							if(judge){
								tmp_hpkata=tmp_tmp_hpkata;
								}
							
						}else{
							tmp_hpkata=haptype[nd_hp[tmpoya]];
							nd_hp_tmp[j]=nd_hp[tmpoya];
							
						}
						//hppair�o�^
						boolean newpair=true;
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
									//System.out.println("##�o�^���Ȃ� " + j);
									newpair=false;
								}
								
							}
						}
						if(newpair){
							hpoya.addelem(nd_hp[tmpoya]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						gen_tot_id_tmp[j]=nd_tot;
						String vgj=TaVtoGML.outVGJtoSt5Node(nd_tot,1,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i*pop_now;
						nd_loc_y_tmp[j]=j*pop_now;
						//textvgj+=vgj;
						OutXML.out3File(bw1,vgj);
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,1,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw2,svg);
						
						String hpkata = j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + " ";
						}
						hpkata += "\n";
						OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							System.out.println("kata out7");
							OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,0,gen_tot_id[tmpoya],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(0, nd_loc_x[tmpoya],nd_loc_y[tmpoya],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//textvgj+=vgj_ed;
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya];
						
						nd_tot++;
						ed_tot++;
					}else{
						//�g��������
						//System.out.println("recombination");
						double rand1 = Math.random();
						double rand2 = Math.random();
						int tmpoya1 = (int)(rand1*nd_hp.length);
						int tmpoya2 = (int)(rand2*(nd_hp.length-1));
						if(tmpoya2<=tmpoya1){
							tmpoya2++;
						}
						choya.addelem(tmpoya1);
						chko.addelem(j);
						choya.addelem(tmpoya2);
						chko.addelem(j);
						//�g�����ʒu
						double rand3 = Math.random();
						int rec = (int)(rand3*region);
						
						recsite[j][0]=rec;
						
						//�Q��oyahap�ɏ�L�Ɠ���������mutation���N�����A���̏�ŁA�V�n�v���^�C�v�����
						IntArray4Hp hptmpoya1 = haptype[nd_hp[tmpoya1]];
						IntArray4Hp hptmpoya2 = haptype[nd_hp[tmpoya2]];
						IntArray4Hp tmphap;
						tmphap = new IntArray4Hp();
						
						double rand_event1 = Math.random();
						double rand_event2 = Math.random();
						if(rand_event1<=mut_rate){
							double rand_mut_site1 = Math.random();
							int mut_site_tmp1 =(int)(rand_mut_site1*region);
							mutsite[j][0]=mut_site_tmp1;
							boolean judge1=true;
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									if(mutsite[j][0]>hptmpoya1.arr[k]){
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}else if(mutsite[j][0]==hptmpoya1.arr[k]){
										tmphap.addelem(mutsite[j][0]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
										judge1=false;
									}else if(mutsite[j][0]<hptmpoya1.arr[k]){
										if(judge1){
											tmphap.addelem(mutsite[j][0]);
											//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
											judge1=false;
										}
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}
								}
							}
							if(judge1){
								if(mutsite[j][0]<=recsite[j][0]){
									tmphap.addelem(mutsite[j][0]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}else{
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									tmphap.addelem(hptmpoya1.arr[k]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}
						if(rand_event2<=mut_rate){
							double rand_mut_site2 = Math.random();
							int mut_site_tmp2 =(int)(rand_mut_site2*region);
							mutsite[j][1]=mut_site_tmp2;
							boolean judge2=true;
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									if(mutsite[j][1]>hptmpoya2.arr[k]){
										tmphap.addelem(hptmpoya2.arr[k]);
									}else if(mutsite[j][1]==hptmpoya2.arr[k]){
										tmphap.addelem(mutsite[j][1]);
										judge2=false;
									}else if(mutsite[j][1]<hptmpoya2.arr[k]){
										if(judge2){
											tmphap.addelem(mutsite[j][1]);
											judge2=false;
										}
										tmphap.addelem(hptmpoya2.arr[k]);
									}
								}
							}
							if(judge2){
								if(mutsite[j][1]>recsite[j][0]){
									tmphap.addelem(mutsite[j][1]);
								}
							}
						}else{
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									tmphap.addelem(hptmpoya2.arr[k]);
								}
							}
						}
						
						//����haplotype�ɂ��łɑ��݂��邩
						
						boolean noidhp=true;
						//int max_mutsite=0;
						
						for(int x=0;x<haptype.length;x++){
							boolean identicalhp = true;
							if(haptype[x].arr.length==tmphap.arr.length){
								//if(haptype[x].arr.length>max_mutsite){
									//max_mutsite=haptype[x].arr.length;
								//}
								for(int y=0;y<tmphap.arr.length;y++){
									if(haptype[x].arr[y]!=tmphap.arr[y]){
										identicalhp=false;
										break;
									}
								}
								if(identicalhp){//�Vhptype�ł͂Ȃ�
									
									//nd_hp_tmp[j]=nd_hp[x];
									nd_hp_tmp[j]=x;
									
									noidhp=false;
									
									break;
								}
							}
						}
						//if(tmp_tmp_hpkata.arr.length>max_mutsite){
							//max_mutsite = tmp_tmp_hpkata.arr.length;
						//}
						if(noidhp){
							
							nd_hp_tmp[j]=haptype.length;
							IntArray4Hp[] tmp_haptype;
							tmp_haptype = new IntArray4Hp[haptype.length+1];
							for(int x=0;x<haptype.length;x++){
								tmp_haptype[x]=haptype[x];
								
							}
							
							tmp_haptype[haptype.length]=tmphap;
							
							haptype = null;
							haptype = new IntArray4Hp[tmp_haptype.length];
							haptype=tmp_haptype;
						}
//						hppair�o�^
						boolean newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya1]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya1]);
							hpko.addelem(nd_hp_tmp[j]);
						}
//						hppair�o�^
						newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya2]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya2]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						//nd_hp_tmp[j]=nd_hp[tmpoya1];//�����̓n�v���^�C�v��{�C�œo�^����Ƃ��ɂ́A�ς���
//						
						gen_tot_id_tmp[j]=nd_tot;
						String vgj=TaVtoGML.outVGJtoSt5Node(nd_tot,2,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i*pop_now;
						nd_loc_y_tmp[j]=j*pop_now;
						//textvgj+=vgj;
						OutXML.out3File(bw1,vgj);
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,2,nd_loc_x_tmp[j],nd_loc_y_tmp[j],0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw2,svg);
						
						
						String hpkata = "";
						hpkata +=j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + "\t";
						}
						hpkata += "\n";
						OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							System.out.println("kata out8");
							OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya1],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya1],nd_loc_y[tmpoya1],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						ed_tot++;
						//textvgj+=vgj_ed;
						vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya2],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya2],nd_loc_y[tmpoya2],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						OutXML.out3File(bw1,vgj_ed);
						OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya1];
						parent1[nd_tot]=gen_tot_id[tmpoya2];
						
						ed_tot++;
						nd_tot++;
					}
					
				}

				
//				���� generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
				//freqdataout="generation\t" + gen + "\n";
				//OutXML.out3File(bw5,freqdataout);
				freqhp = new int[haptype.length];
				for(int j=0;j<haptype.length;j++){
					freqhp[j]=0;
				}
				for(int j=0;j<nd_hp_tmp.length;j++){
					//System.out.println("j,nd_hp_tmp[j] "+j + " " + nd_hp_tmp[j]);
					freqhp[nd_hp_tmp[j]]++;
				}
				int hptypecnt=0;
				int[] hp_loc_x_tmp;
				int[] hp_loc_y_tmp;
				hp_loc_x_tmp = new int[haptype.length];
				hp_loc_y_tmp = new int[haptype.length];
				//System.out.println("haptype.len " + haptype.length);
				for(int j=0;j<haptype.length;j++){
					double freqdb=(double)(freqhp[j])/(double)(pop_now); 
					if(freqhp[j]>0){
					//if(freqdb>hapfreq4disp){
						
						
						String hpkata = "";
						
						for(int k=0;k<haptype[j].arr.length;k++){
							
							hpkata += haptype[j].arr[k] + "\t";
							
							
						}
						
						
						texthaptypeFreq+="\n";
						
						freqdataout=hptypecnt + "\t" + j+"\t" + freqhp[j] + "\t" + hpkata + "\n";
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw5,freqdataout);
							if(i==num_gen-1){
								OutXML.out3File(bw8,freqdataout);
								//OutXML.out3File(bw22,texthaptypeFreq);
							}
						}
						OutXML.out3File(bw5All,freqdataout);
						
						if(i==num_gen-1){
							OutXML.out3File(bw8All,freqdataout);
							//OutXML.out3File(bw22,texthaptypeFreq);
						}
						hp_loc_x_tmp[j]=gen*pop_now;
						hp_loc_y_tmp[j]=hptypecnt*pop_now;
						
						String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqdb,
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw4,freqsvg);
						}
						OutXML.out3File(bw4All,freqsvg);
						
						//String freqvgj=TaVtoGML.outVGJtoSt5Node(hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
								//NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String freqvgj=TaVtoGML.outVGJtoSt6Node(hpkata,hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw6,freqvgj);
						}
						OutXML.out3File(bw6All,freqvgj);
						hp_nd_tmp[j]=hp_nd_tot;
						hp_nd_tot++;
						
						for(int k=0;k<hpoya.arr.length;k++){
							if(hpko.arr[k]==j){
								String hp_svg_ed=TaVtoGML.outSVGtoSt5Edge(1, 
										hp_loc_x[hpoya.arr[k]],hp_loc_y[hpoya.arr[k]],hp_loc_x_tmp[j],
										hp_loc_y_tmp[j],NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								if(freqdb>hapfreq4disp){
									OutXML.out3File(bw4,hp_svg_ed);
								}
								OutXML.out3File(bw4All,hp_svg_ed);
								
								String hp_vgj_ed=TaVtoGML.outVGJtoSt5Edge(hp_nd_tmp[j],2,hp_nd[hpoya.arr[k]],
										NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								if(freqdb>hapfreq4disp){
									OutXML.out3File(bw6,hp_vgj_ed);
								}
								OutXML.out3File(bw6All,hp_vgj_ed);
							}
						}
						String hpid=i + "\t" + hptypecnt + "\t" + j+"\n";
						if(freqdb>hapfreq4disp){
							OutXML.out3File(bw21,hpid);
						}
						OutXML.out3File(bw21All,hpid);
						
						hptypecnt++;
					}
					
				}
				//output parent,child of ch
				for(int j=0;j<pop_before;j++){
					String textchild = i-1 + "\t" + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textchild2 = i-1 + "\t" + j +"\t";
						if(choya.arr[k]==j){
							textchild += i + "\t" + chko.arr[k] + "\t";
							textchild2 += i + "\t" + chko.arr[k] + "\t\n";
							OutXML.out3File(bw12,"parent\t");
							OutXML.out3File(bw12,textchild2);
							
							OutXML.out3File(bw14,textchild2);
						}
					}
					textchild += "\n";
					OutXML.out3File(bw9,"parent\t");
					OutXML.out3File(bw9,textchild);
					OutXML.out3File(bw11,textchild);
				}
				for(int j=0;j<pop_now;j++){
					String textparent = i + "\t" + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textparent2 = i + "\t" + j +"\t";
						if(chko.arr[k]==j){
							textparent += i-1 + "\t" + choya.arr[k] + "\t";
							textparent2 += i-1 + "\t" + choya.arr[k] + "\t\n";
							OutXML.out3File(bw12,"child\t");
							OutXML.out3File(bw12,textparent2);
							OutXML.out3File(bw13,textparent2);
						}
					}
					textparent += "\n";
					OutXML.out3File(bw9,"child\t");
					OutXML.out3File(bw9,textparent);
					OutXML.out3File(bw10,textparent);
				}
//				output parent,child of hp
				for(int j=0;j<haptype_before.length;j++){
					if(freqhp_before[j]>0){
						String textchild = i-1 + "\t" + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textchild2 = i-1 + "\t" + j +"\t";
							if(hpoya.arr[k]==j){
								textchild += i + "\t" + hpko.arr[k] + "\t";
								textchild2 += i + "\t" + hpko.arr[k] + "\t\n";
								OutXML.out3File(bw18,"parent\t");
								OutXML.out3File(bw18,textchild2);
								
								OutXML.out3File(bw20,textchild2);
							}
						}
						textchild += "\n";
						OutXML.out3File(bw15,"parent\t");
						OutXML.out3File(bw15,textchild);
						OutXML.out3File(bw17,textchild);
					}
					
				}
				int freqhpcnt=0;
				for(int j=0;j<haptype.length;j++){
					if(freqhp[j]>0){
						String textparent = i + "\t" + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textparent2 = i + "\t" + j +"\t";
							if(hpko.arr[k]==j){
								textparent += i-1 + "\t" + hpoya.arr[k] + "\t";
								textparent2 += i-1 + "\t" + hpoya.arr[k] + "\t\n";
								OutXML.out3File(bw18,"child\t");
								OutXML.out3File(bw18,textparent2);
								OutXML.out3File(bw19,textparent2);
							}
						}
						textparent += "\n";
						OutXML.out3File(bw15,"child\t");
						OutXML.out3File(bw15,textparent);
						OutXML.out3File(bw16,textparent);
					}
					
				}
				
				pop_before = pop_now;
				
				nd_hp = null;
				nd_hp = new int[nd_hp_tmp.length];
				nd_hp = nd_hp_tmp;
				gen_tot_id = null;
				gen_tot_id = gen_tot_id_tmp;
				nd_loc_x=null;
				nd_loc_y=null;
				nd_loc_x=nd_loc_x_tmp;
				nd_loc_y=nd_loc_y_tmp;
				hp_loc_x=null;
				hp_loc_y=null;
				hp_loc_x=hp_loc_x_tmp;
				hp_loc_y=hp_loc_y_tmp;
				hp_nd = null;
				freqhp_before = freqhp;
				hp_nd = hp_nd_tmp;
//				Last generation �Ńn�v���^�C�v�^�������o��
				//���������^�T�C�g�̂�
				if(i==num_gen-1){
					MiscUtil2 ms = new MiscUtil2();
					int[] snplist = ms.snpList(haptype);
					//System.out.println("snplist");
					String textsnplist="";
					for(int x=0;x<snplist.length;x++){
						textsnplist += snplist[x] + "\t";
						//System.out.println(snplist[x]);/
					}
					OutXML.out3File(bw23,textsnplist);
					int hapkata[][]= new int[haptype.length][snplist.length];
					for(int j=0;j<haptype.length;j++){
						for(int k=0;k<snplist.length;k++){
							hapkata[j][k]=0;
						}
					}
					for(int j=0;j<haptype.length;j++){
						for(int k=0;k<haptype[j].arr.length;k++){
							for(int l=0;l<snplist.length;l++){
								if(haptype[j].arr[k]==snplist[l]){
									hapkata[j][l]=1;
								}
							}
							
						}
					}
					
					for(int j=0;j<haptype.length;j++){
						double freqdb=(double)(freqhp[j])/(double)(pop_now); 
						if(freqhp[j]>0){
							
								
							texthaptypeFreq ="";
							for(int k=0;k<snplist.length;k++){
								texthaptypeFreq += hapkata[j][k];
							}
								
							texthaptypeFreq+="\n";
							if(freqdb>hapfreq4disp){
								OutXML.out3File(bw22,texthaptypeFreq);
								
							}
							OutXML.out3File(bw22All,texthaptypeFreq);
						}
					}
					//common haplotype�݂̂�
					int commonHpnum=0;
					for(int j=0;j<haptype.length;j++){
						double freqdb=(double)(freqhp[j])/(double)(pop_now); 
						if(freqhp[j]>0){
							if(freqdb>hapfreq4disp){
								commonHpnum++;
							}
						}
					}
					/*
					IntArray4Hp[] commonHaptype = new IntArray4Hp[commonHpnum];
					int commonHpcnt=0;
					for(int j=0;j<haptype.length;j++){
						double freqdb=(double)(freqhp[j])/(double)(pop_now); 
						if(freqhp[j]>0){
							if(freqdb>hapfreq4disp){
								commonHaptype[commonHpcnt] = new IntArray4Hp();
								for(int k=0;k<haptype[j].arr.length;k++){
									commonHaptype[commonHpcnt].addelem(haptype[i].arr[k]);
								}
								commonHpcnt++;
							}
						}
					}
					snplist = ms.snpList(commonHaptype);
					textsnplist="";
					for(int x=0;x<snplist.length;x++){
						textsnplist += snplist[x] + "\t";
						//System.out.println(snplist[x]);/
					}
					OutXML.out3File(bw25,textsnplist);
					
					int commonhapkata[][]= new int[commonHaptype.length][snplist.length];
					for(int j=0;j<commonHaptype.length;j++){
						for(int k=0;k<snplist.length;k++){
							commonhapkata[j][k]=0;
						}
					}
					for(int j=0;j<commonHaptype.length;j++){
						for(int k=0;k<commonHaptype[j].arr.length;k++){
							for(int l=0;l<snplist.length;l++){
								if(commonHaptype[j].arr[k]==snplist[l]){
									commonhapkata[j][l]=1;
								}
							}
							
						}
					}
					
					for(int j=0;j<commonHaptype.length;j++){
						//double freqdb=(double)(freqhp[j])/(double)(pop_now); 
						//if(freqhp[j]>0){
							//if(freqdb>hapfreq4disp){
								
								texthaptypeFreq ="";
								for(int k=0;k<snplist.length;k++){
									texthaptypeFreq += commonhapkata[j][k];
								}
								
								texthaptypeFreq+="\n";
								OutXML.out3File(bw24,texthaptypeFreq);
								
							//}
							OutXML.out3File(bw24All,texthaptypeFreq);
						//}
					}
					*/
				}
				
				gen++;
			}
			
			
			textvgj="";
			textvgj=TaVtoGML.outVGJtoSt5footer(textvgj);
			OutXML.out3File(bw1,textvgj);
			textsvg="";
			textsvg=TaVtoGML.outSVGtoSt5footer(textsvg);
			OutXML.out3File(bw2,textsvg);
			OutXML.out3File(bw4,textsvg);
			OutXML.out3File(bw4All,textsvg);
			OutXML.out3File(bw6,textvgj);
			OutXML.out3File(bw6All,textvgj);
			//OutXML.out2File(vgjfile,textvgj);
			bw1.close();
			bw2.close();
			bw3.close();
			bw4.close();
			bw4All.close();
			bw5.close();
			bw5All.close();
			bw6.close();
			bw6All.close();
			bw7.close();
			bw8.close();
			bw8All.close();
			bw9.close();
			bw10.close();
			bw11.close();
			bw12.close();
			bw13.close();
			bw14.close();
			bw15.close();
			bw16.close();
			bw17.close();
			bw18.close();
			bw19.close();
			bw20.close();
			bw21.close();
			bw21All.close();
			bw22.close();
			bw22All.close();
			bw23.close();
			/*
			bw24.close();
			bw24All.close();
			bw25.close();
			*/
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		

	}


    public  static void main4(String[] args,WrightFisherParameter_Ref wfp_){
    	Cancel_WFSim2_2 wf = new Cancel_WFSim2_2(args,wfp_);
    }

}
