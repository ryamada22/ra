/*
 * �쐬��: 2005/10/30
 *
 * TODO Reverse�����̃V�~�����[�V�����J�n���̃p�����^���̓t���[��
 */
package treeANDvine;

/**
 * @author Ryo Yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */

//	Sample17
	import java.awt.*;
	import java.awt.event.*;
	import javax.swing.*;
	import java.lang.Object;
	
	public class InputFrameRev extends JFrame{
		int inputFileType;
		JTextField tf01=new JTextField("10",8);//num_iteration
		/*
	    JTextField tf02=new JTextField("100",8);
	    JTextField tf03=new JTextField("100000",8);
	    JTextField tf04=new JTextField("50",8);
	    JTextField tf05=new JTextField("0.1",8);
	    JTextField tf06=new JTextField("0.1",8);
	    */
	    JTextField tf07=new JTextField("C:\\\\WF_ARG",10);//indir
	    JTextField tf08=new JTextField("hapfreqdata_last_gen.txt",10);//infile
	    JTextField tf09=new JTextField("C:\\retrohaplotype\\Mult2\\Out\\",10);//infile
	    JLabel lb01=new JLabel("No. iteration <integer>");
	    /*
	    JLabel lb02=new JLabel("Ancestral population size <integer>");
	    JLabel lb03=new JLabel("Physical length of 1cM (nt) <integer>");
	    JLabel lb04=new JLabel("No. generation to simulate <integer>");
	    JLabel lb05=new JLabel("Mutation rate <rational>");
	    JLabel lb06=new JLabel("Recombination rate <rational>");
	    */
	    JLabel lb07=new JLabel("Directory for input file<text>");
	    JLabel lb08=new JLabel("Input file <text>");
	    JLabel lb09=new JLabel("Directory for output files<text>");
	    //JLabel lb07a=new JLabel("!!Create directory \"C:\\\\WF_ARG\" or specify as you like!!");
	    
	    JLabel lb07_1=new JLabel("Mutation rate is average number of ");
	    JLabel lb07_2=new JLabel("mutational substitutions of base per");
	    JLabel lb07_3=new JLabel("1Mb per generation.");
		JLabel lb08_1=new JLabel("Recombination rate is probability of ");
		JLabel lb08_2=new JLabel("recombination per 1 Morgan per generation.");
		JLabel lb08_3=new JLabel("Therefore 0.01 is default.              ");
		
		
		
		
//�{�^����ǉ�
        JButton b01=new JButton("Apply & Run");
        
	    //�又��
	    public static void main(String ar[]){
	    	InputFrameRev sample = new InputFrameRev();
	    }
	    //�R���X�g���N�^
	    public InputFrameRev(){
	    	
	    	
	        // �t���[�����쐬
	        JFrame f=new JFrame("Input parameters");
	        
	        
	        f.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	        //f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	        
	        b01.setActionCommand("Apply & Run");
	        b01.addActionListener(new PushButtonActionListener(f));
	        
	        // �{�^���ƃe�L�X�g�t�B�[���h�����C�A�E�g
	        JPanel p1=new JPanel();
	        p1.add(lb01);
	        p1.add(tf01);
	        f.getContentPane().add(p1);
	        /*
	        JPanel p2=new JPanel();
	        p2.add(lb02);
	        p2.add(tf02);
	        f.getContentPane().add(p2);
	        JPanel p3=new JPanel();
	        p3.add(lb03);
	        p3.add(tf03);
	        f.getContentPane().add(p3);
	        JPanel p4=new JPanel();
	        p4.add(lb04);
	        p4.add(tf04);
	        f.getContentPane().add(p4);
	        JPanel p5=new JPanel();
	        p5.add(lb05);
	        p5.add(tf05);
	        f.getContentPane().add(p5);
	        JPanel p6=new JPanel();
	        p6.add(lb06);
	        p6.add(tf06);
	        f.getContentPane().add(p6);
	        */
	        JPanel p7=new JPanel();
	        p7.add(lb07);
	        p7.add(tf07);
	        f.getContentPane().add(p7);
	        JPanel p8=new JPanel();
	        p8.add(lb08);
	        p8.add(tf08);
	        
	        f.getContentPane().add(p8);
	        
	        JPanel p9=new JPanel();
	        p9.add(lb09);
	        p9.add(tf09);
	        f.getContentPane().add(p9);
	        //JPanel p7a=new JPanel();
	        //p7a.add(lb07a);
	        //f.getContentPane().add(p7a);
	        
	        JPanel p7_1=new JPanel();
	        p7_1.add(lb07_1);
	        f.getContentPane().add(p7_1);
	        JPanel p7_2=new JPanel();
	        p7_2.add(lb07_2);
	        f.getContentPane().add(p7_2);
	        JPanel p7_3=new JPanel();
	        p7_3.add(lb07_3);
	        f.getContentPane().add(p7_3);
	        JPanel p8_1=new JPanel();
	        p8_1.add(lb08_1);
	        f.getContentPane().add(p8_1);
	        JPanel p8_2=new JPanel();
	        p8_2.add(lb08_2);
	        f.getContentPane().add(p8_2);
	        JPanel p8_3=new JPanel();
	        p8_3.add(lb08_3);
	        f.getContentPane().add(p8_3);
	        JPanel pb=new JPanel();
	        pb.add(b01);
	        
	        f.getContentPane().add(pb);
	        // �t���[����\��
	        f.setLocation(600, 50);
	        f.setSize(400,500);
	        f.setVisible(true);
	        
	        String mss1 = "  Make or choose directory for outputs as you like. ";
	        String mss2 = "  And specify it in \"Input parameters\" window. ";
	        String mss3 = "  Please be PATIENT particularly when run a large/long conditions. ";
	        String mss4 = "  Message box will appear when simulation ends. ";
	        JFrame fa = new JFrame("Messages");
	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	    	//ErrDialog dia=new ErrDialog(fa,"Error Message",err);
	        JLabel dir1 = new JLabel(mss1);
	        JLabel dir2 = new JLabel(mss2);
	        JLabel dir3 = new JLabel(mss3);
	        JLabel dir4 = new JLabel(mss4);
	    	JPanel pdir1;
	    	JPanel pdir2;
	    	JPanel pdir3;
	    	JPanel pdir4;
	    	pdir1 = new JPanel();
	    	pdir1.add(dir1);
	    	pdir2 = new JPanel();
	    	pdir2.add(dir2);
	    	pdir3 = new JPanel();
	    	pdir3.add(dir3);
	    	//pdir3.setBackground(Color.orange);
	    	pdir4 = new JPanel();
	    	pdir4.add(dir4);
	    	fa.getContentPane().add(pdir1);
	    	fa.getContentPane().add(pdir2);
	    	fa.getContentPane().add(pdir3);
	    	fa.getContentPane().add(pdir4);
	    	fa.setLocation(300,400);
	        fa.setSize(600,200);
	        //fa.setBackground(Color.red);
	        fa.setVisible(true);
	    }
	    
	    public InputFrameRev(int filetype){
	    	//0��default��001010�^�C�v
	    	//1��WrightFisher�V�~�����[�V�����̏o�̓^�C�v
	    	inputFileType =filetype;
	    	System.out.println("inputFileType " + inputFileType);
	        // �t���[�����쐬
	        JFrame f=new JFrame("Input parameters");
	        
	        
	        f.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	        //f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	        
	        b01.setActionCommand("Apply & Run");
	        b01.addActionListener(new PushButtonActionListener(f));
	        
	        // �{�^���ƃe�L�X�g�t�B�[���h�����C�A�E�g
	        JPanel p1=new JPanel();
	        p1.add(lb01);
	        p1.add(tf01);
	        f.getContentPane().add(p1);
	        /*
	        JPanel p2=new JPanel();
	        p2.add(lb02);
	        p2.add(tf02);
	        f.getContentPane().add(p2);
	        JPanel p3=new JPanel();
	        p3.add(lb03);
	        p3.add(tf03);
	        f.getContentPane().add(p3);
	        JPanel p4=new JPanel();
	        p4.add(lb04);
	        p4.add(tf04);
	        f.getContentPane().add(p4);
	        JPanel p5=new JPanel();
	        p5.add(lb05);
	        p5.add(tf05);
	        f.getContentPane().add(p5);
	        JPanel p6=new JPanel();
	        p6.add(lb06);
	        p6.add(tf06);
	        f.getContentPane().add(p6);
	        */
	        JPanel p7=new JPanel();
	        p7.add(lb07);
	        p7.add(tf07);
	        f.getContentPane().add(p7);
	        JPanel p8=new JPanel();
	        p8.add(lb08);
	        p8.add(tf08);
	        if(inputFileType == 0){
	        	p8.setBackground(Color.orange);
	        }else if(inputFileType == 1){
	        	
	        	
	        	p8.setBackground(Color.cyan);
	        }
	        
	        f.getContentPane().add(p8);
	        JPanel p9=new JPanel();
	        p9.add(lb09);
	        p9.add(tf09);
	        f.getContentPane().add(p9);
	        //JPanel p7a=new JPanel();
	        //p7a.add(lb07a);
	        //f.getContentPane().add(p7a);
	        
	        JPanel p7_1=new JPanel();
	        p7_1.add(lb07_1);
	        f.getContentPane().add(p7_1);
	        JPanel p7_2=new JPanel();
	        p7_2.add(lb07_2);
	        f.getContentPane().add(p7_2);
	        JPanel p7_3=new JPanel();
	        p7_3.add(lb07_3);
	        f.getContentPane().add(p7_3);
	        JPanel p8_1=new JPanel();
	        p8_1.add(lb08_1);
	        f.getContentPane().add(p8_1);
	        JPanel p8_2=new JPanel();
	        p8_2.add(lb08_2);
	        f.getContentPane().add(p8_2);
	        JPanel p8_3=new JPanel();
	        p8_3.add(lb08_3);
	        f.getContentPane().add(p8_3);
	        JPanel pb=new JPanel();
	        pb.add(b01);
	        
	        f.getContentPane().add(pb);
	        // �t���[����\��
	        f.setLocation(600, 50);
	        f.setSize(400,500);
	        f.setVisible(true);
	        
	        String mss1 = "  Make or choose directory for outputs as you like. ";
	        String mss2 = "  And specify it in \"Input parameters\" window. ";
	        String mss3 = "  Please be PATIENT particularly when run a large/long conditions. ";
	        String mss4 = "  Message box will appear when simulation ends. ";
	        JFrame fa = new JFrame("Messages");
	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	    	//ErrDialog dia=new ErrDialog(fa,"Error Message",err);
	        JLabel dir1 = new JLabel(mss1);
	        JLabel dir2 = new JLabel(mss2);
	        JLabel dir3 = new JLabel(mss3);
	        JLabel dir4 = new JLabel(mss4);
	    	JPanel pdir1;
	    	JPanel pdir2;
	    	JPanel pdir3;
	    	JPanel pdir4;
	    	pdir1 = new JPanel();
	    	pdir1.add(dir1);
	    	pdir2 = new JPanel();
	    	pdir2.add(dir2);
	    	pdir3 = new JPanel();
	    	pdir3.add(dir3);
	    	
	    	//pdir3.setBackground(Color.red);
	    	pdir4 = new JPanel();
	    	pdir4.add(dir4);
	    	fa.getContentPane().add(pdir1);
	    	fa.getContentPane().add(pdir2);
	    	fa.getContentPane().add(pdir3);
	    	fa.getContentPane().add(pdir4);
	    	fa.setLocation(300,400);
	        fa.setSize(600,200);
	        //fa.setBackground(Color.red);
	        
	        fa.setVisible(true);
	    }
	    

	    //�{�^���N���b�N���̃A�N�V�������X�i
	    private class PushButtonActionListener implements ActionListener{
	        JFrame f = null;
	        public PushButtonActionListener(JFrame af) {
	               this.f = af;
	        }
	        public void actionPerformed(ActionEvent ae){
	            
	            if(ae.getActionCommand()=="Apply & Run"){
	            	
	            	int int1 = Integer.parseInt(tf01.getText());
	            	/*
	            	int int2 = Integer.parseInt(tf02.getText());
	            	int int3 = Integer.parseInt(tf03.getText());
	            	int int4 = Integer.parseInt(tf04.getText());
	            	double double5 = Double.parseDouble(tf05.getText());
	            	double double6 = Double.parseDouble(tf06.getText());
	            	double ans = int1 + int2 + int3 + int4 + double5 + double6;
	            	*/
	            	String rootdir = tf07.getText();
	            	//System.out.println("rootdir " + rootdir);
	            	String infile = tf08.getText();
	            	//System.out.println("rootdir " + infile);
	            	String outdir = tf09.getText();
	                WrightFisherParameter_Ref_Rev wfp;
	                wfp = new WrightFisherParameter_Ref_Rev();
	                wfp.num_iteration = int1;
	                
	            	/*
	            	WrightFisherParameter_Ref wfp;
	            	wfp = new WrightFisherParameter_Ref();
	            	wfp.region_length = int1;//nucleotide��100base�̂Ƃ�100
	            	wfp.population_size = int2*2;//1���l�A���F�̂�2���{
	            	wfp.nt_morgan_ratio = int3;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
	            	wfp.num_generation = int4;
	            	wfp.mutation_rate = double5;
	            	wfp.recombination_rate = double6;
	            	
	            	wfp.hapfreq4disp = 0;
	            	*/
	                    //ErrDialog dia=new ErrDialog(this.f,"Error Message",err);
	            	/*
	            	WFSim2_2 sim;
	            	sim = new WFSim2_2();
	            	*/
	                /*
	                RetroFromTxtMult sim;
	            	String a[] = {rootdir,infile};
	            	sim.run5(a,wfp); 
	            	*/
	                InOutCtrl ioctl;
	            	
	            	ioctl = new InOutCtrl();
	            	String a[] = {rootdir,infile,outdir};
	            	//ioctl.main2(a,wfp);
	            	ioctl.main3(a,inputFileType,wfp);
	                
	            	String mss0 = "  Simulation ended.";
	            	String mss1 = "  Open \".bml\" file(s) via Menu of VGJ window \"File->Open\".";
	            	String mss2 = "  Open \".svg\" file(s) via SVG viewer.";
	            	String mss3 = "  Other multiple files are logs or for further usages of simulational population.";
	    	        JFrame fa = new JFrame("Directions");
	    	        fa.setLayout(new FlowLayout(FlowLayout.CENTER, 2, 2));
	    	        JLabel dir0 = new JLabel(mss0);
	    	        JLabel dir1 = new JLabel(mss1);
	    	    	JLabel dir2 = new JLabel(mss2);
	    	    	JLabel dir3 = new JLabel(mss3);
	    	    	JPanel pdir0;
	    	    	JPanel pdir1;
	    	    	JPanel pdir2;
	    	    	JPanel pdir3;
	    	    	pdir0 = new JPanel();
	    	    	pdir1 = new JPanel();
	    	    	pdir2 = new JPanel();
	    	    	pdir3 = new JPanel();
	    	    	pdir0.add(dir0);
	    	    	pdir1.add(dir1);
	    	    	pdir2.add(dir2);
	    	    	pdir3.add(dir3);
	    	    	fa.getContentPane().add(pdir0);
	    	    	fa.getContentPane().add(pdir1);
	    	    	fa.getContentPane().add(pdir2);
	    	    	fa.getContentPane().add(pdir3);
	    	    	fa.setLocation(300,500);
	    	        fa.setSize(600,100);
	    	        fa.setVisible(true);
	                    return;
	                
	                
	            }
	        }    
	    }
	    
	    
	    //�_�C�A���O
	    class ErrDialog extends JDialog{
	        ErrDialog(Frame f,String title,String msg) {
	            // ���[�_���_�C�A���O���쐬
	            JDialog dia = new JDialog(f, title, true);
	            // ���x����ǉ�
	            JLabel lab = new JLabel(msg);
	            dia.getContentPane().add(BorderLayout.NORTH, lab);
	            // ���[�_���_�C�A���O��\��
	            dia.setLocation(250, 250);
	            dia.setSize(600, 100);
	            dia.setVisible(true);
	        }
	    }
	}


