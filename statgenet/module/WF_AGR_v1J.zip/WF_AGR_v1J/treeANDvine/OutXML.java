/*
 * �쐬��: 2005/08/23
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * @author Ryo Yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
public class OutXML {

	public static void main(String[] args) {
		
	}
	public static String HeaderXML(){
		String st="<?xml version=\"1.0\" encoding=\"Shift_JIS\" ?>\n";
		
		
		return st;
	}
	public static String NodeHeaderXML(){
		String st ="<Nodes>\n";
		return st;
	}
	public static String NodeFooterXML(){
		String st ="</Nodes>\n";
		return st;
	}
	public static String EdgeHeaderXML(){
		String st ="<Edges>\n";
		return st;
	}
	public static String EdgeFooterXML(){
		String st ="</Edges>\n";
		return st;
	}
	public static String Node2XML(treeANDvine.Node n){
		
		String st ="";
		st += "\t<id>" + n.id + "</id>\n";
		st += "\t<Graph>" + n.gr.id + "</Graph>\n";
		st += "\t<Label>" + n.gr.label + "</Label>\n";
		st += "\t<Type>" + n.gr.type + "</Type>\n";
		st += "\t<Haplotype1>\n";
		for(int i=0;i<n.hp[0].hp.length;i++){
			st += "\t\t<SNP>" + n.hp[0].hp[i] + "</SNP>\n";
		}
		st += "\t<Haplotype1>\n";
 		st += "\t<Edge>\n";
		for(int i=0;i<n.edge.length;i++){
			st += "\t\t<id>" + n.edge[i].id + "</id>\n";
		}
		st += "\t</Edge>\n";
		st += "\t<Location>\n" + "\t\t<x>" + n.x + "</x>\n"
							+ "\t\t<y>" + n.x + "</y>\n"
							+"\t\t<z>" + n.x + "</z>\n"
							+ "\t</Location>\n";
		
		return st;
	}
	public static String Node2XMLTab(treeANDvine.Node n,int t,int len){
		String tab="\n";
		for(int i=0;i<t;i++){
			tab+="\t";
		}
		String st ="";
		for(int i=0;i<t;i++){
			st+="\t";
		}
		st += "\t<id>" + n.id + "</id>"+tab;
		st += "\t<Graph>" + n.gr.id + "</Graph>"+tab;
		st += "\t<Label>" + n.label + "</Label>"+tab;
		int nodetype=TaVtoGML.nodeType(n);
		st += "\t<Type>" + n.type + "</Type>"+tab;
		st += "\t<NodeType>" + nodetype + "</NodeType>"+tab;
		st += "\t<Haplotype>"+tab;
		st += "\t\t<Segments>"+tab;
		for(int i=0;i<n.hp[0].st.length;i++){
			st +="\t\t\t<Segment>"+tab;
			st +="\t\t\t\t<ID>" + i + "</ID>"+tab;
			st+="\t\t\t\t\t<Start>"+n.hp[0].st[i]+"</Start>";
			st+="\t\t\t\t\t<End>"+n.hp[0].end[i]+"</End>";
			st +="\t\t\t</Segment>"+tab;
		}
		
		st += "\t\t</Segments>"+tab;
		st += "\t\t<Haplotype1>"+tab;
		for(int j=0;j<n.hp[0].hp.length;j++){
			st += "\t\t\t<SNP>"+tab;
			st += "\t\t\t\t<Location>" + n.hp[0].hp[j] + "</Location>"+tab;
			st += "\t\t\t</SNP>"+tab;
		}
		st += "\t\t</Haplotype1>"+tab;
		
		//haplotype
		String hp="";
		Haplotype haplo=n.hp[0];
		int tmphap[];
		tmphap = new int[len];
		if(n.hp[0].part == 1){
			for(int i=0;i<len;i++){
				tmphap[i]=9;
			}
		}else{
			for(int i=0;i<len;i++){
				tmphap[i]=0;
			}
		}
		
		int counter=0;
		for(int i=0;i<n.hp[0].st.length;i++){
			for(int j=n.hp[0].st[i];j<=n.hp[0].end[i];j++){
				tmphap[j]=0;
			}
		}
		for(int i=0;i<n.hp[0].hp.length;i++){
			tmphap[n.hp[0].hp[i]]=1;
		}
		for(int i=0;i<len;i++){
			hp+=tmphap[i];
		}
		st += "\t\t<Haplotype2>"+ hp + "</Haplotype2>" + tab;
		st += "\t</Haplotype>"+tab;
		st += "\t<Edges>"+tab;
		st += "\t\t<Number>"+tab;
		st += "\t\t\t<Total>" + n.edge.length + "</Total>"+tab;
		
		int ined,outed;
		ined=0;
		if(nodetype==0){
			ined=0;
		}else if(nodetype==1){
			ined=1;
		}else if(nodetype==2){
			ined=2;
		}
		outed=n.edge.length-ined;
		st += "\t\t\t<In>" + ined + "</In>"+tab;
		st += "\t\t\t<Out>" + outed + "</Out>"+tab;
		st += "\t\t</Number>\n"+tab;
 		st += "\t\t<Edge>"+tab;
		for(int j=0;j<n.edge.length;j++){
			st += "\t\t\t<id>" + n.edge[j].id + "</id>"+tab;
		}
		
		st += "\t\t</Edge>"+tab;
		st += "\t</Edges>"+tab;
		st += "\t<Location>"+tab;
		st += "\t\t<x>" + n.x + "</x>"+tab;
		st += "\t\t<y>" + n.y + "</y>"+tab;
		st += "\t\t<z>" + n.z + "</z>"+tab;
		st += "\t</Location>\n";
		
		
		return st;
	}
	public static String Edge2XMLTab(treeANDvine.Edge n,int t){
		String tab="\n";
		for(int i=0;i<t;i++){
			tab+="\t";
		}
		String st ="";
		for(int i=0;i<t;i++){
			st+="\t";
		}
		st += "\t<id>" + n.id + "</id>"+tab;
		st += "\t<Graph>" + n.gr.id + "</Graph>"+tab;
		st += "\t<Site>"+tab;
		
		int nodetype=TaVtoGML.nodeType(n.end);
		if(nodetype==0){
			st += "\t\t<Mutation>" + n.label + "</Mutation>"+tab;
		}else if(nodetype==1){
			st += "\t\t<Mutation>" + n.label + "</Mutation>"+tab;
		}else if(nodetype==2){
			st += "\t\t<Recombination5>" + n.rec1 + "</Recombination5>"+tab;
			st += "\t\t<Recombination3>" + n.rec2 + "</Recombination3>"+tab;
		}
		st += "\t</Site>"+tab;
		st += "\t<Type>" + n.type + "</Type>"+tab;
		
		for(int i=0;i<t;i++){
			st+="\t";
		}
 		st += "\t<Node>"+tab;
		
		st += "\t\t<Start>" + n.start.id + "</Start>"+tab;
		
		st += "\t\t<End>" + n.end.id + "</End>"+tab;
		
		
		st += "\t</Node>"+tab;
		
		
		
		return st;
	}
	
	public static String DTDGraph(){
		String st="";
		st += "<!DOCTYPE Graph[\n";
		st +="<!ELEMENT Graph (id)>\n";
		st +="<!ELEMENT id (#PCDATA)>\n";
		st +="<!ELEMENT Graph (Statistics)>\n";
		st +="\t<!ELEMENT Statistics (Node,Edge)>\n";
		st +="\t\t<!ELEMENT Node (Number)>\n";
		st +="\t\t\t<!ELEMENT Number (Initial,Total,Root,Mutant,Recombinant)>\n";
		st +="\t\t\t\t<!ELEMENT Initial (#PCDATA)>\n";
		st +="\t\t\t\t<!ELEMENT Total (#PCDATA)>\n";
		st +="\t\t\t\t<!ELEMENT Root (#PCDATA)>\n";
		st +="\t\t\t\t<!ELEMENT Mutant (#PCDATA)>\n";
		st +="\t\t\t\t<!ELEMENT Recombinant (#PCDATA)>\n";
		st +="\t\t<!ELEMENT Edge (Number)>\n";
		st +="\t\t\t<!ELEMENT Number (Total)>\n";
		st +="\t\t\t\t<!ELEMENT Total (#PCDATA)>";
		
		st +="<!ELEMENT Log (Conditions, Retrograde_History)>\n";
		st +="<!ELEMENT Conditions (Sequence_Length)>\n";
		st += "<!ELEMENT Sequence_Length (#PCDATA)>\n";
		st +="<!ELEMENT Retrograde_History (Statistics,Events)>\n";
		st +="<!ELEMENT Statistics (Total,Mutation_No_New_Haplotype,Mutation_New_Haplotype,Recombination_New_Haplotype,Recombination_to_Originals)>\n";
		st +="<!ELEMENT Total (#PCDATA)>\n";
		st +="<!ELEMENT Mutation_No_New_Haplotype (#PCDATA)>\n";
		st +="<!ELEMENT Mutation_New_Haplotype (#PCDATA)>\n";
		st +="<!ELEMENT Recombination_New_Haplotype (#PCDATA)>\n";
		st +="<!ELEMENT Recombination_to_Originals (#PCDATA)>\n";
		st +="<!ELEMENT Events (Event)>\n";
		st +="<!ELEMENT Event (ID,Type)>\n";
		st +="<!ELEMENT ID (#PCDATA)>\n";
		st +="<!ELEMENT Type (#PCDATA)>\n";
		st +="<!ELEMENT Nodes (Node)>\n";
		st += DTDElementNode();
		st +="<!ELEMENT Edges (Edge)>\n";
		st += DTDElementEdge();
		st += "]>\n";
		return st;
	}
	
	public static String DTDElementEdge(){
		String st="";
		st +="<!ELEMENT Edge (id,Graph,Site,Type,Node)>\n";
		st +="<!ELEMENT id (#PCDATA)>\n";
		st +="<!ELEMENT Graph (#PCDATA)>\n";
		st +="<!ELEMENT Site (Mutation,Recombination5,Recombination3)>\n";
		st +="<!ELEMENT Mutation (#PCDATA)>\n";
		st +="<!ELEMENT Recombination5 (#PCDATA)>\n";
		st +="<!ELEMENT Recombination3 (#PCDATA)>\n";
		st +="<!ELEMENT Type (#PCDATA)>\n";
		st +="<!ELEMENT Node (Start,End)>\n";
		st +="<!ELEMENT Start (#PCDATA)>\n";
		st +="<!ELEMENT End (#PCDATA)>\n";
		return st;
	}
	
	public static String DTDElementNode(){
		String st="";
		
		st +="<!ELEMENT Node (id,Graph,Label,Type,NodeType,Haplotype,Segments,Edges,Location)>";
		st +="<!ELEMENT id (#PCDATA)>\n";
		st +="<!ELEMENT Graph (#PCDATA)>\n";
		st +="<!ELEMENT Label (#PCDATA)>\n";
		st +="<!ELEMENT Type (#PCDATA)>\n";
		st +="<!ELEMENT NodeType (#PCDATA)>\n";
		st +="<!ELEMENT Haplotype (Segments,Haplotype1,Haplotype2)>\n";
		st +="<!ELEMENT Segments (Segment)>\n";
		st +="<!ELEMENT Segment (ID,Start,End)>\n";
		st +="<!ELEMENT ID (#PCDATA)>\n";
		st +="<!ELEMENT Start (#PCDATA)>\n";
		st +="<!ELEMENT End (#PCDATA)>\n";
		st +="<!ELEMENT Haplotype1 (SNP)>\n";
		st +="<!ELEMENT SNP (Location)>\n";
		st +="<!ELEMENT Location (#PCDATA)>\n";
		st +="<!ELEMENT Haplotype2 (#PCDATA)>\n";
		st +="<!ELEMENT Edges (Number,Edge)>\n";
		st +="<!ELEMENT Number (Total,In,Out)>\n";
		st +="<!ELEMENT Total (#PCDATA)>\n";
		st +="<!ELEMENT In (#PCDATA)>\n";
		st +="<!ELEMENT Out (#PCDATA)>\n";
		st +="<!ELEMENT Edge (id)>\n";
		st +="<!ELEMENT id (#PCDATA)>\n";
		st +="<!ELEMENT Location (x,y,z)>\n";
		st +="<!ELEMENT x (#PCDATA)>\n";
		st +="<!ELEMENT y (#PCDATA)>\n";
		st +="<!ELEMENT z (#PCDATA)>\n";
		
		return st;
	}
	public static String GraphHeaderXML(){
		String st ="<Graph>\n";
		return st;
	}
	
	public static String GraphFooterXML(){
		String st ="</Graph>\n";
		return st;
	}
	
	public static String Graph2XML(treeANDvine.Graph n,int t, int len,Log lg){
		String st ="";
		String tab="\n";
		for(int i=0;i<t;i++){
			tab+="\t";
		}
		st += "\t<id>" + n.id + "</id>"+tab;
		st += "\t<Statistics>"+tab;
		st += "\t\t<Node>"+tab;
		st += "\t\t\t<Number>" +tab;
		st += "\t\t\t\t<Initial>" +tab;
		st += lg.numRetroStartNode;
		st += "\t\t\t\t</Initial>" +tab;
		st += "\t\t\t\t<Total>" +tab;
		st += n.nodes.length + tab;
		st += "\t\t\t\t</Total>" +tab;
		int nodetype[]=GraphStat.NodeType(n);
		st += "\t\t\t\t<Root>" +tab;
		st += nodetype[0] + tab;
		st += "\t\t\t\t</Root>" +tab;
		st += "\t\t\t\t<Mutant>" +tab;
		st += nodetype[1] + tab;
		st += "\t\t\t\t</Mutant>" +tab;
		st += "\t\t\t\t<Recombinant>" +tab;
		st += nodetype[2] + tab;
		st += "\t\t\t\t</Recombinant>" +tab;
		st += "\t\t\t</Number>" +tab;
		st += "\t\t</Node>"+tab;
		
		
		st += "\t\t<Edge>"+tab;
		st += "\t\t\t<Number>" +tab;
		st += "\t\t\t\t<Total>" +tab;
		st += n.edges.length + tab;
		st += "\t\t\t\t</Total>" +tab;
		
		st += "\t\t\t</Number>" +tab;
		st += "\t\t</Edge>"+tab;	
		
		
		st += "\t</Statistics>"+tab;
		
		st += "\t<Log>"+tab;
		st += "\t\t<Conditions>"+tab;
		st += "\t\t\t<Sequence_Length>" + lg.numsnp + "</Sequence_Length>";
		
		
		
		st += "\t\t</Conditions>" + tab;
		st += "\t\t<Retrograde_History>"+tab;
		st += "\t\t\t<Statistics>"+tab;
		st += "\t\t\t\t<Total>" + lg.retroMR.length + "</Total>"+tab;
		
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		st += "\t\t\t\t<Mutation_No_New_Haplotype>" + num0 + "</Mutation_No_New_Haplotype>"+tab;
		st += "\t\t\t\t<Mutation_New_Haplotype>" + num1 + "</Mutation_New_Haplotype>"+tab;
		st += "\t\t\t\t<Recombination_New_Haplotype>" + num3 + "</Recombination_New_Haplotype>"+tab;
		st += "\t\t\t\t<Recombination_to_Originals>" + num4 + "</Recombination_to_Originals>"+tab;
		
		st += "\t\t\t</Statistics>"+tab;
		st += "\t\t\t<Events>"+tab;
		for(int i=0;i<lg.retroMR.length;i++){
			st += "\t\t\t\t<Event>"+tab;
			st += "\t\t\t\t\t<ID>" + i + "</ID>";
			st += "\t\t\t\t\t<Type>" + lg.retroMR[i] + "</Type>";
			st += "\t\t\t\t</Event>"+tab;
		}
		st += "\t\t\t</Events>"+tab;
		st += "\t\t</Retrograde_History>"+tab;
		
		st += "\t</Log>"+tab;
		
		st += "\t<Nodes>"+tab;
		for(int i=0;i<n.nodes.length;i++){
			st += "\t\t<Node>"+tab;
			//st += "\t\t<id>" + n.nodes[i].id + "</id>\n";
			st += Node2XMLTab(n.nodes[i],2,len);
			st += "\t\t</Node>"+tab;
		}
		st += "\t</Nodes>"+tab;
		
		
 		st += "\t<Edges>"+tab;
		for(int i=0;i<n.edges.length;i++){
			st += "\t\t<Edge>"+tab;
			//st += "\t\t<id>" + n.edges[i].id + "</id>\n";
			st += Edge2XMLTab(n.edges[i],2);
			st += "\t\t</Edge>"+tab;
		}
		st += "\t</Edges>"+tab;
		
		
		return st;
	}

	
	public static String Graph2XMLiter(int iter,treeANDvine.Graph n,int t, int len,Log lg){
		String st ="";
		String tab="\n";
		for(int i=0;i<t;i++){
			tab+="\t";
		}
		//st += "\t<id>" + n.id + "</id>"+tab;
		st += "\t<id>" + iter + "</id>"+tab;
		st += "\t<Statistics>"+tab;
		st += "\t\t<Node>"+tab;
		st += "\t\t\t<Number>" +tab;
		st += "\t\t\t\t<Initial>" +tab;
		st += lg.numRetroStartNode;
		st += "\t\t\t\t</Initial>" +tab;
		st += "\t\t\t\t<Total>" +tab;
		st += n.nodes.length + tab;
		st += "\t\t\t\t</Total>" +tab;
		int nodetype[]=GraphStat.NodeType(n);
		st += "\t\t\t\t<Root>" +tab;
		st += nodetype[0] + tab;
		st += "\t\t\t\t</Root>" +tab;
		st += "\t\t\t\t<Mutant>" +tab;
		st += nodetype[1] + tab;
		st += "\t\t\t\t</Mutant>" +tab;
		st += "\t\t\t\t<Recombinant>" +tab;
		st += nodetype[2] + tab;
		st += "\t\t\t\t</Recombinant>" +tab;
		st += "\t\t\t</Number>" +tab;
		st += "\t\t</Node>"+tab;
		
		
		st += "\t\t<Edge>"+tab;
		st += "\t\t\t<Number>" +tab;
		st += "\t\t\t\t<Total>" +tab;
		st += n.edges.length + tab;
		st += "\t\t\t\t</Total>" +tab;
		
		st += "\t\t\t</Number>" +tab;
		st += "\t\t</Edge>"+tab;	
		
		
		st += "\t</Statistics>"+tab;
		
		st += "\t<Log>"+tab;
		st += "\t\t<Conditions>"+tab;
		st += "\t\t\t<Sequence_Length>" + lg.numsnp + "</Sequence_Length>";
		
		
		
		st += "\t\t</Conditions>" + tab;
		st += "\t\t<Retrograde_History>"+tab;
		st += "\t\t\t<Statistics>"+tab;
		st += "\t\t\t\t<Total>" + lg.retroMR.length + "</Total>"+tab;
		
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		st += "\t\t\t\t<Mutation_No_New_Haplotype>" + num0 + "</Mutation_No_New_Haplotype>"+tab;
		st += "\t\t\t\t<Mutation_New_Haplotype>" + num1 + "</Mutation_New_Haplotype>"+tab;
		st += "\t\t\t\t<Recombination_New_Haplotype>" + num3 + "</Recombination_New_Haplotype>"+tab;
		st += "\t\t\t\t<Recombination_to_Originals>" + num4 + "</Recombination_to_Originals>"+tab;
		
		st += "\t\t\t</Statistics>"+tab;
		st += "\t\t\t<Events>"+tab;
		for(int i=0;i<lg.retroMR.length;i++){
			st += "\t\t\t\t<Event>"+tab;
			st += "\t\t\t\t\t<ID>" + i + "</ID>";
			st += "\t\t\t\t\t<Type>" + lg.retroMR[i] + "</Type>";
			st += "\t\t\t\t</Event>"+tab;
		}
		st += "\t\t\t</Events>"+tab;
		st += "\t\t</Retrograde_History>"+tab;
		
		st += "\t</Log>"+tab;
		
		st += "\t<Nodes>"+tab;
		for(int i=0;i<n.nodes.length;i++){
			st += "\t\t<Node>"+tab;
			//st += "\t\t<id>" + n.nodes[i].id + "</id>\n";
			st += Node2XMLTab(n.nodes[i],2,len);
			st += "\t\t</Node>"+tab;
		}
		st += "\t</Nodes>"+tab;
		
		
 		st += "\t<Edges>"+tab;
		for(int i=0;i<n.edges.length;i++){
			st += "\t\t<Edge>"+tab;
			//st += "\t\t<id>" + n.edges[i].id + "</id>\n";
			st += Edge2XMLTab(n.edges[i],2);
			st += "\t\t</Edge>"+tab;
		}
		st += "\t</Edges>"+tab;
		
		
		return st;
	}

	public static String Graph2XMLiter2(int iter,treeANDvine.Graph n,int t, int len,Log lg){
		String st ="";
		String tab="\n";
		for(int i=0;i<t;i++){
			tab+="\t";
		}
		//st += "\t<id>" + n.id + "</id>"+tab;
		st += "\t<id>" + iter + "</id>"+tab;
		
		st += "\t<TotalNode>"+n.nodes.length + "</TotalNode>" +tab;
		st += "\t<InitialNode>"+lg.numRetroStartNode + "</InitialNode>" +tab;
		int nodetype[]=GraphStat.NodeType(n);
		st += "\t<RootNode>"+nodetype[0] + "</RootNode>" +tab;
		st += "\t<MutNode>"+nodetype[1] + "</MutNode>" +tab;
		st += "\t<RecNode>"+nodetype[2] + "</RecNode>" +tab;
		st += "\t<Edge>"+n.edges.length + "</Edge>"+tab;

		st += "\t<RetroEvent>" + lg.retroMR.length + "</RetroEvent>"+tab;
		
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num1++;
			else if(lg.retroMR[i]==2)num2++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		st += "\t<Mutation_No_New_Haplotype>" + num0 + "</Mutation_No_New_Haplotype>"+tab;
		st += "\t<Mutation_New_Haplotype>" + num1 + "</Mutation_New_Haplotype>"+tab;
		st += "\t<Recombination_New_Haplotype>" + num3 + "</Recombination_New_Haplotype>"+tab;
		st += "\t<Recombination_to_Originals>" + num4 + "</Recombination_to_Originals>"+tab;
		
		st += "\t<Events>";
		for(int i=0;i<lg.retroMR.length;i++){
			st += " " + lg.retroMR[i];
		}
		st += "\t</Events>"+tab;

		/*
		st += "\t<Nodes>"+tab;
		for(int i=0;i<n.nodes.length;i++){
			st += "\t\t<Node>"+tab;
			//st += "\t\t<id>" + n.nodes[i].id + "</id>\n";
			st += Node2XMLTab(n.nodes[i],2,len);
			st += "\t\t</Node>"+tab;
		}
		st += "\t</Nodes>"+tab;
		
		
 		st += "\t<Edges>"+tab;
		for(int i=0;i<n.edges.length;i++){
			st += "\t\t<Edge>"+tab;
			//st += "\t\t<id>" + n.edges[i].id + "</id>\n";
			st += Edge2XMLTab(n.edges[i],2);
			st += "\t\t</Edge>"+tab;
		}
		st += "\t</Edges>"+tab;
		*/
		
		return st;
	}

		
	public static String Graph2XMLnoID(treeANDvine.Graph n,int t, int len,Log lg){
		String st ="";
		String tab="\n";
		for(int i=0;i<t;i++){
			tab+="\t";
		}
		//st += "\t<id>" + n.id + "</id>"+tab;
		st += "\t<Statistics>"+tab;
		st += "\t\t<Node>"+tab;
		st += "\t\t\t<Number>" +tab;
		st += "\t\t\t\t<Initial>" +tab;
		st += lg.numRetroStartNode;
		st += "\t\t\t\t</Initial>" +tab;
		st += "\t\t\t\t<Total>" +tab;
		st += n.nodes.length + tab;
		st += "\t\t\t\t</Total>" +tab;
		int nodetype[]=GraphStat.NodeType(n);
		st += "\t\t\t\t<Root>" +tab;
		st += nodetype[0] + tab;
		st += "\t\t\t\t</Root>" +tab;
		st += "\t\t\t\t<Mutant>" +tab;
		st += nodetype[1] + tab;
		st += "\t\t\t\t</Mutant>" +tab;
		st += "\t\t\t\t<Recombinant>" +tab;
		st += nodetype[2] + tab;
		st += "\t\t\t\t</Recombinant>" +tab;
		st += "\t\t\t</Number>" +tab;
		st += "\t\t</Node>"+tab;
		
		
		st += "\t\t<Edge>"+tab;
		st += "\t\t\t<Number>" +tab;
		st += "\t\t\t\t<Total>" +tab;
		st += n.edges.length + tab;
		st += "\t\t\t\t</Total>" +tab;
		
		st += "\t\t\t</Number>" +tab;
		st += "\t\t</Edge>"+tab;	
		
		
		st += "\t</Statistics>"+tab;
		
		st += "\t<Log>"+tab;
		st += "\t\t<Conditions>"+tab;
		st += "\t\t\t<Sequence_Length>" + lg.numsnp + "</Sequence_Length>";
		
		
		
		st += "\t\t</Conditions>" + tab;
		st += "\t\t<Retrograde_History>"+tab;
		st += "\t\t\t<Statistics>"+tab;
		st += "\t\t\t\t<Total>" + lg.retroMR.length + "</Total>"+tab;
		
		int num0=0;
		int num1=0;
		int num2=0;
		int num3=0;
		int num4=0;
		for(int i=0;i<lg.retroMR.length;i++){
			if(lg.retroMR[i]==0)num0++;
			else if(lg.retroMR[i]==1)num0++;
			else if(lg.retroMR[i]==2)num0++;
			else if(lg.retroMR[i]==3)num3++;
			else if(lg.retroMR[i]==4)num4++;
		}
		st += "\t\t\t\t<Mutation_No_New_Haplotype>" + num0 + "</Mutation_No_New_Haplotype>"+tab;
		st += "\t\t\t\t<Mutation_New_Haplotype>" + num1 + "</Mutation_New_Haplotype>"+tab;
		st += "\t\t\t\t<Recombination_New_Haplotype>" + num3 + "</Recombination_New_Haplotype>"+tab;
		st += "\t\t\t\t<Recombination_to_Originals>" + num4 + "</Recombination_to_Originals>"+tab;
		
		st += "\t\t\t</Statistics>"+tab;
		st += "\t\t\t<Events>"+tab;
		for(int i=0;i<lg.retroMR.length;i++){
			st += "\t\t\t\t<Event>"+tab;
			st += "\t\t\t\t\t<ID>" + i + "</ID>";
			st += "\t\t\t\t\t<Type>" + lg.retroMR[i] + "</Type>";
			st += "\t\t\t\t</Event>"+tab;
		}
		st += "\t\t\t</Events>"+tab;
		st += "\t\t</Retrograde_History>"+tab;
		
		st += "\t</Log>"+tab;
		
		st += "\t<Nodes>"+tab;
		for(int i=0;i<n.nodes.length;i++){
			st += "\t\t<Node>"+tab;
			//st += "\t\t<id>" + n.nodes[i].id + "</id>\n";
			st += Node2XMLTab(n.nodes[i],2,len);
			st += "\t\t</Node>"+tab;
		}
		st += "\t</Nodes>"+tab;
		
		
 		st += "\t<Edges>"+tab;
		for(int i=0;i<n.edges.length;i++){
			st += "\t\t<Edge>"+tab;
			//st += "\t\t<id>" + n.edges[i].id + "</id>\n";
			st += Edge2XMLTab(n.edges[i],2);
			st += "\t\t</Edge>"+tab;
		}
		st += "\t</Edges>"+tab;
		
		
		return st;
	}
	

	public static void out2File(String file, String st){
		
		BufferedWriter bw1 = null;
		try{
			bw1 = new BufferedWriter(new FileWriter(file));
			
			
			bw1.write(st);
			bw1.close();

		}catch(Exception e){
			
			System.out.println(e);
			System.out.println("koko");
		}
		
		
	}
	public static void out3File(BufferedWriter bw1,String st){
		
		//BufferedWriter bw1 = null;
		try{
			//bw1 = new BufferedWriter(new FileWriter(file));
			
			
			bw1.write(st);
			//bw1.close();

		}catch(Exception e){
			
			System.out.println(e);
			System.out.println("koko");
		}
		
		
	}
}
