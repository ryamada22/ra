/*
 * �쐬��: 2005/07/15
 *
 * TODO ���̐������ꂽ�t�@�C���̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
package treeANDvine;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringBufferInputStream;

import auburn.VGJ.*;
import auburn.VGJ.algorithm.GraphUpdate;
import auburn.VGJ.algorithm.cartegw.BiconnectGraph;
import auburn.VGJ.algorithm.cgd.CGDAlgorithm;
import auburn.VGJ.algorithm.shawn.Spring;
import auburn.VGJ.algorithm.tree.TreeAlgorithm;
import auburn.VGJ.examplealg.ExampleAlg2;
import auburn.VGJ.graph.GMLobject;
import auburn.VGJ.graph.Graph;
import auburn.VGJ.graph.ParseError;
import auburn.VGJ.gui.MessageDialog;
import auburn.VGJ.gui.GraphWindow;
import auburn.VGJ.graph.*;

/**
 * @author yamada
 *
 * TODO ���̐������ꂽ�^�R�����g�̃e���v���[�g��ύX����ɂ͎��փW�����v:
 * �E�B���h�E - �ݒ� - Java - �R�[�h�E�X�^�C�� - �R�[�h�E�e���v���[�g
 */
public class WF_VGJ {
	/*
	 * WFSim�́ATreeAndVine�̂����A���F�̂�����A���̐e�q�֌W�����߂�_�ɓ�������
	 * �L�^�͐��ゲ�ƂƂ��A���ゲ�ƂɃI�u�W�F�N�g���폜���邱�Ƃŉ\�ɂ���
	 */	
		
	
	
	
	public static void main(String[] args) {
		try{
//			WrightFisherParameters�ǂݍ���
			WrightFisherParameterDemo wfp;
			wfp = new WrightFisherParameterDemo();
			int region = wfp.region_length;
			int pop = wfp.population_size;//1���l�A���F�̂�2���{
			double nt_morgan_ratio = wfp.nt_morgan_ratio;//1cM=1Mb,0.00000000,1cM=2Mb�̂Ƃ��́A0.000000002
			int num_gen = wfp.num_generation;
			double mut_rate = wfp.mutation_rate;
			double rec_rate = wfp.recombination_rate;
			double hapfreq4disp = wfp.hapfreq4disp;
			
			//���s���O
			//�����ʂ��ăJ�E���g
			int gen=0;//����
			int nd_tot=0;//�S���F��(node)
			int ed_tot=0;//�S�G�b�W
			int hp_nd_tot=0;
			
			
			//������ŃJ�E���g
			int num_ch=0;
			//int[][] haptype;//�n�v���^�C�v�^
			IntArray4Hp[] haptype;
			int[] num_hp;//�n�v���^�C�v���Ƃ̐l��
			int[] nd_hp;//���F�̂̃n�v���^�C�v�^
			
			//graph
			int[][] child;//oyaid���1�A�q�������2�A�l��koid
			child = null;
			int event[][];//oyaid���1�A�q�������2�A�l�̓C�x���gID
			event = null;
			int[] parent0;//koid���1�A�l��oyaid
			int[] parent1;//koid���2�A�l��oyaid2(���Ȃ����null)
			parent0=new int[pop*num_gen];
			parent1=new int[pop*num_gen];
			int[] eventtype;//eventid���1�A�^�C�v(coalescent(0),recombination(1))
			int[][] recsite;//eventid���1�A��������2�Arecombination�ʒu�̍�����ԍ����l
			int[][] mutsite;//eventid���1�A��������2�Amutation�ʒu���l
			eventtype=null;
			//recsite=null;
			mutsite=new int[pop][2];
			recsite=new int[pop][1];
			

			
			int pop_before;
			int[] freqhp_before;
			
			//�o�̓p�����^
			GMLoutParameters gmloutp;
			gmloutp = new GMLoutParameters();
			
			int NdLb=gmloutp.NdLb;
			int EdLb=gmloutp.EdLb;
			int rootCol=gmloutp.rootCol;
			int mutCol=gmloutp.mutCol;
			int recCol=gmloutp.recCol;
			int mutEdcol=gmloutp.mutEdcol;
			int recEdcol=gmloutp.recEdcol;
			int origin=gmloutp.origin;
			
			
			
			//output setting 
			
			String textlog="";
			String textvgj="";
			String textgen="";
			String textgenhp="";
			String textsvg="";
			
			String gml1="";
			String gml2="";
			
			String rootdir = "C:\\Java\\WrightFisher\\WFSimOut";
			//3 types(�S�́A�؂̏W�܂�A�X�̖�)�̃O���t�����t�@�C��
			//�S��
			/*
			String logfile=rootdir+"\\log.txt";
			String vgjfile=rootdir+"\\individual.gml";
			String svgfile=rootdir+"\\individual.svg";
			String freqsvgfile=rootdir+"\\hapfreq.svg";
			String genotypefile=rootdir+"\\hapallele_all_gen.txt";
			String freqdatafile=rootdir+"\\hapfreqdata_all_gen.txt";
			String genotypefile_last=rootdir+"\\hapallele_last_gen.txt";
			String freqdatafile_last=rootdir+"\\hapfreqdata_last_gen.txt";
			String freqvgjfile=rootdir+"\\hapfreq.gml";
			String parentchildfile =rootdir + "\\chparentchild.txt";
			String parentfile =rootdir + "\\chparent.txt";
			String childfile =rootdir + "\\chchild.txt";
			String parentchildfile2 =rootdir + "\\chparentchild2.txt";
			String parentfile2 =rootdir + "\\chparent2.txt";
			String childfile2 =rootdir + "\\chchild2.txt";
			String hpparentchildfile =rootdir + "\\hpparentchild.txt";
			String hpparentfile =rootdir + "\\hpparent.txt";
			String hpchildfile =rootdir + "\\hpchild.txt";
			String hpparentchildfile2 =rootdir + "\\hpparentchild2.txt";
			String hpparentfile2 =rootdir + "\\hpparent2.txt";
			String hpchildfile2 =rootdir + "\\hpchild2.txt";
			String hpidfile = rootdir + "\\hpid.txt";
			BufferedWriter bw1;
			BufferedWriter bw2;
			BufferedWriter bw3;
			BufferedWriter bw4;
			BufferedWriter bw5;
			BufferedWriter bw6;
			BufferedWriter bw7;
			BufferedWriter bw8;
			BufferedWriter bw9;
			BufferedWriter bw10;
			BufferedWriter bw11;
			BufferedWriter bw12;
			BufferedWriter bw13;
			BufferedWriter bw14;
			BufferedWriter bw15;
			BufferedWriter bw16;
			BufferedWriter bw17;
			BufferedWriter bw18;
			BufferedWriter bw19;
			BufferedWriter bw20;
			BufferedWriter bw21;
			
			bw1=null;
			bw2=null;
			bw3=null;
			bw4=null;
			bw5=null;
			bw6=null;
			bw7=null;
			bw8=null;
			bw9=null;
			bw10=null;
			bw11=null;
			bw12=null;
			bw13=null;
			bw14=null;
			bw15=null;
			bw16=null;
			bw17=null;
			bw18=null;
			bw19=null;
			bw20=null;
			bw21=null;
			
			try{
				bw1 = new BufferedWriter(new FileWriter(vgjfile));
				bw2 = new BufferedWriter(new FileWriter(svgfile));
				bw3 = new BufferedWriter(new FileWriter(genotypefile));
				bw4 = new BufferedWriter(new FileWriter(freqsvgfile));
				bw5 = new BufferedWriter(new FileWriter(freqdatafile));
				bw6 = new BufferedWriter(new FileWriter(freqvgjfile));
				bw7 = new BufferedWriter(new FileWriter(genotypefile_last));
				bw8 = new BufferedWriter(new FileWriter(freqdatafile_last));
				bw9 = new BufferedWriter(new FileWriter(parentchildfile));
				bw10 = new BufferedWriter(new FileWriter(parentfile));
				bw11 = new BufferedWriter(new FileWriter(childfile));
				bw12 = new BufferedWriter(new FileWriter(parentchildfile2));
				bw13 = new BufferedWriter(new FileWriter(parentfile2));
				bw14 = new BufferedWriter(new FileWriter(childfile2));
				bw15 = new BufferedWriter(new FileWriter(hpparentchildfile));
				bw16 = new BufferedWriter(new FileWriter(hpparentfile));
				bw17 = new BufferedWriter(new FileWriter(hpchildfile));
				bw18 = new BufferedWriter(new FileWriter(hpparentchildfile2));
				bw19 = new BufferedWriter(new FileWriter(hpparentfile2));
				bw20 = new BufferedWriter(new FileWriter(hpchildfile2));
				bw21 = new BufferedWriter(new FileWriter(hpidfile));
			}catch(Exception e){
				
				System.out.println(e);

			}
			*/
			/*
			String genoutroot=rootdir+"\\gen";
			
			
			String outarg = rootdir + "\\out_arg.txt";
			//�g�����ɂ�蕪�������u�؁v�̏W�܂�(�u�сv)
			String outforest = rootdir + "\\out_forest.txt";
			String outforestTr = rootdir + "\\out_forestTr.txt";
			String outfr_vine = rootdir + "\\out_fr_vine.txt";
			//�X�́u�؁v
			String outtrees = rootdir + "\\out_trees_";
			String outtrees_sf ="";
			String outpajek2 = rootdir + "\\out2.txt";
			String outevent = rootdir + "\\event.txt";
			*/
			
			//simulation settings
			//int numsnp = 200;//SNP�̐��A�z�񒷂ɂ�����
			int numsnp = wfp.region_length;//SNP�̐��A�z�񒷂ɂ�����
			//int iteration =100;//mutation + recombination�̉�
			int iteration = wfp.num_generation;//���㐔
			

			
			textvgj=TaVtoGML.outVGJtoSt5header(textvgj);
			int svgsize;
			svgsize = Math.max(pop,num_gen);
			textsvg=TaVtoGML.outSVGtoSt5header(textsvg,svgsize);
			//OutXML.out3File(bw1,textvgj);
			//OutXML.out3File(bw2,textsvg);
			//OutXML.out3File(bw4,textsvg);
			//OutXML.out3File(bw6,textvgj);
			gml1+=textvgj;
			gml2+=textvgj;
			String headerhapfreq = ">Length of region(nt)\t"+ region+"\n"
			+">No.total chromosomes\t" + pop +"\n" +
					">nt/1cM\t"+ nt_morgan_ratio +"\n"+
					">No.generation\t" + num_gen + "\n"+
					">Mutation rate\t" + mut_rate + "\n"+ 
					">Recombination rate/1cM\t"+rec_rate +"\n" +
					">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n"+
					"\n>Haplotype id\tNo.chromosomes\tMutation sites\n";
			//OutXML.out3File(bw8,headerhapfreq);
			
			//Root
			//simulation�J�n�̃n�v���^�C�v����
//			�S���F�͕̂ψقȂ��A����n�v���^�C�v
			System.out.println("Root Generation is in progress");
			IntArray4Hp tmpintarray4hp;
			tmpintarray4hp=new IntArray4Hp();
			haptype = new IntArray4Hp[1];
			haptype[0]=tmpintarray4hp;
			//haptype[0].arr=null;
			//haptype[0][0]=-9;
			String[] genotype;
			genotype = new String[1];
			//genotype[0] = "\n";
			genotype[0] = "";
			
			nd_hp = new int[pop];
			int[] gen_tot_id;
			gen_tot_id = new int[pop];
			
			int[] nd_loc_x;
			nd_loc_x = new int[pop];
			int[] nd_loc_y;
			nd_loc_y = new int[pop];
			
			int[] hp_loc_x;
			int[] hp_loc_y;
			hp_loc_x=new int[1];
			hp_loc_y=new int[1];
			
			int[] hp_nd;
			hp_nd = new int[pop];
			//String freqdataout="generation\t" + gen + "\n";
			String freqdataout="generation\t" + gen + "\n";
			//OutXML.out3File(bw5,freqdataout);
			//OutXML.out3File(bw3,freqdataout);
			
			for(int i=0;i<pop;i++){
				
				nd_hp[i]=0;
				gen_tot_id[i]=nd_tot;
				//String vgj=TaVtoGML.outVGJtoSt5Node(nd_tot,0,gen,i
				String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,0,gen,i
						,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				//textvgj+=vgj;
				nd_loc_x[i]=gen;
				nd_loc_y[i]=i;
				//OutXML.out3File(bw1,vgj);

				gml1+=vgj;
				String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,gen,i,0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
				//OutXML.out3File(bw2,svg);

				String hpkata = genotype[nd_hp[i]];
				//System.out.println("hpkata " + hpkata);
				hpkata +=i + "\t" + hpkata + "\n";
				//OutXML.out3File(bw3,hpkata);
			
						
				nd_tot++;

			}
			pop_before = pop;
			//root generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
			
			int[] freqhp;
			freqhp = new int[haptype.length];
			for(int i=0;i<haptype.length;i++){
				freqhp[i]=0;
			}
			for(int i=0;i<nd_hp.length;i++){
				freqhp[nd_hp[i]]++;
			}
			int roothpcnt=0;
			
			for(int i=0;i<haptype.length;i++){
				if(freqhp[i]>0){
					String hpid="0\t" + roothpcnt + "\t" + i+"\n";
					//OutXML.out3File(bw21,hpid);
					
					String hpkata = "";
					
					for(int k=0;k<haptype[i].arr.length;k++){
						
						hpkata += haptype[i].arr[k] + "\t";
					}
					freqdataout=roothpcnt + "\t" + i +"\t" + freqhp[i] + "\t" + hpkata + "\n";
					//OutXML.out3File(bw5,freqdataout);
					hp_loc_x[i]=gen*pop;
					hp_loc_y[i]=roothpcnt*pop;
					double freqdb=(double)(freqhp[i])/(double)(pop);
					String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqdb,
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					//OutXML.out3File(bw4,freqsvg);
					//String freqvgj=TaVtoGML.outVGJtoSt5Node(hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
							//NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					//String freqvgj=TaVtoGML.outVGJtoSt6Node(hpkata,hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
					String freqvgj=TaVtoGML.outVGJtoSt6Node_URL(hpkata,hp_nd_tot,0,hp_loc_x[i],hp_loc_y[i],0,freqhp[i],
							NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
					hp_nd[i]=hp_nd_tot;
					hp_nd_tot++;
					//OutXML.out3File(bw6,freqvgj);
					gml2+=freqvgj;
					roothpcnt++;
				}
				
			}
			freqhp_before = freqhp;
			gen++;
			
			for(int i=gen;i<num_gen;i++){
				System.out.println("Generation " + i + "/" + num_gen + " is in progress.");
				//freqdataout="generation\t" + gen + "\n";
				freqdataout="generation\t" + gen + "\n";
				//OutXML.out3File(bw5,freqdataout);
				//OutXML.out3File(bw3,freqdataout);
				
				int pop_now=pop;
				int[] nd_hp_tmp;
				nd_hp_tmp = new int[pop_now];
				int[] gen_tot_id_tmp;
				gen_tot_id_tmp = new int[pop_now];
				int[] nd_loc_x_tmp;
				nd_loc_x_tmp = new int[pop_now];
				int[] nd_loc_y_tmp;
				nd_loc_y_tmp = new int[pop_now];
				int[] hp_nd_tmp;
				hp_nd_tmp = new int[hp_nd.length+pop_now];
				//ch�e�q�y�A�L�^�p�A���C
				IntArray4Hp choya;
				IntArray4Hp chko;
				//hp�e�q�y�A�L�^�p�A���C
				IntArray4Hp hpoya;
				IntArray4Hp hpko;
				//haptype�u��
				IntArray4Hp[] haptype_before;
				haptype_before = haptype;
				
				choya = new IntArray4Hp();
				chko = new IntArray4Hp();
				hpoya = new IntArray4Hp();
				hpko = new IntArray4Hp();
				
				for(int j=0;j<pop;j++){
					double rand0 = Math.random();
					double rec_freq = rec_rate*region/nt_morgan_ratio;
					
					if(rand0>rec_freq){//No recombination
						double rand1 = Math.random();
						int tmpoya = (int)(rand1*nd_hp.length);
						choya.addelem(tmpoya);
						chko.addelem(j);
						
						IntArray4Hp tmp_hpkata;
						tmp_hpkata=new IntArray4Hp();
						double rand_mut = Math.random();
						if(rand_mut<=mut_rate){
							//System.out.println("mutation!!");
							double rand_mut_site = Math.random();
							int mut_site_tmp =(int)(rand_mut_site*region);
							mutsite[j][0]=mut_site_tmp;
							IntArray4Hp tmp_tmp_hpkata;
							tmp_tmp_hpkata = new IntArray4Hp();
							boolean judge=true;
							boolean judgeyet=true;
							if(haptype[nd_hp[tmpoya]].arr.length==0){
								
								tmp_tmp_hpkata.addelem(mutsite[j][0]);
								
								nd_hp_tmp[j]=haptype.length;
								IntArray4Hp[] tmp_haptype;
								tmp_haptype = new IntArray4Hp[haptype.length+1];
								for(int x=0;x<haptype.length;x++){
									tmp_haptype[x]=haptype[x];
									
								}
								tmp_haptype[haptype.length]=tmp_tmp_hpkata;
								
								haptype = null;
								haptype=tmp_haptype;
								
							}else{
								int counter=0;
								for(int k=0;k<haptype[nd_hp[tmpoya]].arr.length;k++){
									
									if(haptype[nd_hp[tmpoya]].arr[k]==mutsite[j][0]){
										
										tmp_tmp_hpkata.addelem(mutsite[j][0]);
										
										judge=false;
										judgeyet=false;
										//System.out.println("eaqual");
									}else if(haptype[nd_hp[tmpoya]].arr[k]<mutsite[j][0]){
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										//System.out.println("more than");
									}else if(haptype[nd_hp[tmpoya]].arr[k]>mutsite[j][0]){
										//System.out.println("less than");
										if(judgeyet){
											tmp_tmp_hpkata.addelem(mutsite[j][0]);
											counter++;
											judgeyet=false;
										}
										tmp_tmp_hpkata.addelem(haptype[nd_hp[tmpoya]].arr[k]);
										counter++;
										
									
									}
									
								}
								if(judgeyet){
									//System.out.println("add");
									tmp_tmp_hpkata.addelem(mutsite[j][0]);
									counter++;
								}
								boolean noidhp=true;
								for(int x=0;x<haptype.length;x++){
									boolean identicalhp = true;
									if(haptype[x].arr.length==tmp_tmp_hpkata.arr.length){
										for(int y=0;y<tmp_tmp_hpkata.arr.length;y++){
											if(haptype[x].arr[y]!=tmp_tmp_hpkata.arr[y]){
												identicalhp=false;
												break;
											}
										}
										if(identicalhp){//�Vhptype�ł͂Ȃ�
											//nd_hp_tmp[j]=nd_hp[x];
											nd_hp_tmp[j]=x;
											noidhp=false;
											
											break;
										}
									}
								}
								if(noidhp){
									nd_hp_tmp[j]=haptype.length;
									IntArray4Hp[] tmp_haptype;
									tmp_haptype = new IntArray4Hp[haptype.length+1];
									for(int x=0;x<haptype.length;x++){
										tmp_haptype[x]=haptype[x];
										
									}
									
									tmp_haptype[haptype.length]=tmp_tmp_hpkata;
									
									haptype = null;
									haptype=tmp_haptype;
								}
							}
							if(judge){
								tmp_hpkata=tmp_tmp_hpkata;
								}
							
						}else{
							tmp_hpkata=haptype[nd_hp[tmpoya]];
							nd_hp_tmp[j]=nd_hp[tmpoya];
							
						}
						//hppair�o�^
						boolean newpair=true;
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
									//System.out.println("##�o�^���Ȃ� " + j);
									newpair=false;
								}
								
							}
						}
						if(newpair){
							hpoya.addelem(nd_hp[tmpoya]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						gen_tot_id_tmp[j]=nd_tot;
						//String vgj=TaVtoGML.outVGJtoSt5Node(nd_tot,1,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,1,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i;
						nd_loc_y_tmp[j]=j;
						//textvgj+=vgj;
						//OutXML.out3File(bw1,vgj);
						gml1+=vgj;
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,1,i,j,0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//OutXML.out3File(bw2,svg);

						String hpkata = j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + " ";
						}
						hpkata += "\n";
						//OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							//OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,0,gen_tot_id[tmpoya],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(0, nd_loc_x[tmpoya],nd_loc_y[tmpoya],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//textvgj+=vgj_ed;
						//OutXML.out3File(bw1,vgj_ed);
						gml1+=vgj_ed;
						//OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya];
						
						nd_tot++;
						ed_tot++;
					}else{
						//�g��������
						//System.out.println("recombination");
						double rand1 = Math.random();
						double rand2 = Math.random();
						int tmpoya1 = (int)(rand1*nd_hp.length);
						int tmpoya2 = (int)(rand2*(nd_hp.length-1));
						if(tmpoya2<=tmpoya1){
							tmpoya2++;
						}
						choya.addelem(tmpoya1);
						chko.addelem(j);
						choya.addelem(tmpoya2);
						chko.addelem(j);
						//�g�����ʒu
						double rand3 = Math.random();
						int rec = (int)(rand3*region);
						
						recsite[j][0]=rec;
						
						//�Q��oyahap�ɏ�L�Ɠ���������mutation���N�����A���̏�ŁA�V�n�v���^�C�v�����
						IntArray4Hp hptmpoya1 = haptype[nd_hp[tmpoya1]];
						IntArray4Hp hptmpoya2 = haptype[nd_hp[tmpoya2]];
						IntArray4Hp tmphap;
						tmphap = new IntArray4Hp();
						
						double rand_event1 = Math.random();
						double rand_event2 = Math.random();
						if(rand_event1<=mut_rate){
							double rand_mut_site1 = Math.random();
							int mut_site_tmp1 =(int)(rand_mut_site1*region);
							mutsite[j][0]=mut_site_tmp1;
							boolean judge1=true;
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									if(mutsite[j][0]>hptmpoya1.arr[k]){
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}else if(mutsite[j][0]==hptmpoya1.arr[k]){
										tmphap.addelem(mutsite[j][0]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
										judge1=false;
									}else if(mutsite[j][0]<hptmpoya1.arr[k]){
										if(judge1){
											tmphap.addelem(mutsite[j][0]);
											//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
											judge1=false;
										}
										tmphap.addelem(hptmpoya1.arr[k]);
										//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
									}
								}
							}
							if(judge1){
								if(mutsite[j][0]<=recsite[j][0]){
									tmphap.addelem(mutsite[j][0]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}else{
							for(int k=0;k<hptmpoya1.arr.length;k++){
								if(hptmpoya1.arr[k]<=recsite[j][0]){
									tmphap.addelem(hptmpoya1.arr[k]);
									//System.out.println("tmphap.arr.length "+ tmphap.arr.length);
								}
							}
						}
						if(rand_event2<=mut_rate){
							double rand_mut_site2 = Math.random();
							int mut_site_tmp2 =(int)(rand_mut_site2*region);
							mutsite[j][1]=mut_site_tmp2;
							boolean judge2=true;
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									if(mutsite[j][1]>hptmpoya2.arr[k]){
										tmphap.addelem(hptmpoya2.arr[k]);
									}else if(mutsite[j][1]==hptmpoya2.arr[k]){
										tmphap.addelem(mutsite[j][1]);
										judge2=false;
									}else if(mutsite[j][1]<hptmpoya2.arr[k]){
										if(judge2){
											tmphap.addelem(mutsite[j][1]);
											judge2=false;
										}
										tmphap.addelem(hptmpoya2.arr[k]);
									}
								}
							}
							if(judge2){
								if(mutsite[j][1]>recsite[j][0]){
									tmphap.addelem(mutsite[j][1]);
								}
							}
						}else{
							for(int k=0;k<hptmpoya2.arr.length;k++){
								if(hptmpoya2.arr[k]>recsite[j][0]){
									tmphap.addelem(hptmpoya2.arr[k]);
								}
							}
						}
						
						//����haplotype�ɂ��łɑ��݂��邩
						
						boolean noidhp=true;
						//int max_mutsite=0;
						
						for(int x=0;x<haptype.length;x++){
							boolean identicalhp = true;
							if(haptype[x].arr.length==tmphap.arr.length){
								//if(haptype[x].arr.length>max_mutsite){
									//max_mutsite=haptype[x].arr.length;
								//}
								for(int y=0;y<tmphap.arr.length;y++){
									if(haptype[x].arr[y]!=tmphap.arr[y]){
										identicalhp=false;
										break;
									}
								}
								if(identicalhp){//�Vhptype�ł͂Ȃ�
									
									//nd_hp_tmp[j]=nd_hp[x];
									nd_hp_tmp[j]=x;
									
									noidhp=false;
									
									break;
								}
							}
						}
						//if(tmp_tmp_hpkata.arr.length>max_mutsite){
							//max_mutsite = tmp_tmp_hpkata.arr.length;
						//}
						if(noidhp){
							
							nd_hp_tmp[j]=haptype.length;
							IntArray4Hp[] tmp_haptype;
							tmp_haptype = new IntArray4Hp[haptype.length+1];
							for(int x=0;x<haptype.length;x++){
								tmp_haptype[x]=haptype[x];
								
							}
							
							tmp_haptype[haptype.length]=tmphap;
							
							haptype = null;
							haptype = new IntArray4Hp[tmp_haptype.length];
							haptype=tmp_haptype;
						}
//						hppair�o�^
						boolean newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya1]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya1]);
							hpko.addelem(nd_hp_tmp[j]);
						}
//						hppair�o�^
						newpair=true;
						//System.out.println("hpoya.arr.length " + hpoya.arr.length);
						for(int x=0;x<hpoya.arr.length;x++){
							if(nd_hp[tmpoya2]==hpoya.arr[x]){
								if(nd_hp_tmp[j]==hpko.arr[x]){
//									�o�^���Ȃ�
									newpair=false;
								}
								
							}
						}
						if(newpair){
							//System.out.println("hpoya�o�^");
							hpoya.addelem(nd_hp[tmpoya2]);
							hpko.addelem(nd_hp_tmp[j]);
						}
						//nd_hp_tmp[j]=nd_hp[tmpoya1];//�����̓n�v���^�C�v��{�C�œo�^����Ƃ��ɂ́A�ς���
//						
						gen_tot_id_tmp[j]=nd_tot;
						//String vgj=TaVtoGML.outVGJtoSt5Node(nd_tot,2,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String vgj=TaVtoGML.outVGJtoSt5Node_URL(nd_tot,2,i,j,0,1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						nd_loc_x_tmp[j]=i;
						nd_loc_y_tmp[j]=j;
						//textvgj+=vgj;
						//OutXML.out3File(bw1,vgj);
						gml1+=vgj;
						String svg=TaVtoGML.outSVGtoSt5Node(nd_tot,2,i,j,0,0.1,NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//OutXML.out3File(bw2,svg);
						
						
						String hpkata = "";
						hpkata +=j + "\t";
						for(int k=0;k<haptype[nd_hp_tmp[j]].arr.length;k++){
							
							hpkata += haptype[nd_hp_tmp[j]].arr[k] + " ";
						}
						hpkata += "\n";
						//OutXML.out3File(bw3,hpkata);
						if(i==num_gen-1){
							//OutXML.out3File(bw7,hpkata);
						}
						
						String vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya1],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						String svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya1],nd_loc_y[tmpoya1],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//OutXML.out3File(bw1,vgj_ed);
						gml1+=vgj_ed;
						//OutXML.out3File(bw2,svg_ed);
						ed_tot++;
						//textvgj+=vgj_ed;
						vgj_ed=TaVtoGML.outVGJtoSt5Edge(nd_tot,1,gen_tot_id[tmpoya2],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						svg_ed=TaVtoGML.outSVGtoSt5Edge(1, nd_loc_x[tmpoya2],nd_loc_y[tmpoya2],nd_loc_x_tmp[j],nd_loc_y_tmp[j],NdLb,EdLb,
								rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//OutXML.out3File(bw1,vgj_ed);
						//OutXML.out3File(bw2,svg_ed);
						parent0[nd_tot]=gen_tot_id[tmpoya1];
						parent1[nd_tot]=gen_tot_id[tmpoya2];
						
						ed_tot++;
						nd_tot++;
					}
					
				}

				
//				���� generation��haptype�ʐl���W�v�Ƃ���freqsvgfile�ւ̏o��
				//freqdataout="generation\t" + gen + "\n";
				//OutXML.out3File(bw5,freqdataout);
				freqhp = new int[haptype.length];
				for(int j=0;j<haptype.length;j++){
					freqhp[j]=0;
				}
				for(int j=0;j<nd_hp_tmp.length;j++){
					//System.out.println("j,nd_hp_tmp[j] "+j + " " + nd_hp_tmp[j]);
					freqhp[nd_hp_tmp[j]]++;
				}
				int hptypecnt=0;
				int[] hp_loc_x_tmp;
				int[] hp_loc_y_tmp;
				hp_loc_x_tmp = new int[haptype.length];
				hp_loc_y_tmp = new int[haptype.length];
				//System.out.println("haptype.len " + haptype.length);
				for(int j=0;j<haptype.length;j++){
					double freqdb=(double)(freqhp[j])/(double)(pop_now); 
					//if(freqhp[j]>0){
					if(freqdb>hapfreq4disp){
						
						
						String hpkata = "";
						
						for(int k=0;k<haptype[j].arr.length;k++){
							
							hpkata += haptype[j].arr[k] + " ";
						}
						freqdataout=hptypecnt + "\t" + j+"\t" + freqhp[j] + "\t" + hpkata + "\n";
						//OutXML.out3File(bw5,freqdataout);
						if(i==num_gen-1){
							//OutXML.out3File(bw8,freqdataout);
						}
						hp_loc_x_tmp[j]=gen*pop_now;
						hp_loc_y_tmp[j]=hptypecnt*pop_now;
						
						String freqsvg=TaVtoGML.outSVGtoSt5Node(nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqdb,
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						
						
						//OutXML.out3File(bw4,freqsvg);
						//String freqvgj=TaVtoGML.outVGJtoSt5Node(hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
								//NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//String freqvgj=TaVtoGML.outVGJtoSt6Node(hpkata,hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
						String freqvgj=TaVtoGML.outVGJtoSt6Node_URL(hpkata,hp_nd_tot,0,hp_loc_x_tmp[j],hp_loc_y_tmp[j],0,freqhp[j],
								NdLb,EdLb,rootCol,mutCol,recCol,mutEdcol,recEdcol);
						//OutXML.out3File(bw6,freqvgj);
						gml2+=freqvgj;
						hp_nd_tmp[j]=hp_nd_tot;
						hp_nd_tot++;
						
						for(int k=0;k<hpoya.arr.length;k++){
							if(hpko.arr[k]==j){
								String hp_svg_ed=TaVtoGML.outSVGtoSt5Edge(1, 
										hp_loc_x[hpoya.arr[k]],hp_loc_y[hpoya.arr[k]],hp_loc_x_tmp[j],
										hp_loc_y_tmp[j],NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								//OutXML.out3File(bw4,hp_svg_ed);
								String hp_vgj_ed=TaVtoGML.outVGJtoSt5Edge(hp_nd_tmp[j],2,hp_nd[hpoya.arr[k]],
										NdLb,EdLb,
										rootCol,mutCol,recCol,mutEdcol,recEdcol);
								
								//OutXML.out3File(bw6,hp_vgj_ed);
//								OutXML.out3File(bw6,hp_vgj_ed);
								gml2+=hp_vgj_ed;
							}
						}
						String hpid=i + "\t" + hptypecnt + "\t" + j+"\n";
						//OutXML.out3File(bw21,hpid);
						
						hptypecnt++;
					}
					
				}
				//output parent,child of ch
				for(int j=0;j<pop_before;j++){
					String textchild = i-1 + " " + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textchild2 = i-1 + " " + j +"\t";
						if(choya.arr[k]==j){
							textchild += i + " " + chko.arr[k] + "\t";
							textchild2 += i + " " + chko.arr[k] + "\t\n";
							//OutXML.out3File(bw12,"parent\t");
							//OutXML.out3File(bw12,textchild2);
							
							//OutXML.out3File(bw14,textchild2);
						}
					}
					textchild += "\n";
					//OutXML.out3File(bw9,"parent\t");
					//OutXML.out3File(bw9,textchild);
					//OutXML.out3File(bw11,textchild);
				}
				for(int j=0;j<pop_now;j++){
					String textparent = i + " " + j +"\t";
					
					for(int k=0;k<choya.arr.length;k++){
						String textparent2 = i + " " + j +"\t";
						if(chko.arr[k]==j){
							textparent += i-1 + " " + choya.arr[k] + "\t";
							textparent2 += i-1 + " " + choya.arr[k] + "\t\n";
							//OutXML.out3File(bw12,"child\t");
							//OutXML.out3File(bw12,textparent2);
							//OutXML.out3File(bw13,textparent2);
						}
					}
					textparent += "\n";
					//OutXML.out3File(bw9,"child\t");
					//OutXML.out3File(bw9,textparent);
					//OutXML.out3File(bw10,textparent);
				}
//				output parent,child of hp
				for(int j=0;j<haptype_before.length;j++){
					if(freqhp_before[j]>0){
						String textchild = i-1 + " " + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textchild2 = i-1 + " " + j +"\t";
							if(hpoya.arr[k]==j){
								textchild += i + " " + hpko.arr[k] + "\t";
								textchild2 += i + " " + hpko.arr[k] + "\t\n";
								//OutXML.out3File(bw18,"parent\t");
								//OutXML.out3File(bw18,textchild2);
								
								//OutXML.out3File(bw20,textchild2);
							}
						}
						textchild += "\n";
						//OutXML.out3File(bw15,"parent\t");
						//OutXML.out3File(bw15,textchild);
						//OutXML.out3File(bw17,textchild);
					}
					
				}
				int freqhpcnt=0;
				for(int j=0;j<haptype.length;j++){
					if(freqhp[j]>0){
						String textparent = i + " " + j +"\t";
						
						for(int k=0;k<hpoya.arr.length;k++){
							String textparent2 = i + " " + j +"\t";
							if(hpko.arr[k]==j){
								textparent += i-1 + " " + hpoya.arr[k] + "\t";
								textparent2 += i-1 + " " + hpoya.arr[k] + "\t\n";
								//OutXML.out3File(bw18,"child\t");
								//OutXML.out3File(bw18,textparent2);
								//OutXML.out3File(bw19,textparent2);
							}
						}
						textparent += "\n";
						//OutXML.out3File(bw15,"child\t");
						//OutXML.out3File(bw15,textparent);
						//OutXML.out3File(bw16,textparent);
					}
					
				}
				
				pop_before = pop_now;
				
				nd_hp = null;
				nd_hp = new int[nd_hp_tmp.length];
				nd_hp = nd_hp_tmp;
				gen_tot_id = null;
				gen_tot_id = gen_tot_id_tmp;
				nd_loc_x=null;
				nd_loc_y=null;
				nd_loc_x=nd_loc_x_tmp;
				nd_loc_y=nd_loc_y_tmp;
				hp_loc_x=null;
				hp_loc_y=null;
				hp_loc_x=hp_loc_x_tmp;
				hp_loc_y=hp_loc_y_tmp;
				hp_nd = null;
				freqhp_before = freqhp;
				hp_nd = hp_nd_tmp;

				gen++;
			}
			
			textvgj="";
			textvgj=TaVtoGML.outVGJtoSt5footer(textvgj);
			//OutXML.out3File(bw1,textvgj);
			textsvg="";
			textsvg=TaVtoGML.outSVGtoSt5footer(textsvg);
			//OutXML.out3File(bw2,textsvg);
			//OutXML.out3File(bw4,textsvg);
			//OutXML.out3File(bw6,textvgj);
			gml1+=textvgj;
			gml2+=textvgj;
			//OutXML.out2File(vgjfile,textvgj);
			/*
			bw1.close();
			bw2.close();
			bw3.close();
			bw4.close();
			bw5.close();
			bw6.close();
			bw7.close();
			bw8.close();
			bw9.close();
			bw10.close();
			bw11.close();
			bw12.close();
			bw13.close();
			bw14.close();
			bw15.close();
			bw16.close();
			bw17.close();
			bw18.close();
			bw19.close();
			bw20.close();
			bw21.close();
			*/
			//System.out.println("�v��VGJ");
//			VGJ
			//GMLlexer
			//String text=tmpgr2[1].outVGJtoSt();
			//String text = textarea_.getText();
	        StringBufferInputStream stream1 = new StringBufferInputStream(gml1);
	        StringBufferInputStream stream2 = new StringBufferInputStream(gml2);
	        GMLlexer gmlLex1 = new GMLlexer(stream1);
	        GMLlexer gmlLex2 = new GMLlexer(stream2);
			//GMLlexer gmlLex=new GMLlexer(lexer);
	        
	        auburn.VGJ.graph.Graph graph_1 = new auburn.VGJ.graph.Graph();
	        auburn.VGJ.graph.Graph graph_2 = new auburn.VGJ.graph.Graph();
	        boolean update = true;
	        GraphUpdate update_;
	        auburn.VGJ.graph.Graph newgraph1 = null;
	        auburn.VGJ.graph.Graph newgraph2 = null;
	        boolean freqGML=true;
	        if(freqGML){
	        	try
		        {
		           GMLobject GMLgraph = new GMLobject(gmlLex2, null);
		           GMLobject GMLtmp;
		        
		           // If the GML doesn't contain a graph, assume it is a graph.
		           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
		           if(GMLtmp != null)
		              GMLgraph = GMLtmp;
		           newgraph2 = new Graph(GMLgraph);
		        
		           //update_.update(true);
		        }
		        
		        
		           catch(ParseError error)
		           {
		           	/*
		              MessageDialog dg = new MessageDialog(this,
		                                                  "Error", error.getMessage() +
		                                                  " at line " + lexer.getLineNumber() + " at or near \""
		                                                  + lexer.getStringval() + "\".", true);
		              return true;
		              */
		           }
		           catch(IOException error)
		           {
		           	/*
		              MessageDialog dg = new MessageDialog(this,
		                                                  "Error", error.getMessage(), true);
		              return true;
		              */
		           }
		        
		        
		        
		        //GraphWindow���J��
		        
		        //GraphWindow gw=new GraphWindow(newgraph);
		           GraphWindow gw;
		           gw = buildWindow_(newgraph2);
		        gw.pack();
		        gw.show();
	        }else{
	        	try
		        {
		           GMLobject GMLgraph = new GMLobject(gmlLex1, null);
		           GMLobject GMLtmp;
		        
		           // If the GML doesn't contain a graph, assume it is a graph.
		           GMLtmp = GMLgraph.getGMLSubObject("graph", GMLobject.GMLlist, false);
		           if(GMLtmp != null)
		              GMLgraph = GMLtmp;
		           newgraph1 = new Graph(GMLgraph);
		        
		           //update_.update(true);
		        }
		        
		        
		           catch(ParseError error)
		           {
		           	/*
		              MessageDialog dg = new MessageDialog(this,
		                                                  "Error", error.getMessage() +
		                                                  " at line " + lexer.getLineNumber() + " at or near \""
		                                                  + lexer.getStringval() + "\".", true);
		              return true;
		              */
		           }
		           catch(IOException error)
		           {
		           	/*
		              MessageDialog dg = new MessageDialog(this,
		                                                  "Error", error.getMessage(), true);
		              return true;
		              */
		           }
		        
		        
		        
		        //GraphWindow���J��
		        
		        //GraphWindow gw=new GraphWindow(newgraph);
		           GraphWindow gw;
		           gw = buildWindow_(newgraph1);
		        gw.pack();
		        gw.show();
	        }
	        
		}catch(Exception e){
			System.out.println(e);
		}
		
		

	}

	private static GraphWindow buildWindow_(Graph gr_)
    {
		int appCount_ = 0;  	
		// Bring up an undirected graph editor window.
          
          	// The parameter to GraphWindow() indicates directed
          	// or undirected.
             //GraphWindow graph_editing_window = new GraphWindow(true);
		GraphWindow graph_editing_window = new GraphWindow(gr_);
          	// Here the algorithms are added.
             graph_editing_window.addAlgorithmMenu("Tree");
          
             ExampleAlg2 alg2 = new ExampleAlg2();
             graph_editing_window.addAlgorithm(alg2, "Random");
          
             TreeAlgorithm talg = new TreeAlgorithm('d');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Down");
          
             talg = new TreeAlgorithm('u');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Up");
          
             talg = new TreeAlgorithm('l');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Left");
          
             talg = new TreeAlgorithm('r');
             graph_editing_window.addAlgorithm(talg, "Tree", "Tree Right");
          
          
             graph_editing_window.addAlgorithmMenu("CGD");
          
             CGDAlgorithm calg = new CGDAlgorithm();
             graph_editing_window.addAlgorithm(calg, "CGD", "CGD");
          
             calg = new CGDAlgorithm(true);
             graph_editing_window.addAlgorithm(calg, "CGD",
                "show CGD parse tree");
          
             Spring spring = new Spring();
             graph_editing_window.addAlgorithm(spring, "Spring");
          
             graph_editing_window.addAlgorithmMenu("Biconnectivity");
             BiconnectGraph make_biconnect = new BiconnectGraph(true);
             graph_editing_window.addAlgorithm (make_biconnect, 
                "Biconnectivity", "Remove Articulation Points");
             BiconnectGraph check_biconnect = new BiconnectGraph(false);
             graph_editing_window.addAlgorithm (check_biconnect, 
                "Biconnectivity", "Find Articulation Points");
          
             if (appCount_++ == 0)
                graph_editing_window.setTitle("VGJ v1.03");
             else
                graph_editing_window.setTitle("VGJ v1.03" + ": "
                   + appCount_);
             graph_editing_window.setLocation(50,50);
             graph_editing_window.pack();
             graph_editing_window.show();

             return graph_editing_window;
    }

}
